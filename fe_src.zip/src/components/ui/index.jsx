/**
 * ui.jsx — Single source of truth cho tất cả shared UI primitives.
 */
import { Loader2 } from 'lucide-react';

// ── Layout helpers ────────────────────────────────────────────────────────────

export function PageHeader({ icon: Icon, title, subtitle, action }) {
  return (
    <div className="flex items-start justify-between gap-3 flex-wrap">
      <div className="flex items-start gap-3 min-w-0">
        {Icon && (
          <div className="w-10 h-10 rounded-xl bg-gold/15 text-gold flex items-center justify-center flex-shrink-0 mt-0.5 ring-1 ring-gold/20">
            <Icon size={19} />
          </div>
        )}
        <div className="min-w-0">
          <h1 className="text-xl sm:text-2xl font-bold text-ink" style={{ fontFamily: 'var(--font-display)' }}>
            {title}
          </h1>
          {subtitle && <p className="text-sm text-muted mt-0.5">{subtitle}</p>}
        </div>
      </div>
      {action && <div className="flex-shrink-0">{action}</div>}
    </div>
  );
}

export function SectionCard({ children, className = '' }) {
  return (
    <div className={`bg-surface rounded-2xl border border-hairline shadow-sm overflow-hidden ${className}`}>
      {children}
    </div>
  );
}

export function SectionHeader({ title, action }) {
  return (
    <div className="flex items-center justify-between px-5 py-3.5 border-b border-hairline bg-canvas">
      <h3 className="text-xs font-semibold text-muted uppercase tracking-wider">{title}</h3>
      {action}
    </div>
  );
}

// ── Feedback ──────────────────────────────────────────────────────────────────

export function LoadingSpinner({ label = '' }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-muted">
      <Loader2 className="animate-spin text-gold" size={26} />
      <p className="mt-2.5 text-sm">{label}</p>
    </div>
  );
}

export function EmptyState({ icon: Icon, title, description, action }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
      {Icon && (
        <div className="w-14 h-14 rounded-2xl bg-canvas flex items-center justify-center text-gold/40 mb-3">
          <Icon size={24} />
        </div>
      )}
      <p className="text-ink font-medium">{title}</p>
      {description && <p className="text-sm text-muted mt-1 max-w-xs">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

// ── Buttons ───────────────────────────────────────────────────────────────────

export function PrimaryButton({ children, loading, className = '', ...rest }) {
  return (
    <button {...rest} disabled={loading || rest.disabled}
      className={`inline-flex items-center justify-center gap-2 px-4 py-2.5
        bg-gold text-white text-sm font-semibold rounded-xl
        hover:bg-gold-strong active:bg-gold-strong
        disabled:bg-gold/50 disabled:cursor-not-allowed
        transition-colors shadow-sm ${className}`}>
      {loading && <Loader2 size={14} className="animate-spin" />}
      {children}
    </button>
  );
}

export function SecondaryButton({ children, className = '',
                                   loading, size, ...rest }) {
  // FIX (10/2026): swallow `loading` và `size` để không lọt xuống <button>
  //   • React 19 cảnh báo "Received `false` for a non-boolean attribute
  //     `loading`" khi loading={false} được truyền thẳng.
  //   • `size="sm"` không hợp lệ với <button> (chỉ hợp lệ với <input>).
  // Nhiều call-site cũ vẫn truyền 2 prop này; giờ render spinner khi
  // loading=true (giống DangerButton) để chúng có hiệu ứng đúng kỳ vọng.
  const sizeCls = size === 'sm'
    ? 'px-3 py-1.5 text-xs'
    : 'px-4 py-2.5 text-sm';
  return (
    <button {...rest} disabled={loading || rest.disabled}
      className={`inline-flex items-center justify-center gap-2
        bg-surface text-ink font-semibold rounded-xl
        border border-hairline-2 hover:bg-canvas active:bg-surface-2
        disabled:opacity-60 disabled:cursor-not-allowed
        transition-colors ${sizeCls} ${className}`}>
      {loading && <Loader2 size={size === 'sm' ? 12 : 14} className="animate-spin" />}
      {children}
    </button>
  );
}

export function DangerButton({ children, loading, className = '', ...rest }) {
  return (
    <button {...rest} disabled={loading || rest.disabled}
      className={`inline-flex items-center justify-center gap-2 px-4 py-2.5
        bg-red-600 text-white text-sm font-semibold rounded-xl
        hover:bg-red-700 disabled:opacity-60 disabled:cursor-not-allowed
        transition-colors ${className}`}>
      {loading && <Loader2 size={14} className="animate-spin" />}
      {children}
    </button>
  );
}

export function IconButton({ icon: Icon, label, onClick, className = '' }) {
  return (
    <button onClick={onClick} title={label}
      className={`p-2 rounded-lg text-muted hover:text-ink hover:bg-canvas transition-colors ${className}`}>
      <Icon size={15} />
    </button>
  );
}

// ── Form ──────────────────────────────────────────────────────────────────────

export function Field({ label, children, required, hint, error }) {
  return (
    // Dùng <div> thay vì <label> — label HTML tự động forward click/focus tới
    // control con đầu tiên bên trong nó. Với input/select đơn giản thì vô hại,
    // nhưng với các custom dropdown nhiều bước (search input + list item + tag
    // xoá) như MultiProductSelect/SearchDropdown, hành vi forward này khiến
    // click vào ô input bị browser "chuyển tiếp" thành click vào nút xoá tag
    // hoặc phần tử ẩn đầu tiên, gây mất lựa chọn đã chọn và dropdown không mở
    // được trên mobile (touch event bị label nuốt mất).
    <div className="block">
      <span className="block text-xs font-semibold text-ink uppercase tracking-wider mb-1.5">
        {label}{required && <span className="text-red-500 ml-0.5">*</span>}
      </span>
      {children}
      {hint && !error && <p className="text-xs text-muted mt-1">{hint}</p>}
      {error && <p className="text-xs text-red-600 dark:text-red-300 mt-1">{error}</p>}
    </div>
  );
}

export const inputCls =
  'w-full px-3 py-2.5 bg-surface border border-hairline-2 rounded-xl text-sm text-ink placeholder-muted/70 focus:outline-none focus:border-gold focus:ring-2 focus:ring-gold/20 transition-all';

export const selectCls = inputCls + ' cursor-pointer';

// ── Tabs ──────────────────────────────────────────────────────────────────────

export function TabBar({ tabs, active, onChange }) {
  return (
    <div className="flex bg-surface border border-hairline rounded-xl p-1 shadow-sm w-fit flex-wrap gap-0.5">
      {tabs.map(tab => (
        <button key={tab.id} onClick={() => onChange(tab.id)}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap
            ${active === tab.id ? 'bg-chrome text-white shadow-sm' : 'text-muted hover:text-ink hover:bg-canvas'}`}>
          {tab.icon && <tab.icon size={14} />}
          {tab.label}
        </button>
      ))}
    </div>
  );
}

// ── Table ─────────────────────────────────────────────────────────────────────

export function Table({ children, className = '' }) {
  return (
    <div className="overflow-x-auto">
      <table className={`w-full text-sm ${className}`}>{children}</table>
    </div>
  );
}

export function Thead({ children, className = '' }) {
  return (
    <thead className={className}>
      {children}
    </thead>
  );
}

export function Th({ children, className = '', right = false }) {
  return (
    <th className={`px-4 py-3 font-semibold text-xs uppercase tracking-wider ${right ? 'text-right' : 'text-left'} ${className}`}>
      {children}
    </th>
  );
}

// `...rest` để truyền được colSpan / rowSpan / title xuống thẻ <td> thật.
// Thiếu nó thì mọi ô gộp cột đều âm thầm bị bỏ qua và bảng lệch cột.
export function Td({ children, className = '', right = false, ...rest }) {
  return (
    <td className={`px-4 py-3 ${right ? 'text-right' : ''} ${className}`} {...rest}>
      {children}
    </td>
  );
}

export function Tr({ children, onClick, className = '', ...rest }) {
  const isHeader =
    className.includes('bg-canvas') ||
    className.includes('bg-');

  return (
    <tr
      onClick={onClick}
      {...rest}
      className={`
        ${!isHeader ? 'border-t border-hairline' : ''}
        transition-colors
        ${onClick
          ? 'cursor-pointer hover:bg-canvas/60'
          : !isHeader
            ? 'hover:bg-canvas/30'
            : ''
        }
        ${className}
      `}
    >
      {children}
    </tr>
  );
}

// ── Format helpers ────────────────────────────────────────────────────────────

export const formatCurrency = (v) =>
  new Intl.NumberFormat('vi-VN').format(Math.round(Number(v || 0))) + '₫';

export const formatNumber = (v) =>
  new Intl.NumberFormat('vi-VN').format(Number(v || 0));

export const formatDateTime = (ms) => {
  if (!ms) return '–';
  return new Date(Number(ms)).toLocaleString('vi-VN', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
};

export const formatDate = (ms) => {
  if (!ms) return '–';
  return new Date(Number(ms)).toLocaleDateString('vi-VN', {
    day: '2-digit', month: '2-digit', year: 'numeric',
  });
};

/* ── Barrel ───────────────────────────────────────────────────────────────────
   Gom mọi primitive về một điểm nhập, để trang chỉ cần:
       import { PageHeader, Modal, StatCard, OrderStatusBadge } from '../../components/ui';
   thay vì 6 dòng import trỏ vào 6 file. */
export * from './Skeleton.jsx';
export * from './Badge.jsx';
export { default as Modal } from './Modal.jsx';
export { default as Pagination } from './Pagination.jsx';
export { default as StatCard } from './StatCard.jsx';
export { default as DatePicker } from './DatePicker.jsx';
export { default as DateTimePicker } from './DateTimePicker.jsx';
export { default as DateRangePicker } from './DateRangePicker.jsx';
export { default as MonthPicker } from './MonthPicker.jsx';
export { default as TimePicker } from './TimePicker.jsx';
export { default as ExpenseDatePeriodPicker } from './ExpenseDatePeriodPicker.jsx';
export { default as CustomerOrderHistory } from './CustomerOrderHistory.jsx';