// src/components/hr/AttendanceDayCalendar.jsx
// LỊCH CHẤM CÔNG 1 THÁNG CỦA 1 NHÂN VIÊN — dùng chung.
//
//   · Trang "Quản lý lương" (MyPayrollPage) — nhân viên tự xem của mình.
//   · Modal "Chi tiết ngày công" trong Bảng chấm công của OWNER — xem của
//     nhân viên bất kỳ trong bảng Phiếu lương.
//
// Component này CHỈ render phần ruột (lưới ngày + chi tiết ngày + tổng kết),
// KHÔNG bọc SectionCard, để nơi gọi tự quyết định khung chứa (card hay modal).
//
// Dữ liệu `attendance` lấy từ:
//   · GET /api/factory-payroll/my-payslip     → slip.attendance
//   · GET /api/factory-payroll/employee-attendance?userId&month&year
// Hai nguồn trả về CÙNG một DTO (AttendanceSummaryDto) nên dùng chung được.
import { useState, useEffect } from 'react';
import {
  AlertCircle, AlertTriangle, Check, Clock, Coffee, LogIn, LogOut, Minus,
  MousePointerClick, Plane, Sun, X,
} from 'lucide-react';

const fmtNum = (v, d = 2) =>
  v == null ? '\u2014' : Number(v).toLocaleString('vi-VN', { maximumFractionDigits: d });

export const WEEKDAY_LABEL = { 2: 'T2', 3: 'T3', 4: 'T4', 5: 'T5', 6: 'T6', 7: 'T7', 8: 'CN' };

/** Màu + icon cho từng loại ngày công trên lịch. */
const DAY_TYPE = {
  WORK:      { cls: 'bg-emerald-500 text-white border-emerald-500', label: 'Đủ công', icon: Check },
  HALF:      { cls: 'bg-amber-400 text-white border-amber-400', label: 'Nửa công (0.5)', icon: Minus },
  MISSING:   { cls: 'bg-red-400 text-white border-red-400', label: 'Thiếu chấm công (0 công)', icon: AlertTriangle },
  EXCEPTION: { cls: 'bg-violet-500 text-white border-violet-500', label: 'Nghỉ có phép (đủ công)', icon: Plane },
  HOLIDAY:   { cls: 'bg-gray-300 dark:bg-gray-600 text-gray-600 dark:text-gray-300 border-gray-400 dark:border-gray-500', label: 'Lễ / Tết / Nghỉ', icon: Sun },
  LEAVE:     { cls: 'bg-sky-400 text-white border-sky-400', label: 'Nghỉ có phép', icon: Plane },
  UNPAID:    { cls: 'bg-red-100 dark:bg-red-500/18 text-red-700 dark:text-red-300 border-red-300 dark:border-red-500/35', label: 'Nghỉ không lương', icon: AlertCircle },
  BUSINESS:  { cls: 'bg-indigo-500 text-white border-indigo-500', label: 'Công tác', icon: Plane },
  OFF:       { cls: 'bg-canvas text-faint border-hairline', label: 'Không chấm công', icon: Coffee },
};

/** Đổi số phút thành dạng "8h33" cho dễ đọc. */
const fmtDuration = (m) => {
  if (!m || m <= 0) return '—';
  const h = Math.floor(m / 60), r = m % 60;
  return h > 0 ? `${h}h${r ? String(r).padStart(2, '0') : ''}` : `${r} phút`;
};

// ═════════════════════════════
// CHI TIẾT 1 NGÀY CHẤM CÔNG — cột phải
// ═════════════════════════════

function DayDetail({ day, month, year, onClose }) {
  if (!day) return null;

  // Derive type from value for old data: type="WORK" but value=0.5 → HALF
  let effectiveType = day.type;
  if (day.type === 'WORK' && day.value != null && day.value < 1 && day.value > 0)
    effectiveType = 'HALF';
  if (day.type === 'WORK' && day.value != null && day.value <= 0)
    effectiveType = 'MISSING';

  const cfg = DAY_TYPE[effectiveType] || DAY_TYPE.OFF;
  const Icon = cfg.icon;
  const dateStr = `${String(day.day).padStart(2, '0')}/${String(month).padStart(2, '0')}/${year}`;

  const sessions = day.sessions?.length
    ? day.sessions
    : (day.checkIn || day.checkOut ? [{ in: day.checkIn, out: day.checkOut }] : []);

  return (
    <div className="lg:h-full flex flex-col rounded-2xl border border-gold/30 overflow-hidden
      bg-gradient-to-br from-gold/10 to-transparent">

      <div className="shrink-0 flex items-center justify-between gap-3 px-4 py-3
        border-b border-gold/20">
        <div className="flex items-center gap-2.5 min-w-0">
          <span className={`w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 ${cfg.cls}`}>
            <Icon size={15} />
          </span>
          <div className="min-w-0">
            <p className="text-sm font-bold text-ink leading-tight">
              {dateStr} · Thứ {day.weekdayLabel}
            </p>
            <p className="text-[11px] text-muted mt-0.5">{cfg.label}</p>
          </div>
        </div>
        <button onClick={onClose}
          className="p-1.5 rounded-lg text-muted hover:text-ink
            hover:bg-surface/60 transition-colors shrink-0">
          <X size={15} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {sessions.length === 0 ? (
          <p className="text-sm text-muted text-center py-3">
            Không có dữ liệu chấm công trong ngày này.
          </p>
        ) : (
          <div className="space-y-2">
            {sessions.map((s, i) => (
              <div key={i}
                className="flex items-center gap-3 bg-surface rounded-xl px-3.5 py-3 border border-hairline">
                {sessions.length > 1 && (
                  <span className="w-6 h-6 rounded-lg bg-canvas flex items-center justify-center
                    text-[11px] font-bold text-muted shrink-0">{i + 1}</span>
                )}
                <div className="flex-1 flex items-center gap-2">
                  <LogIn size={14} className="text-emerald-600 dark:text-emerald-300 shrink-0" />
                  <div>
                    <p className="text-[10px] uppercase tracking-wide text-muted font-bold">Vào</p>
                    <p className="text-base font-bold text-ink leading-tight">{s.in || '--:--'}</p>
                  </div>
                </div>
                <div className="w-px h-8 bg-hairline" />
                <div className="flex-1 flex items-center gap-2">
                  <LogOut size={14} className="text-orange-600 dark:text-orange-300 shrink-0" />
                  <div>
                    <p className="text-[10px] uppercase tracking-wide text-muted font-bold">Ra</p>
                    <p className="text-base font-bold text-ink leading-tight">{s.out || '--:--'}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="flex flex-wrap gap-2">
          <span className="text-[11px] font-semibold px-2.5 py-1 rounded-lg
            bg-surface border border-hairline text-ink-2">
            Công ghi nhận: <strong className="text-ink">{fmtNum(day.value)}</strong>
          </span>
          {day.lateMinutes > 0 && (
            <span className="text-[11px] font-semibold px-2.5 py-1 rounded-lg
              bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/28 text-amber-700 dark:text-amber-300"
              title="Ghi nhận cho KPI — không trừ lương">
              Đi trễ {day.lateMinutes} phút <span className="opacity-60">(KPI)</span>
            </span>
          )}
          {day.earlyMinutes > 0 && (
            <span className="text-[11px] font-semibold px-2.5 py-1 rounded-lg
              bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/28 text-blue-700 dark:text-blue-300"
              title="Ghi nhận cho KPI — không trừ lương">
              Về sớm {day.earlyMinutes} phút <span className="opacity-60">(KPI)</span>
            </span>
          )}
          {day.workedMinutes > 0 && (
            <span className="text-[11px] font-semibold px-2.5 py-1 rounded-lg
              bg-surface border border-hairline text-ink-2"
              title="Đã trừ 1 tiếng nghỉ trưa 12:00–13:00">
              Thời gian làm: <strong className="text-ink">{fmtDuration(day.workedMinutes)}</strong>
              {day.requiredMinutes > 0 && (
                <span className="text-muted"> / {fmtDuration(day.requiredMinutes)}</span>
              )}
            </span>
          )}
        </div>

        {day.exception && (
          <div className="flex items-start gap-2 bg-violet-50 dark:bg-violet-500/10 border border-violet-200 dark:border-violet-500/28 rounded-xl px-3 py-2.5">
            <Plane size={14} className="text-violet-600 dark:text-violet-300 shrink-0 mt-0.5" />
            <p className="text-[11px] text-violet-800 dark:text-violet-300 leading-snug">
              <strong>{day.exception}</strong>
              {day.windowStart && ` — ca làm ngày này là ${day.windowStart}–${day.windowEnd}.`}
            </p>
          </div>
        )}

        {day.type === 'MISSING' && (
          <div className="flex items-start gap-2 bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/28 rounded-xl px-3 py-2.5">
            <AlertTriangle size={14} className="text-red-600 dark:text-red-300 shrink-0 mt-0.5" />
            <p className="text-[11px] text-red-800 dark:text-red-300 leading-snug">
              Ngày này thiếu giờ vào hoặc giờ ra nên <strong>không được tính công</strong>.
              Nếu có lý do chính đáng, hãy nộp đơn xin nghỉ / đi trễ cho bộ phận nhân sự.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

// ═════════════════════════════
// PLACEHOLDER CỘT PHẢI — dùng chung cho cả chấm công lẫn tài xế
// ═════════════════════════════

export function DayDetailPlaceholder({ description }) {
  return (
    <div className="hidden lg:flex flex-col items-center justify-center text-center
      h-full px-8 rounded-2xl border border-dashed border-hairline-2 bg-canvas/60">
      <span className="w-12 h-12 rounded-2xl bg-surface border border-hairline
        flex items-center justify-center shadow-sm">
        <MousePointerClick size={20} className="text-gold" />
      </span>
      <p className="text-sm font-bold text-ink mt-4">Chọn một ngày để xem chi tiết</p>
      <p className="text-xs text-muted mt-1.5 leading-relaxed max-w-[280px]">
        {description}
      </p>
    </div>
  );
}

// ═════════════════════════════
// LỊCH CHẤM CÔNG (mọi bộ phận trừ Tài xế)
// ═════════════════════════════

export default function AttendanceDayCalendar({ attendance, month, year, showHeader = true }) {
  const [selected, setSelected] = useState(null);
  const days = attendance?.days || [];

  useEffect(() => { setSelected(null); }, [month, year, attendance]);

  // Không có dữ liệu ngày nào → báo rõ thay vì render khung rỗng. Trường hợp hay
  // gặp: nhân viên không khớp được mã chấm công khi import file Excel.
  if (!days.length) {
    return (
      <div className="flex flex-col items-center justify-center text-center px-6 py-12">
        <span className="w-12 h-12 rounded-2xl bg-canvas border border-hairline
          flex items-center justify-center">
          <Coffee size={20} className="text-faint" />
        </span>
        <p className="text-sm font-bold text-ink mt-4">Chưa có dữ liệu chấm công</p>
        <p className="text-xs text-muted mt-1.5 max-w-[320px] leading-relaxed">
          Tháng này chưa có bảng chấm công cho nhân viên, hoặc mã chấm công của
          nhân viên không khớp với dòng nào trong file đã tải lên.
        </p>
      </div>
    );
  }

  const leading = Math.max(0, days[0].weekday - 2);   // T2 = cột 0
  const cells = [...Array(leading).fill(null), ...days];

  const usedTypes = [...new Set(days.map(d => {
    if (d.type === 'WORK' && d.value != null && d.value < 1 && d.value > 0) return 'HALF';
    if (d.type === 'WORK' && d.value != null && d.value <= 0) return 'MISSING';
    return d.type;
  }))].filter(t => DAY_TYPE[t]);
  const hasPunchData = days.some(d => d.checkIn || d.checkOut || d.sessions?.length);

  return (
    <>
      {/* Tiêu đề — ẩn được khi component nằm trong Modal đã có tiêu đề riêng */}
      {showHeader && (
        <div className="flex items-center justify-between px-5 py-4 border-b border-hairline">
          <div className="flex items-center gap-2">
            <Clock size={16} className="text-gold" />
            <h3 className="text-sm font-bold text-ink">Chi tiết ngày công</h3>
          </div>
          <span className="text-xs font-semibold text-muted">
            {fmtNum(attendance.actualDays)} / {fmtNum(attendance.standardDays)} công
          </span>
        </div>
      )}

      <div className="p-4 sm:p-5">
        <div className="grid lg:grid-cols-[auto_1fr] gap-5 lg:gap-8 lg:items-stretch">

          {/* CỘT TRÁI — lưới lịch + chú thích */}
          <div>
            {hasPunchData && (
              <p className="text-[11px] text-muted mb-3 lg:hidden">
                Bấm vào một ngày để xem giờ chấm công vào / ra (tối đa 3 lượt).
              </p>
            )}

            <div className="grid grid-cols-[repeat(7,44px)] gap-1.5 mb-1.5">
              {[2, 3, 4, 5, 6, 7, 8].map(w => (
                <div key={w} className="text-center text-[10px] font-bold text-muted">
                  {WEEKDAY_LABEL[w]}
                </div>
              ))}
            </div>

            <div className="grid grid-cols-[repeat(7,44px)] gap-1.5">
              {cells.map((d, i) => {
                if (!d) return <div key={`empty-${i}`} />;
                // Derive type from value for old data compatibility
                let cellType = d.type;
                if (d.type === 'WORK' && d.value != null && d.value < 1 && d.value > 0)
                  cellType = 'HALF';
                if (d.type === 'WORK' && d.value != null && d.value <= 0)
                  cellType = 'MISSING';
                const cfg = DAY_TYPE[cellType] || DAY_TYPE.OFF;
                const isSelected = selected?.day === d.day;
                const clickable = !!(d.checkIn || d.checkOut || d.sessions?.length || d.value > 0);

                return (
                  <button key={d.day}
                    onClick={() => setSelected(isSelected ? null : d)}
                    title={`Ngày ${d.day} · ${cfg.label}`
                      + (d.checkIn ? ` · ${d.checkIn}–${d.checkOut || '--:--'}` : '')}
                    className={`h-11 rounded-lg border flex items-center justify-center
                      text-[12px] font-bold leading-none transition-all ${cfg.cls}
                      ${clickable ? 'hover:scale-110 cursor-pointer' : 'cursor-default'}
                      ${isSelected ? 'ring-2 ring-gold ring-offset-1 scale-110' : ''}`}
                  >
                    {d.day}
                  </button>
                );
              })}
            </div>

            <div className="flex flex-wrap gap-x-4 gap-y-2 mt-4 pt-4 border-t border-hairline
              max-w-[340px]">
              {usedTypes.map(t => {
                const cfg = DAY_TYPE[t];
                return (
                  <div key={t} className="flex items-center gap-1.5">
                    <span className={`w-3.5 h-3.5 rounded-md border ${cfg.cls}`} />
                    <span className="text-[11px] text-muted font-medium">{cfg.label}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* CỘT PHẢI — chi tiết ngày đang chọn / placeholder */}
          <div className="min-w-0 lg:h-full lg:min-h-[300px]">
            {selected ? (
              <DayDetail day={selected} month={month} year={year}
                onClose={() => setSelected(null)} />
            ) : (
              <DayDetailPlaceholder description={hasPunchData
                ? 'Bấm vào ô ngày bên trái để xem giờ vào / ra, số công ghi nhận và ghi chú của ngày đó.'
                : 'Tháng này chưa có dữ liệu chấm công chi tiết. Bấm vào một ngày để xem thông tin hiện có.'} />
            )}
          </div>
        </div>

        {/* Tổng kết */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-5 pt-5 border-t border-hairline">
          {[
            { label: 'Công chuẩn', value: fmtNum(attendance.standardDays), color: 'text-ink' },
            {
              label: 'Tổng công tháng', value: fmtNum(attendance.actualDays), color: 'text-emerald-600 dark:text-emerald-300',
              sub: `${attendance.presentDays ?? 0} ngày có chấm công`
            },
            {
              label: 'Tổng phút đi trễ (KPI)', value: (attendance.lateMinutes ?? 0).toLocaleString('vi-VN'),
              color: 'text-amber-600 dark:text-amber-300', sub: `${attendance.lateCount ?? 0} ngày · không trừ lương`
            },
            {
              label: 'Tổng phút về sớm (KPI)', value: (attendance.earlyMinutes ?? 0).toLocaleString('vi-VN'),
              color: 'text-blue-600 dark:text-blue-300', sub: `${attendance.earlyCount ?? 0} ngày · không trừ lương`
            },
          ].map(st => (
            <div key={st.label} className="bg-canvas rounded-xl px-3 py-2.5">
              <p className="text-[11px] text-muted font-medium">{st.label}</p>
              <p className={`text-lg font-bold mt-0.5 leading-tight ${st.color}`}>{st.value}</p>
              {st.sub && <p className="text-[10px] text-muted mt-0.5">{st.sub}</p>}
            </div>
          ))}
        </div>

        <div className="flex flex-wrap gap-x-4 gap-y-1 mt-3 text-[11px] text-muted">
          {attendance.shiftStart && (
            <span>Ca chuẩn: <strong className="text-ink">
              {attendance.shiftStart}–{attendance.shiftEnd}</strong></span>
          )}
          {attendance.employeeCode && (
            <span>Mã chấm công: <strong className="text-ink">{attendance.employeeCode}</strong></span>
          )}
        </div>
      </div>
    </>
  );
}