// src/components/hr/EmployeeRequestsPanel.jsx
// PANEL DUYỆT ĐƠN NHÂN VIÊN — nằm trong tab "Phiếu nghỉ" của trang Nhân sự/Lương.
//
// Ba thao tác của OWNER, đúng theo quy trình:
//   1. Duyệt              → có phép (hưởng đủ công) hoặc không phép (công = 0)
//   2. Duyệt & trừ công   → nhập số công trừ, 0.01 – 1
//   3. Từ chối            → bắt buộc nêu lý do
//
// Mỗi thao tác đẩy một thông báo WebSocket về cho người tạo đơn; nội dung do
// backend dựng nên ở đây không cần ghép lại câu thông báo.
import { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Calendar, Check, X, MinusCircle, Clock, Loader2, AlertCircle,
  ChevronRight, Filter, RefreshCw,
} from 'lucide-react';

import LeaveBalanceCard, { useLeaveBalance } from './LeaveBalance';
import { employeeRequestApi } from '../../api/employeeRequestApi';
import { useToast } from '../common/Toast';
import Modal from '../ui/Modal';
import Pagination from '../ui/Pagination';
import {
  SectionCard, LoadingSpinner, EmptyState, PrimaryButton, SecondaryButton,
  Field, inputCls, selectCls, Table, Thead, Th, Td, Tr, formatDateTime,
} from '../ui';

// ══════════════════════════════════════════════════════════════════════════════
// HẰNG SỐ
// ══════════════════════════════════════════════════════════════════════════════

const DEPARTMENTS = [
  { value: '', label: 'Tất cả bộ phận' },
  { value: 'FACTORY', label: 'Xưởng sản xuất' },
  { value: 'ACCOUNTING', label: 'Kế toán' },
  { value: 'SALES', label: 'Kinh doanh' },
  { value: 'WAREHOUSE', label: 'Kho' },
  { value: 'DRIVER', label: 'Tài xế' },
];

const STATUSES = [
  { value: '', label: 'Tất cả trạng thái' },
  { value: 'PENDING', label: 'Chờ duyệt' },
  { value: 'APPROVED_PAID', label: 'Đã duyệt - có lương' },
  { value: 'APPROVED_UNPAID', label: 'Đã duyệt - không lương' },
  { value: 'APPROVED_DEDUCTED', label: 'Đã duyệt - trừ công' },
  { value: 'REJECTED', label: 'Từ chối' },
];

const STATUS_STYLE = {
  PENDING:           { cls: 'bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-500/28', icon: Clock },
  APPROVED_PAID:     { cls: 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-500/28', icon: Check },
  APPROVED_UNPAID:   { cls: 'bg-sky-50 dark:bg-sky-500/10 text-sky-700 dark:text-sky-300 border-sky-200 dark:border-sky-500/28', icon: Check },
  APPROVED_DEDUCTED: { cls: 'bg-orange-50 dark:bg-orange-500/10 text-orange-700 dark:text-orange-300 border-orange-200 dark:border-orange-500/28', icon: MinusCircle },
  REJECTED:          { cls: 'bg-red-50 dark:bg-red-500/10 text-red-700 dark:text-red-300 border-red-200 dark:border-red-500/28', icon: X },
};

function StatusBadge({ status, label }) {
  const s = STATUS_STYLE[status] || STATUS_STYLE.PENDING;
  const Icon = s.icon;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-lg border text-[11px] font-semibold whitespace-nowrap ${s.cls}`}>
      <Icon size={11} />{label}
    </span>
  );
}

/** Hiển thị số ngày rút gọn: 3, 1,5, 0,5 — không kéo dài số 0 thừa. */
const fmtDays = (v) => {
  const n = Number(v ?? 0);
  return (Number.isInteger(n) ? String(n) : n.toFixed(1)).replace('.', ',');
};

// ══════════════════════════════════════════════════════════════════════════════
// MODAL CHI TIẾT + DUYỆT
// ══════════════════════════════════════════════════════════════════════════════

function DecideModal({ item, onClose, onDone }) {
  const toast = useToast();

  // 'view' khi đơn đã xử lý; đơn còn chờ thì mở thẳng vào bước chọn thao tác.
  const [action, setAction] = useState(null);   // 'APPROVE' | 'DEDUCT' | 'REJECT'
  const [paid, setPaid] = useState(true);
  const [deduct, setDeduct] = useState('0.5');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setAction(null); setPaid(true); setDeduct('0.5'); setNote('');
  }, [item?.id]);

  // Số dư ngày phép của chính nhân viên gửi phiếu — nạp trước khi render để
  // auto-split. Hook phải chạy TRƯỚC early return để giữ đúng thứ tự hook giữa
  // các lần render (mở/đóng modal).
  const isLeave = item?.type === 'LEAVE';
  const leaveYear = item?.fromDate ? Number(String(item.fromDate).slice(0, 4))
                                   : new Date().getFullYear();
  const { balance: leaveBal } = useLeaveBalance(isLeave ? item?.userId : null, leaveYear);

  if (!item) return null;
  const editable = item.status === 'PENDING';

  // Số ngày phép phiếu này tiêu tốn — mốc trần khi chia phép / không lương.
  // Nghỉ nửa ngày luôn là 0,5 bất kể khoảng ngày.
  const totalDays = (() => {
    // BE đã cộng sẵn theo BUỔI (leaveDays) — ra được 3,5 / 0,5 / 4 cho phiếu
    // ngắt quãng. Chỉ tự tính khi gặp phiếu cũ chưa có trường này.
    if (item.leaveDays != null) return item.leaveDays;
    if (item.halfDay) return 0.5;
    if (!item.fromDate || !item.toDate) return 1;
    const a = new Date(item.fromDate), b = new Date(item.toDate);
    return Math.max(1, Math.round((b - a) / 86400000) + 1);
  })();

  // ── AUTO-SPLIT theo quỹ phép của chính nhân viên ─────────────────────────
  // Trừ hết ngày phép còn lại vào phiếu trước; phần dư (nếu có) mới cần người
  // duyệt chọn "Có phép — hưởng đủ công" hoặc "Không phép — công 0/0.5". Người
  // duyệt KHÔNG được sửa split, chỉ xem.
  const remainingDays = Math.max(0, Number(leaveBal?.remainingDays ?? 0));
  const autoPaidDays = isLeave ? Math.min(remainingDays, totalDays) : 0;
  const autoUnpaidDays = isLeave ? Math.max(0, totalDays - autoPaidDays) : 0;
  // Chỉ khi CÒN PHẦN DƯ mới có ý nghĩa để chọn có/không lương — hết quỹ hoặc
  // dùng chưa hết đều KHÔNG hiển thị 2 nút.
  const needsPaidChoice = isLeave && autoUnpaidDays > 0;

  const submit = async () => {
    if (action === 'REJECT' && !note.trim())
      return toast('Bắt buộc nhập lý do từ chối', 'error');

    const d = Number(deduct);
    if (action === 'DEDUCT' && (!d || d < 0.01 || d > 1))
      return toast('Số công trừ phải nằm trong khoảng 0.01 – 1', 'error');

    setBusy(true);
    try {
      if (action === 'APPROVE') {
        if (isLeave) {
          // Split đã tự tính từ quỹ; user không sửa được. Nếu không có phần
          // dư thì mặc định là "có phép" (APPROVED_PAID).
          const effectivePaid = needsPaidChoice ? paid : true;
          await employeeRequestApi.decide(item.id, {
            action: 'APPROVE',
            paid: effectivePaid,
            paidLeaveDays: autoPaidDays,
            unpaidLeaveDays: autoUnpaidDays,
            note: note.trim() || null,
          });
        } else {
          await employeeRequestApi.approve(item.id, paid, note.trim() || null);
        }
      }
      else if (action === 'DEDUCT') await employeeRequestApi.deduct(item.id, d, note.trim() || null);
      else await employeeRequestApi.reject(item.id, note.trim());

      toast('Đã xử lý phiếu — nhân viên đã nhận thông báo.', 'success');
      onDone?.();
      onClose();
    } catch (e) {
      toast(e?.response?.data?.message || 'Không xử lý được phiếu', 'error');
    } finally {
      setBusy(false);
    }
  };

  const Row = ({ label, children }) => (
    <div className="flex gap-3 py-2.5 border-b border-hairline last:border-0">
      <span className="text-xs text-muted uppercase tracking-wider w-32 flex-shrink-0 pt-0.5">{label}</span>
      <div className="text-sm text-ink min-w-0 flex-1">{children}</div>
    </div>
  );

  const ActionTab = ({ id, label, icon: Icon, tone }) => (
    <button type="button" onClick={() => setAction(id)}
      className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl text-sm
        font-semibold border transition-all
        ${action === id ? tone : 'bg-surface text-muted border-hairline-2 hover:border-gold hover:text-gold'}`}>
      <Icon size={14} />{label}
    </button>
  );

  return (
    <Modal open onClose={onClose} size="lg" title={`${item.typeLabel} — ${item.userFullName}`}>
      <div className="space-y-4">

        {/* ── Nội dung đơn ────────────────────────────────────────────────── */}
        <div>
          <Row label="Nhân viên">
            <div className="font-medium">{item.userFullName}</div>
            <div className="text-xs text-muted">
              {[item.roleLabel, item.departmentLabel].filter(Boolean).join(' · ')}
            </div>
          </Row>
          <Row label="Loại phiếu">{item.typeLabel}</Row>
          <Row label="Thời gian xin phép">
            {/* (10/2026) Hiện breakdown ngày có phép / không lương khi phiếu
                nghỉ bị auto-split (hết quỹ phép). */}
            {Array.isArray(item.daysBreakdown) && item.daysBreakdown.length > 0 ? (
              <div className="space-y-1">
                {item.daysBreakdown.map((d, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm">
                    <span className="text-ink font-medium">
                      {new Date(d.date).toLocaleDateString('vi-VN')}
                      {d.dayValue != null && d.dayValue < 1 && (
                        <span className="text-muted font-normal"> (nửa ngày)</span>
                      )}
                    </span>
                    <span className={`text-[11px] px-2 py-0.5 rounded-full font-semibold
                      ${d.paid
                        ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-500/28'
                        : 'bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-500/28'}`}>
                      {d.label}
                    </span>
                  </div>
                ))}
                <div className="pt-1 text-[11px] text-muted">
                  Tổng {item.leaveDays ?? item.totalDays} ngày
                  {(item.paidLeaveDays || 0) > 0 && (item.unpaidLeaveDays || 0) > 0 && (
                    <> · {item.paidLeaveDays} có lương + {item.unpaidLeaveDays} không lương</>
                  )}
                </div>
              </div>
            ) : (
              <span className="font-medium">{item.periodText}</span>
            )}
          </Row>
          <Row label="Lý do"><span className="whitespace-pre-wrap">{item.reason}</span></Row>
          <Row label="Trạng thái"><StatusBadge status={item.status} label={item.statusLabel} /></Row>

          {item.status === 'APPROVED_DEDUCTED' && (
            <Row label="Công bị trừ">
              <span className="font-semibold text-orange-600 dark:text-orange-300">{item.deductedDays} công</span>
            </Row>
          )}
          {item.decisionNote && (
            <Row label={item.status === 'REJECTED' ? 'Lý do từ chối' : 'Ghi chú'}>
              <span className="whitespace-pre-wrap">{item.decisionNote}</span>
            </Row>
          )}
          {item.decidedByName && (
            <Row label="Người duyệt">
              {item.decidedByName}
              <span className="text-xs text-muted ml-2">{formatDateTime(item.decidedAt)}</span>
            </Row>
          )}
          <Row label="Gửi lúc">{formatDateTime(item.createdAt)}</Row>
        </div>

        {/* ── Thao tác ───────────────────────────────────────────────────── */}
        {editable ? (
          <div className="rounded-xl border border-hairline-2 bg-canvas p-4 space-y-4">
            <p className="text-xs font-semibold text-ink uppercase tracking-wider">Xử lý phiếu</p>

            <div className="flex gap-2">
              <ActionTab id="APPROVE" label="Duyệt" icon={Check}
                tone="bg-emerald-600 text-white border-emerald-600 dark:border-emerald-500/40 shadow-sm" />
              <ActionTab id="DEDUCT" label="Duyệt & trừ công" icon={MinusCircle}
                tone="bg-orange-500 text-white border-orange-500 shadow-sm" />
              <ActionTab id="REJECT" label="Từ chối" icon={X}
                tone="bg-red-600 text-white border-red-600 dark:border-red-500/40 shadow-sm" />
            </div>

            {action === 'APPROVE' && isLeave && (
              <div className="space-y-3">
                {/* Số dư phép của CHÍNH nhân viên này — phải thấy TRƯỚC khi bấm
                    duyệt, nếu không sẽ duyệt vượt quỹ mà không hay. */}
                <div className="rounded-xl bg-surface border border-hairline-2 px-3 py-2.5">
                  <LeaveBalanceCard userId={item.userId} compact />
                </div>

                {/* Split được tính tự động: trừ hết ngày phép còn lại trước,
                    phần dư (nếu có) mới cần chọn có/không phép. Readonly. */}
                <Field label={`Chia ${fmtDays(totalDays)} ngày của phiếu`}
                  hint={autoUnpaidDays > 0
                    ? 'Đã dùng hết quỹ phép còn lại cho phiếu này. Phần dư cần chọn nhánh bên dưới.'
                    : 'Còn đủ quỹ phép — trọn phiếu là nghỉ có phép.'}>
                  <div className="flex items-center gap-2 flex-wrap">
                    <div className="flex items-center gap-1.5">
                      <div className="w-[90px] px-3 py-2.5 bg-canvas border border-hairline-2 rounded-xl
                          text-sm text-ink text-center font-semibold">
                        {fmtDays(autoPaidDays)}
                      </div>
                      <span className="text-xs text-muted">ngày phép</span>
                    </div>
                    <span className="text-muted">+</span>
                    <div className="flex items-center gap-1.5">
                      <div className={`w-[90px] px-3 py-2.5 bg-canvas border border-hairline-2 rounded-xl
                          text-sm text-center font-semibold
                          ${autoUnpaidDays > 0 ? 'text-amber-700 dark:text-amber-300' : 'text-ink'}`}>
                        {fmtDays(autoUnpaidDays)}
                      </div>
                      <span className="text-xs text-muted">ngày không lương</span>
                    </div>
                  </div>
                </Field>
              </div>
            )}

            {action === 'APPROVE' && (!isLeave || needsPaidChoice) && (
              <Field
                label={isLeave
                  ? `Nghỉ có lương hay không lương cho ${fmtDays(autoUnpaidDays)} ngày dư`
                  : 'Nghỉ có lương hay không lương'}
                required>
                <div className="flex gap-2">
                  <button type="button" onClick={() => setPaid(true)}
                    className={`flex-1 px-3 py-2.5 rounded-xl text-sm font-medium border transition-all
                      ${paid ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-300 dark:border-emerald-500/35'
                             : 'bg-surface text-muted border-hairline-2 hover:border-emerald-300 dark:border-emerald-500/35'}`}>
                    Có phép — hưởng đủ công
                  </button>
                  <button type="button" onClick={() => setPaid(false)}
                    className={`flex-1 px-3 py-2.5 rounded-xl text-sm font-medium border transition-all
                      ${!paid ? 'bg-sky-50 dark:bg-sky-500/10 text-sky-700 dark:text-sky-300 border-sky-300 dark:border-sky-500/35'
                              : 'bg-surface text-muted border-hairline-2 hover:border-sky-300 dark:border-sky-500/35'}`}>
                    Không phép — công ngày đó = 0 (hoặc 0,5 nếu nửa buổi)
                  </button>
                </div>
              </Field>
            )}

            {action === 'DEDUCT' && (
              <Field label="Số công bị trừ" required
                hint="Tối thiểu 0.01 — tối đa 1. VD trừ 0.1 công thì ngày đó còn 0.9 công.">
                <div className="flex items-center gap-2">
                  <input type="number" step="0.01" min="0.01" max="1"
                    value={deduct} onChange={e => setDeduct(e.target.value)}
                    className={inputCls + ' max-w-[140px]'} />
                  <div className="flex gap-1.5">
                    {['0.25', '0.5', '1'].map(v => (
                      <button key={v} type="button" onClick={() => setDeduct(v)}
                        className="px-2.5 py-1.5 rounded-lg text-xs font-semibold border border-hairline-2
                          bg-surface text-muted hover:border-gold hover:text-gold transition-colors">
                        {v}
                      </button>
                    ))}
                  </div>
                </div>
              </Field>
            )}

            {action && (
              <Field
                label={action === 'REJECT' ? 'Lý do từ chối' : 'Ghi chú cho nhân viên'}
                required={action === 'REJECT'}
                hint="Nội dung này được gửi kèm trong thông báo cho nhân viên.">
                <textarea rows={2} value={note} onChange={e => setNote(e.target.value)}
                  maxLength={2000}
                  placeholder={action === 'REJECT' ? 'VD: Đã có 2 người nghỉ cùng ngày…' : 'Không bắt buộc'}
                  className={inputCls + ' resize-y'} />
              </Field>
            )}
          </div>
        ) : (
          <div className="rounded-xl border border-hairline-2 bg-canvas px-4 py-3">
            <p className="text-sm text-muted">
              Phiếu đã được xử lý nên không thao tác lại được. Cần đổi quyết định thì yêu cầu
              nhân viên gửi phiếu mới.
            </p>
          </div>
        )}

        <div className="flex justify-end gap-2 pt-1">
          <SecondaryButton onClick={onClose}>Đóng</SecondaryButton>
          {editable && action && (
            <PrimaryButton onClick={submit} loading={busy}>Xác nhận</PrimaryButton>
          )}
        </div>
      </div>
    </Modal>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// PANEL
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Panel duyệt phiếu nghỉ / OT.
 *
 * @param userId  chỉ xét phiếu của MỘT nhân viên (mở từ nút "Duyệt nghỉ/OT"
 *                trên trang Nhân viên). Bỏ trống = toàn công ty như trước.
 */
/**
 * Phase 6b (10/2026): thêm prop {@code typeFilter} để tab "Phiếu nghỉ" và tab
 * "Phiếu làm ở nhà" dùng chung component này nhưng lọc 2 loại khác nhau.
 * Giá trị hợp lệ: 'LEAVE' | 'BUSINESS_TRIP' | 'WORK_FROM_HOME'. Null = tất cả.
 */
export default function EmployeeRequestsPanel({ userId = null, typeFilter = null }) {
  const toast = useToast();

  const [department, setDepartment] = useState('');
  // Mặc định lọc "Chờ duyệt": mở tab ra là thấy ngay việc cần làm, không phải
  // lội qua hàng trăm đơn cũ đã xử lý.
  // Khi xét riêng một người thì mở sẵn TẤT CẢ: số phiếu ít, và người duyệt
  // thường muốn thấy cả lịch sử để cân nhắc.
  const [status, setStatus] = useState(userId ? '' : 'PENDING');
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(1);

  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);
  const [pendingCount, setPendingCount] = useState(0);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await employeeRequestApi.search({
        department: userId ? undefined : (department || undefined),
        status: status || undefined,
        userId: userId || undefined,
        type: typeFilter || undefined,     // Phase 6b
        page, size: 20,
      });
      setItems(data?.content ?? []);
      setTotalPages(data?.totalPages ?? 1);
    } catch (e) {
      toast(e?.response?.data?.message || 'Không tải được danh sách phiếu', 'error');
    } finally {
      setLoading(false);
    }
  }, [department, status, page, userId, typeFilter, toast]);

  const loadSummary = useCallback(async () => {
    // Khi lọc theo một nhân viên, số liệu tổng của cả bộ phận gây hiểu nhầm —
    // đếm thẳng trên danh sách đang hiển thị thay vì gọi API tổng hợp.
    if (userId) return;
    try {
      const s = await employeeRequestApi.summary(department || undefined);
      setPendingCount(s?.pending ?? 0);
    } catch { /* badge không quan trọng tới mức phải báo lỗi */ }
  }, [department, userId]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { loadSummary(); }, [loadSummary]);

  // Đổi bộ lọc thì phải về trang 1, nếu không sẽ rơi vào trang trống.
  useEffect(() => { setPage(0); }, [department, status, userId, typeFilter]);

  // Chế độ một nhân viên: badge đếm ngay trên danh sách đang có.
  useEffect(() => {
    if (userId) setPendingCount(items.filter(i => i.status === 'PENDING').length);
  }, [userId, items]);

  const refresh = () => { load(); loadSummary(); };

  const headerNote = useMemo(() => {
    if (pendingCount === 0) return 'Không còn phiếu nào chờ duyệt.';
    return `${pendingCount} phiếu đang chờ duyệt.`;
  }, [pendingCount]);

  return (
    <div className="space-y-4">

      {/* ── Bộ lọc ──────────────────────────────────────────────────────── */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1.5 text-muted text-xs font-semibold uppercase tracking-wider mr-1">
          <Filter size={13} /> Lọc
        </div>
        {!userId && (
          <select value={department} onChange={e => setDepartment(e.target.value)}
            className={selectCls + ' max-w-[190px] py-2'}>
            {DEPARTMENTS.map(d => <option key={d.value} value={d.value}>{d.label}</option>)}
          </select>
        )}
        <select value={status} onChange={e => setStatus(e.target.value)}
          className={selectCls + ' max-w-[210px] py-2'}>
          {STATUSES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>

        <button onClick={refresh}
          className="inline-flex items-center gap-1.5 px-3 h-[42px] rounded-xl text-xs font-semibold
            bg-surface text-muted border border-hairline-2 hover:border-gold hover:text-gold transition-colors">
          <RefreshCw size={13} /> Tải lại
        </button>

        <span className={`ml-auto text-xs font-semibold px-2.5 py-1.5 rounded-lg
          ${pendingCount > 0 ? 'bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-300' : 'bg-canvas text-muted'}`}>
          {headerNote}
        </span>
      </div>

      {/* ── Danh sách ───────────────────────────────────────────────────── */}
      <SectionCard>
        {loading ? (
          <LoadingSpinner label="Đang tải phiếu…" />
        ) : items.length === 0 ? (
          <EmptyState
            icon={Calendar}
            title="Không có phiếu nào"
            description={status === 'PENDING'
              ? 'Tất cả phiếu đã được xử lý.'
              : 'Thử đổi bộ lọc để xem các phiếu khác.'}
          />
        ) : (
          <Table>
            <Thead>
              <Tr className="bg-canvas text-muted">
                <Th>Nhân viên</Th>
                <Th>Loại phiếu</Th>
                <Th>Thời gian xin phép</Th>
                <Th>Lý do</Th>
                <Th>Trạng thái</Th>
                <Th right>Gửi lúc</Th>
                <Th />
              </Tr>
            </Thead>
            <tbody>
              {items.map(it => (
                <Tr key={it.id} onClick={() => setSelected(it)}>
                  <Td>
                    <div className="font-medium text-ink">{it.userFullName}</div>
                    <div className="text-xs text-muted">
                      {[it.roleLabel, it.departmentLabel].filter(Boolean).join(' · ') || '—'}
                    </div>
                  </Td>
                  <Td className="whitespace-nowrap">{it.typeLabel}</Td>
                  <Td className="whitespace-nowrap font-medium text-ink">{it.periodText}</Td>
                  <Td className="text-muted max-w-[220px] truncate">{it.reason}</Td>
                  <Td><StatusBadge status={it.status} label={it.statusLabel} /></Td>
                  <Td right className="text-xs text-muted whitespace-nowrap">
                    {formatDateTime(it.createdAt)}
                  </Td>
                  <Td right><ChevronRight size={14} className="text-faint" /></Td>
                </Tr>
              ))}
            </tbody>
          </Table>
        )}

        {totalPages > 1 && (
          <div className="px-4 py-3 border-t border-hairline">
            <Pagination page={page} totalPages={totalPages} onChange={setPage} />
          </div>
        )}
      </SectionCard>

      {selected && (
        <DecideModal item={selected} onClose={() => setSelected(null)} onDone={refresh} />
      )}
    </div>
  );
}