// src/api/factoryPayrollApi.js
// API "Quản lý lương" — dùng chung cho MỌI bộ phận.
import api from './axios';

const r = (res) => res.data?.data ?? res.data;

/**
 * 5 bộ phận tính lương — khớp với enum PayrollDepartment bên backend.
 *
 * Phase 2 refactor (10/2026):
 *  - MANAGEMENT đã GỠ khỏi hệ thống lương (OWNER/ADMIN không có phiếu lương).
 *  - Tất cả 5 bộ phận giờ đều `attendanceBased: true` — dùng CHUNG 1 file
 *    chấm công cho cả công ty (upload ở CompanyPayrollPanel đầu trang).
 *
 * Phase 5 refactor (10/2026):
 *  - DRIVER: lương theo chấm công (base × ngày công / chuẩn công) đọc từ
 *    AttendanceEntry CHUNG như xưởng SX / văn phòng.
 *  - Chấm công ODO giờ CHỈ dùng để tính phụ cấp XĂNG XE và THƯỞNG ĐƠN HÀNG,
 *    xuất riêng ở file Thưởng tài xế — không ảnh hưởng tới lương theo
 *    chấm công / phụ cấp cơm nữa.
 *  - ACCOUNTING / SALES / WAREHOUSE: cũng ngừng mặc định full công —
 *    phải có trong file chấm công chung để được tính ngày công.
 */
export const PAYROLL_DEPARTMENTS = [
  { code: 'FACTORY',    label: 'Xưởng sản xuất', attendanceBased: true,  hasKpiBonus: true  },
  { code: 'ACCOUNTING', label: 'Kế toán',        attendanceBased: true,  hasKpiBonus: true  },
  { code: 'WAREHOUSE',  label: 'Kho',            attendanceBased: true,  hasKpiBonus: true  },
  { code: 'SALES',      label: 'Kinh doanh',     attendanceBased: true,  hasKpiBonus: true  },
  { code: 'DRIVER',     label: 'Tài xế',         attendanceBased: true,  hasKpiBonus: true  },
];

export const factoryPayrollApi = {
  // ── Nhân viên ──────────────────────────────────────────────────────────────

  /** Bộ phận + role nhận lương của tài khoản đang đăng nhập */
  me: () => api.get('/api/factory-payroll/me').then(r),

  /** Tháng có thể chọn — CHỈ các THÁNG ĐÃ QUA. [{month,year,label,attendanceReady,finalized}] */
  periods: () => api.get('/api/factory-payroll/periods').then(r),

  /**
   * Phiếu lương của chính mình cho 1 tháng.
   * status: PROCESSING (chưa Hoàn tất) | NO_SALARY | NO_DEPARTMENT | READY
   */
  myPayslip: (month, year) =>
    api.get('/api/factory-payroll/my-payslip', { params: { month, year } }).then(r),

  // ── Quản trị ───────────────────────────────────────────────────────────────

  /** Danh sách bộ phận kèm số nhân viên */
  departments: () => api.get('/api/factory-payroll/departments').then(r),

  listSheets: (department) =>
    api.get('/api/factory-payroll/sheets', { params: { department } }).then(r),

  uploadablePeriods: (department = 'FACTORY') =>
    api.get('/api/factory-payroll/sheets/periods', { params: { department } }).then(r),

  monthStatus: (month, year, department = 'FACTORY') =>
    api.get('/api/factory-payroll/sheets/status', { params: { month, year, department } }).then(r),

  /** Trạng thái của CẢ 5 bộ phận trong 1 tháng — dựng tab bar 1 lần */
  monthStatusAll: (month, year) =>
    api.get('/api/factory-payroll/sheets/status-all', { params: { month, year } }).then(r),

  // ── Upload 3 loại file (theo bộ phận) ──────────────────────────────────────

  uploadSheet: (file, month, year, department = 'FACTORY') => {
    const fd = new FormData();
    fd.append('file', file);
    return api.post('/api/factory-payroll/sheets/upload', fd, {
      params: { month, year, department },
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then(r);
  },

  uploadExceptions: (file, month, year, department = 'FACTORY') => {
    const fd = new FormData();
    fd.append('file', file);
    return api.post('/api/factory-payroll/exceptions/upload', fd, {
      params: { month, year, department },
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then(r);
  },

  uploadLeaves: (file, month, year, department = 'FACTORY') => {
    const fd = new FormData();
    fd.append('file', file);
    return api.post('/api/factory-payroll/leaves/upload', fd, {
      params: { month, year, department },
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then(r);
  },

  /** Xoá file của tháng. kind: 'attendance' | 'exception' | 'leave' */
  deleteFile: (kind, month, year, department = 'FACTORY') =>
    api.delete(`/api/factory-payroll/files/${kind}`, {
      params: { month, year, department },
    }).then(r),

  // ── Hoàn tất / mở lại ──────────────────────────────────────────────────────

  /** OWNER bấm "Hoàn tất" → nhân viên bộ phận đó xem được phiếu lương */
  finalize: (month, year, department = 'FACTORY') =>
    api.post('/api/factory-payroll/finalize', null, {
      params: { month, year, department },
    }).then(r),

  /** Mở lại tháng đã hoàn tất */
  reopen: (month, year, department = 'FACTORY') =>
    api.post('/api/factory-payroll/reopen', null, {
      params: { month, year, department },
    }).then(r),

  /**
   * OWNER bấm "Hoàn tất KPI / Thưởng" — nhân viên thấy KPI và bonus.
   * Phải gọi SAU khi đã hoàn tất Lương (finalize).
   */
  finalizeKpi: (month, year, department = 'FACTORY') =>
    api.post('/api/factory-payroll/finalize-kpi', null, {
      params: { month, year, department },
    }).then(r),

  /** Mở lại KPI/Thưởng đã hoàn tất — nhân viên quay về "Đang tính thưởng" */
  reopenKpi: (month, year, department = 'FACTORY') =>
    api.post('/api/factory-payroll/reopen-kpi', null, {
      params: { month, year, department },
    }).then(r),

  // ── Thưởng doanh thu (SALES / ACCOUNTING bước 3) ──────────────────────────

  /**
   * Tính và chốt thưởng doanh thu.
   *
   * @param {number} month
   * @param {number} year
   * @param {'SALES'|'ACCOUNTING'} department
   * @param {number|null} unitPrice  Đơn giá hoa hồng (VNĐ cho mỗi 100tr doanh thu).
   *   Flow MỚI (11/2026) luôn truyền số dương. Bỏ trống → BE fallback về tier-based
   *   cũ (giữ tương thích legacy, yêu cầu finalizeKpi trước).
   */
  finalizeBonus: (month, year, department = 'SALES', unitPrice = null) =>
    api.post('/api/factory-payroll/finalize-bonus', null, {
      params: {
        month, year, department,
        ...(unitPrice != null ? { unitPrice } : {}),
      },
    }).then(r),

  /** Mở lại Thưởng — nhân viên quay về "Đang tính thưởng". */
  reopenBonus: (month, year, department = 'SALES') =>
    api.post('/api/factory-payroll/reopen-bonus', null, {
      params: { month, year, department },
    }).then(r),

  /** Lấy kết quả thưởng doanh thu đã tính. */
  officeBonus: (month, year, department = 'SALES') =>
    api.get('/api/factory-payroll/office-bonus', {
      params: { month, year, department },
    }).then(r),

  /**
   * Preview hoa hồng — hoạt động cả khi CHƯA tính và SAU khi đã tính.
   * Response shape:
   *   {
   *     month, year, department, departmentLabel,
   *     totalMonthOrderRevenue, totalCollectedRevenue, totalHoldRevenue,
   *     transactionCount,
   *     commissionCalculated, commissionUnitPrice, lastCommissionUnitPrice,
   *     totalBonusPool, computedAt, computedByName,
   *     items: [{
   *       userId, userFullName, roleLabel, roleSortOrder, weight,
   *       totalMonthOrderRevenue, totalCollectedRevenue, totalHoldRevenue,
   *       transactionCount, bonusAmount  // null = chưa tính
   *     }]
   *   }
   */
  officeBonusPreview: (month, year, department = 'SALES') =>
    api.get('/api/factory-payroll/office-bonus-preview', {
      params: { month, year, department },
    }).then(r),

  /** Đơn giá hoa hồng của tháng gần nhất — dùng làm placeholder ô input. */
  lastCommissionUnitPrice: (month, year, department = 'SALES') =>
    api.get('/api/factory-payroll/office-bonus/last-unit-price', {
      params: { month, year, department },
    }).then(r),

  /**
   * Backfill PaymentTransaction từ order_log — chạy 1 lần sau deploy.
   * @param {object} opts
   * @param {boolean} opts.dryRun  TRUE = chỉ đếm, không ghi (mặc định TRUE)
   * @param {number} [opts.month]  month+year: chỉ backfill 1 tháng (giờ VN)
   * @param {number} [opts.year]
   * @param {number} [opts.fromMs] fromMs+toMs: tùy ý epoch ms
   * @param {number} [opts.toMs]
   */
  backfillPaymentTransactions: (opts = {}) => {
    const { dryRun = true, month, year, fromMs, toMs } = opts;
    return api.post('/api/factory-payroll/payment-transactions/backfill', null, {
      params: {
        dryRun,
        ...(month != null && year != null ? { month, year } : {}),
        ...(fromMs != null && toMs != null ? { fromMs, toMs } : {}),
      },
    }).then(r);
  },


  // ── 2 bảng OWNER xem sau khi Hoàn tất ─────────────────────────────────────

  /** { rows: [...], totalNetSalary, ... } — Phiếu lương + Chi tiết ngày công */
  departmentPayroll: (month, year, department = 'FACTORY') =>
    api.get('/api/factory-payroll/department-payroll', {
      params: { month, year, department },
    }).then(r),

  /** Chi tiết ngày công của 1 nhân viên (OWNER bấm vào 1 dòng) */
  employeeAttendance: (userId, month, year) =>
    api.get('/api/factory-payroll/employee-attendance', {
      params: { userId, month, year },
    }).then(r),

  /** Số km theo ngày của 1 tài xế (OWNER bấm vào 1 dòng) */
  employeeDriver: (userId, month, year) =>
    api.get('/api/factory-payroll/employee-driver', {
      params: { userId, month, year },
    }).then(r),

  /** Chi tiết breakdown lương của 1 user cho tháng — OWNER xem sơ đồ tổ chức. */
  employeeSalaryBreakdown: (userId, month, year) =>
    api.get('/api/factory-payroll/employee-salary-breakdown', {
      params: { userId, month, year },
    }).then(r),

  /** Cấu hình + bảng lương tài xế của tháng (giá xăng, đơn giá thưởng, lương thử). */
  driverConfig: (month, year) =>
    api.get('/api/factory-payroll/driver-config', {
      params: { month, year },
    }).then(r),

  /** Lưu giá xăng + đơn giá thưởng (xe máy & xe tải) cho tháng. */
  saveDriverConfig: (month, year, gasPrice, bonusUnitPrice, truckBonusUnitPrice) =>
    api.post('/api/factory-payroll/driver-config',
      { month, year, gasPrice, bonusUnitPrice, truckBonusUnitPrice }).then(r),

  /** Chi tiết lương 1 tài xế trong tháng (cho modal Tab 2). */
  driverSalaryDetail: (userId, month, year) =>
    api.get('/api/factory-payroll/driver-salary-detail',
      { params: { userId, month, year } }).then(r),

  // ── Thưởng & phụ cấp theo tháng (import Excel) ────────────────────────────

  /** { bonus: n, allowance: n } — số dòng đã import của kỳ THEO BỘ PHẬN */
  adjustmentStatus: (month, year, department) =>
    api.get('/api/factory-payroll/adjustments/status', { params: { month, year, department } }).then(r),

  uploadBonus: (file, month, year, department) => {
    const fd = new FormData();
    fd.append('file', file);
    return api.post('/api/factory-payroll/bonus/upload', fd, {
      params: { month, year, department },
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then(r);
  },

  uploadAllowance: (file, month, year, department) => {
    const fd = new FormData();
    fd.append('file', file);
    return api.post('/api/factory-payroll/allowance/upload', fd, {
      params: { month, year, department },
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then(r);
  },

  /** type: 'BONUS' | 'ALLOWANCE' */
  clearAdjustments: (type, month, year, department) =>
    api.delete(`/api/factory-payroll/adjustments/${type}`,
      { params: { month, year, department } }).then(r),

  /** Danh sách nhân sự của bộ phận — modal "Chi tiết bộ phận". */
  departmentMembers: (department) =>
    api.get(`/api/factory-payroll/departments/${department}/members`).then(r),

  bonusBatches: (month, year, department) =>
    api.get('/api/factory-payroll/adjustments/bonus/batches',
      { params: { month, year, department } }).then(r),

  /** Xoá ĐÚNG MỘT khoản thưởng (trong bộ phận nếu chỉ định). */
  clearBonusLabel: (month, year, label, department) =>
    api.delete('/api/factory-payroll/adjustments/bonus',
      { params: { month, year, label, department } }).then(r),

  /** PREVIEW dữ liệu đã import — trả về bảng để OWNER xem lại (không sửa). */
  adjustmentPreview: (month, year, type, { label, department } = {}) =>
    api.get('/api/factory-payroll/adjustments/preview',
      { params: { month, year, type, label, department } }).then(r),

  // ── File mẫu ───────────────────────────────────────────────────────────────

  /** kind: 'exception' | 'leave' | 'bonus' | 'allowance' */
  downloadTemplate: async (kind, month, year, department = 'FACTORY') => {
    const res = await api.get(`/api/factory-payroll/templates/${kind}`, {
      params: { month, year, department },
      responseType: 'blob',
    });
    const mm = String(month).padStart(2, '0');
    const PREFIX = {
      exception: 'lich-nghi',
      leave: 'don-xin-nghi',
      bonus: 'thuong',
      allowance: 'phu-cap',
    };
    const name = `${PREFIX[kind] || kind}-${department}-${mm}-${year}.xlsx`;
    const url = window.URL.createObjectURL(new Blob([res.data]));
    const a = document.createElement('a');
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click();
    a.remove(); window.URL.revokeObjectURL(url);
  },

  // ── KPI (chỉ bộ phận Xưởng) ───────────────────────────────────────────────

  kpi: (month, year) =>
    api.get('/api/factory-payroll/kpi', { params: { month, year } }).then(r),

  /**
   * Tính lại thưởng KPI xưởng.
   * securityRate = mức thưởng cố định cho MỘT bảo vệ xưởng. Bỏ trống thì backend
   * giữ nguyên mức đã dùng cho tháng đó (đừng gửi 0 nếu chỉ muốn giữ nguyên).
   */
  recomputeKpi: (month, year, securityRate) =>
    api.post('/api/factory-payroll/kpi/recompute', null, {
      params: { month, year, ...(securityRate != null ? { securityRate } : {}) },
    }).then(r),

  // ── Quỹ dư KPI khai báo tay ───────────────────────────────────────────────
  //
  // Dùng khi tháng trước đã chia thưởng NGOÀI app và còn dư: hệ thống không có
  // bản ghi nào của tháng đó để kế thừa sổ dư, nên phải khai báo tay.
  // Khai báo xong PHẢI bấm "Tính lại thưởng KPI" thì quỹ mới được cộng vào.

  carryOverSeeds: (month, year) =>
    api.get('/api/factory-payroll/kpi/carry-over-seeds', {
      params: (month != null && year != null) ? { month, year } : {},
    }).then(r),

  addCarryOverSeed: (payload) =>
    api.post('/api/factory-payroll/kpi/carry-over-seeds', payload).then(r),

  deleteCarryOverSeed: (id) =>
    api.delete(`/api/factory-payroll/kpi/carry-over-seeds/${id}`).then(r),

  // ── Export file lương tổng hợp (OWNER/ADMIN) ─────────────────────────────

  /**
   * departments: ['MANAGEMENT','ACCOUNTING','FACTORY','SALES','WAREHOUSE']
   * exportType: 'SALARY_ONLY' | 'BONUS_ONLY' | 'SALARY_AND_BONUS'
   */
  exportSalaryReport: async (month, year, departments, exportType) => {
    const res = await api.post(
      '/api/factory-payroll/salary-export',
      { departments, exportType },
      { params: { month, year }, responseType: 'blob' },
    );
    const typeSlug = exportType === 'BONUS_ONLY' ? 'thuong'
      : exportType === 'SALARY_ONLY' ? 'luong' : 'luong-thuong';
    const mm = String(month).padStart(2, '0');
    const name = `bang-${typeSlug}-thang-${mm}-${year}.xlsx`;
    const url = window.URL.createObjectURL(new Blob([res.data]));
    const a = document.createElement('a');
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click();
    a.remove(); window.URL.revokeObjectURL(url);
  },

  /**
   * Xuất file "DANH SÁCH CHI LƯƠNG" theo mẫu NGÂN HÀNG (1 sheet NHẤT NAM,
   * 5 cột: STT · Họ tên · Số TK · Ngân hàng · Số tiền). Cột Số tiền = lương
   * thực nhận không thưởng (base + phụ cấp). Số TK / Ngân hàng để trống, quản
   * lý điền tay trước khi gửi ngân hàng.
   */
  exportBankPayment: async (month, year) => {
    const res = await api.get('/api/factory-payroll/bank-payment-export', {
      params: { month, year }, responseType: 'blob',
    });
    const mm = String(month).padStart(2, '0');
    const name = `danh-sach-chi-luong-thang-${mm}-${year}.xlsx`;
    const url = window.URL.createObjectURL(new Blob([res.data]));
    const a = document.createElement('a');
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click();
    a.remove(); window.URL.revokeObjectURL(url);
  },
};

export default factoryPayrollApi;