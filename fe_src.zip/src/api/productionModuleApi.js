// src/api/productionModuleApi.js
// API client cho Production Module v2
import api from './axios';

// ── Upload helper ─────────────────────────────────────────────────────────────
async function uploadFiles(endpoint, params, files) {
  const form = new FormData();
  Object.entries(params).forEach(([k, v]) => form.append(k, v));
  files.forEach(f => form.append('files', f));
  const res = await api.post(endpoint, form, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return res.data.data; // List<String> URLs
}

// ── Owner APIs ────────────────────────────────────────────────────────────────

export const ownerProdApi = {
  // Dashboard
  getDashboard: () =>
    api.get('/api/owner/production/dashboard').then(r => r.data.data),

  // Plans
  listPlans: (page = 0, size = 20, status) =>
    api.get('/api/owner/production/plans', { params: { page, size, status } }).then(r => r.data.data),
  getPlan: (id) =>
    api.get(`/api/owner/production/plans/${id}`).then(r => r.data.data),
  listPlanWorkOrders: (planId) =>
    api.get(`/api/owner/production/plans/${planId}/work-orders`).then(r => r.data.data),
  createPlan: (body) =>
    api.post('/api/owner/production/plans', body).then(r => r.data.data),
  updatePlanStatus: (id, status) =>
    api.patch(`/api/owner/production/plans/${id}/status`, null, { params: { status } }).then(r => r.data.data),

  // Work Orders
  listWorkOrders: (page = 0, size = 20, status) =>
    api.get('/api/owner/production/work-orders', { params: { page, size, status } }).then(r => r.data.data),
  getWorkOrderDetail: (id) =>
    api.get(`/api/owner/production/work-orders/${id}`).then(r => r.data.data),
  createWorkOrder: (body) =>
    api.post('/api/owner/production/work-orders', body).then(r => r.data.data),
  extendWorkOrder: (id, body) =>
    api.patch(`/api/owner/production/work-orders/${id}/extend`, body).then(r => r.data.data),
  updateWorkOrderStatus: (id, body) =>
    api.patch(`/api/owner/production/work-orders/${id}/status`, body).then(r => r.data.data),

  // Machines
  listMachines: (activeOnly = false) =>
    api.get('/api/owner/production/machines', { params: { activeOnly } }).then(r => r.data.data),
  createMachine: (body) =>
    api.post('/api/owner/production/machines', body).then(r => r.data.data),
  updateMachine: (id, body) =>
    api.put(`/api/owner/production/machines/${id}`, body).then(r => r.data.data),
  toggleMachine: (id, active) =>
    api.patch(`/api/owner/production/machines/${id}/toggle`, null, { params: { active } }).then(r => r.data.data),

  // Maintenance
  listMaintenance: (year, machineId) =>
    api.get('/api/owner/production/maintenance', { params: { year, machineId } }).then(r => r.data.data),

  // Machine occupancy (WorkOrder/Batch đang chiếm máy) — cho Gantt sọc chéo xanh dương
  listMachineOccupancy: (fromMs, toMs) =>
    api.get('/api/owner/production/machine-occupancy', { params: { fromMs, toMs } }).then(r => r.data.data),

  // Factories (xưởng)
  listFactories: () =>
    api.get('/api/owner/production/factories').then(r => r.data.data),
  createFactory: (body) =>
    api.post('/api/owner/production/factories', body).then(r => r.data.data),
  updateFactoryManagers: (id, body) =>
    api.patch(`/api/owner/production/factories/${id}/managers`, body).then(r => r.data.data),
  toggleFactory: (id, active) =>
    api.patch(`/api/owner/production/factories/${id}/toggle`, null, { params: { active } }).then(r => r.data.data),
};

// ── Factory Worker APIs ───────────────────────────────────────────────────────

export const factoryProdApi = {
  // Work Orders — xem theo xưởng (không lọc theo user nữa)
  listMyOrders: (factoryId) =>
    api.get('/api/factory/work-orders', { params: factoryId ? { factoryId } : {} }).then(r => r.data.data),
  listMyFactories: () =>
    api.get('/api/factory/my-factories').then(r => r.data.data),
  getOrderDetail: (id) =>
    api.get(`/api/factory/work-orders/${id}`).then(r => r.data.data),

  // Biến thể sản xuất — lọc theo FactoryProduct của lệnh để chọn khi lập phương án
  listRecipesByProduct: (factoryProductId) =>
    api.get('/api/factory/recipes', { params: factoryProductId ? { productId: factoryProductId } : {} }).then(r => r.data.data),

  // Lập phương án theo Biến thể sản xuất (chọn biến thể + nhập sản lượng cần SX)
  previewPlan: (workOrderId, recipeId, requestedQty) =>
    api.get(`/api/factory/work-orders/${workOrderId}/plan-preview`, { params: { recipeId, requestedQty } }).then(r => r.data.data),
  submitPlanByRecipe: (workOrderId, body) =>
    api.post(`/api/factory/work-orders/${workOrderId}/plan-by-recipe`, body).then(r => r.data.data),

  // Bắt đầu sản xuất
  startOrder: (workOrderId) =>
    api.post(`/api/factory/work-orders/${workOrderId}/start`).then(r => r.data.data),

  // Batch operations
  startBatch: (body) =>
    api.post('/api/factory/batches/start', body).then(r => r.data.data),
  startStep: (batchId, stepSeq, body) =>
    api.post(`/api/factory/batches/${batchId}/steps/${stepSeq}/start`, body || {}).then(r => r.data.data),
  completeStep: (batchId, stepSeq, body) =>
    api.post(`/api/factory/batches/${batchId}/steps/${stepSeq}/complete`, body).then(r => r.data.data),
  completeBatch: (batchId, body) =>
    api.post(`/api/factory/batches/${batchId}/complete`, body).then(r => r.data.data),
  // Công đoạn cấp lệnh (bước chung / bước riêng)
  startStageRun: (stepId, body) =>
    api.post(`/api/factory/work-order-steps/${stepId}/start`, body || {}).then(r => r.data.data),
  completeStageRun: (stepId, body) =>
    api.post(`/api/factory/work-order-steps/${stepId}/complete`, body).then(r => r.data.data),
  cancelBatch: (batchId, body) =>
    api.post(`/api/factory/batches/${batchId}/cancel`, body).then(r => r.data.data),
  // Danh sách NVL đã trừ kho (chưa hoàn) của lệnh sản xuất — dùng cho form huỷ mẻ
  getMaterialUsage: (workOrderId) =>
    api.get(`/api/factory/work-orders/${workOrderId}/material-usage`).then(r => r.data.data),


  // Material Vendors (NCC nguyên liệu / máy móc / sửa chữa)
  listVendors: (q = '', types = '') =>
    api.get('/api/factory/material-vendors', { params: { ...(q?{q}:{}), ...(types?{types}:{}) } }).then(r => r.data.data),
  createVendor: (body) =>
    api.post('/api/factory/material-vendors', body).then(r => r.data.data),
  updateVendor: (id, body) =>
    api.put(`/api/factory/material-vendors/${id}`, body).then(r => r.data.data),
  deleteVendor: (id) =>
    api.delete(`/api/factory/material-vendors/${id}`).then(r => r.data.data),

  // Machines
  listMachines: () =>
    api.get('/api/factory/machines').then(r => r.data.data),
  createMachine: (body) =>
    api.post('/api/factory/machines', body).then(r => r.data.data),
  getMachineMetrics: (id) =>
    api.get(`/api/factory/machines/${id}/metrics`).then(r => r.data.data),

  // Maintenance
  listMaintenance: (year) =>
    api.get('/api/factory/maintenance', { params: { year } }).then(r => r.data.data),
  createMaintenance: (body) =>
    api.post('/api/factory/maintenance', body).then(r => r.data.data),
  completeMaintenance: (id, body) =>
    api.patch(`/api/factory/maintenance/${id}/complete`, body).then(r => r.data.data),
  deleteMaintenance: (id) =>
    api.delete(`/api/factory/maintenance/${id}`).then(r => r.data.data),

  // Preset bước sản xuất (BatchStepTemplate)
  listStepTemplates: () =>
    api.get('/api/factory/step-templates').then(r => r.data.data),
  createStepTemplate: (body) =>
    api.post('/api/factory/step-templates', body).then(r => r.data.data),
};

// ── Finished Goods Warehouse APIs (Kho thành phẩm — Issue #1 + #2) ─────────────

// ── Mix gia vị (Mục 4) ───────────────────────────────────────────────────────
export const mixApi = {
  listOutputs: (factoryId) =>
    api.get('/api/factory/mix/outputs', { params: { factoryId } }).then(r => r.data.data),
  check: (payload) => api.post('/api/factory/mix/check', payload).then(r => r.data.data),
  execute: (payload) => api.post('/api/factory/mix/execute', payload).then(r => r.data.data),
};

// ── Kho nguyên liệu xưởng: xuất / chuyển kho (Mục 2) ─────────────────────────
export const factoryStockApi = {
  // Kho đích: kho bán/trung chuyển + kho NL xưởng khác + kho TP xưởng khác
  listTransferTargets: (factoryId) =>
    api.get('/api/factory/material-stock/transfer-targets', { params: { factoryId } }).then(r => r.data.data),
  // Nguyên liệu chuyển được sang kho đích (chỉ cái kho đích đang có, trùng tên)
  listTransferable: (factoryId, targetKey) =>
    api.get('/api/factory/material-stock/transferable', { params: { factoryId, targetKey } }).then(r => r.data.data),
  exportStock: (payload) =>
    api.post('/api/factory/material-stock/export', payload).then(r => r.data.data),
  transferStock: (payload) =>
    api.post('/api/factory/material-stock/transfer', payload).then(r => r.data.data),
  listNotes: (factoryId, type) =>
    api.get('/api/factory/material-stock/notes', { params: { factoryId, type } }).then(r => r.data.data),
};

export const finishedGoodsApi = {  // Danh sách tổng hợp theo Tên thành phẩm — search + filter cận date + LỌC THEO XƯỞNG (server-side)
  listSummary: (q, expiryBeforeMs, factoryId) =>
    api.get('/api/factory/finished-goods', { params: { q, expiryBeforeMs, factoryId } }).then(r => r.data.data),
  // Danh sách kho bán hàng (loại SALE) — legacy, giữ cho tương thích
  listSaleWarehouses: () =>
    api.get('/api/factory-accountant/finished-goods/sale-warehouses').then(r => r.data.data),
  // Kho đích khi chuyển kho: Kho bán + Trung chuyển (kèm typeLabel để hiện "Tên kho — Loại kho")
  listTransferTargets: () =>
    api.get('/api/factory-accountant/finished-goods/transfer-targets').then(r => r.data.data),
  // Thành phẩm chuyển được sang kho đích — CHỈ những cái kho đích đang có nguyên liệu trùng tên
  listTransferable: (factoryId, targetWarehouseId) =>
    api.get('/api/factory-accountant/finished-goods/transferable',
      { params: { factoryId, targetWarehouseId } }).then(r => r.data.data),
  // Xuất kho — cần lý do (chỉ FACTORY_ACCOUNTANT)
  exportGoods: (body) =>
    api.post('/api/factory-accountant/finished-goods/export', body).then(r => r.data.data),
  // Chuyển kho — cần kho đích (kho bán hàng), tự chuyển ngày SX + HSD (chỉ FACTORY_ACCOUNTANT)
  transferGoods: (body) =>
    api.post('/api/factory-accountant/finished-goods/transfer', body).then(r => r.data.data),
  // Lịch sử giao dịch xuất/chuyển kho (chỉ FACTORY_ACCOUNTANT)
  listTransactions: (productName, page = 0, size = 20) =>
    api.get('/api/factory-accountant/finished-goods/transactions', { params: { productName, page, size } }).then(r => r.data.data),
};

// ── Kho bán thành phẩm + Kho Scrap + Phiếu chuyển kho + Biên bản hao hụt ──────
// (quy trình "đóng gói & hao hụt" 4 bước)

export const semiFinishedGoodsApi = {
  // Bước 1 — xem tồn kho bán thành phẩm (mọi role liên quan xem được)
  listSummary: (q, factoryId) =>
    api.get('/api/factory/semi-finished-goods', { params: { q, factoryId } }).then(r => r.data.data),
  // Bước 1 — xem kho Scrap (hàng lỗi)
  listScrap: (page = 0, size = 20) =>
    api.get('/api/factory/scrap-stock', { params: { page, size } }).then(r => r.data.data),
  // Bước 2 — Trưởng xưởng/NV xưởng lập phiếu chuyển kho bán TP → kho TP
  createTransfer: (body) =>
    api.post('/api/factory/semi-finished-transfers', body).then(r => r.data.data),
  listTransfers: (status, page = 0, size = 20) =>
    api.get('/api/factory/semi-finished-transfers', { params: { status, page, size } }).then(r => r.data.data),
  getTransfer: (id) =>
    api.get(`/api/factory/semi-finished-transfers/${id}`).then(r => r.data.data),
  // Bước 3+4 — FACTORY_ACCOUNTANT xác nhận nhận → tự tính hao hụt
  listTransfersForAccountant: (status, page = 0, size = 20) =>
    api.get('/api/factory-accountant/semi-finished-transfers', { params: { status, page, size } }).then(r => r.data.data),
  getTransferForAccountant: (id) =>
    api.get(`/api/factory-accountant/semi-finished-transfers/${id}`).then(r => r.data.data),
  confirmReceive: (id, body) =>
    api.post(`/api/factory-accountant/semi-finished-transfers/${id}/receive`, body).then(r => r.data.data),
  // Biên bản hao hụt đóng gói
  listLossReportsForAccountant: (productName, page = 0, size = 20) =>
    api.get('/api/factory-accountant/packaging-loss-reports', { params: { productName, page, size } }).then(r => r.data.data),
  listLossReportsForOwner: (productName, page = 0, size = 20) =>
    api.get('/api/owner/production/packaging-loss-reports', { params: { productName, page, size } }).then(r => r.data.data),
  // Xuất Excel 3 biểu mẫu (trả về blob — FE tự tạo link tải xuống)
  exportTransferOut: (id) =>
    api.get(`/api/factory/semi-finished-transfers/${id}/export-out`, { responseType: 'blob' }),
  exportTransferIn: (id) =>
    api.get(`/api/factory-accountant/semi-finished-transfers/${id}/export-in`, { responseType: 'blob' }),
  exportLossReportForAccountant: (id) =>
    api.get(`/api/factory-accountant/packaging-loss-reports/${id}/export`, { responseType: 'blob' }),
  exportLossReportForOwner: (id) =>
    api.get(`/api/owner/production/packaging-loss-reports/${id}/export`, { responseType: 'blob' }),
};

// ⚠️ CHỈ DÙNG TRONG MÔI TRƯỜNG TEST — xoá sạch + khởi tạo lại dữ liệu module
// sản xuất. Hành động KHÔNG THỂ HOÀN TÁC. Xem ProductionResetController phía
// backend để biết chi tiết phạm vi & thứ tự xoá. Xoá khối này (và nút bấm
// tương ứng ở UI) trước khi deploy lên môi trường có dữ liệu thật.
export const productionResetApi = {
  resetOnly: () => api.post('/api/owner/production-reset/reset-only').then(r => r.data.data),
  resetAndSeed: () => api.post('/api/owner/production-reset/reset-and-seed').then(r => r.data.data),
};

// ── Upload APIs ───────────────────────────────────────────────────────────────

export const productionUploadApi = {
  uploadBatchStepImages: (batchId, stepSeq, files) =>
    uploadFiles('/api/upload/production/batch-step', { batchId, stepSeq }, files),
  uploadWorkOrderStepImages: (stepId, files) =>
    uploadFiles('/api/upload/production/work-order-step', { stepId }, files),
  uploadBatchCancelImages: (batchId, files) =>
    uploadFiles('/api/upload/production/batch-cancel', { batchId }, files),
  uploadMaintenanceBefore: (maintenanceId, files) =>
    uploadFiles('/api/upload/production/maintenance-before', { maintenanceId }, files),
  uploadMaintenanceAfter: (maintenanceId, files) =>
    uploadFiles('/api/upload/production/maintenance-after', { maintenanceId }, files),
  uploadMaintenanceReceipt: (maintenanceId, files) =>
    uploadFiles('/api/upload/production/maintenance-receipt', { maintenanceId }, files),
  uploadMaterialInvoice: (workOrderId, files) =>
    uploadFiles('/api/upload/production/material-invoice', { workOrderId }, files),
};

// ── Shared helpers ────────────────────────────────────────────────────────────

// ── Trạng thái: TÁCH màu (STATUS_META) khỏi nhãn (dịch qua t) ─────────────────
// Không hard-code label tiếng Việt ở đây nữa.
export const STATUS_META = {
  SCHEDULED:    { key: 'status_scheduled',    cls: 'bg-blue-100 text-blue-700',      dot: 'bg-blue-400' },
  PENDING_PLAN: { key: 'status_pending_plan', cls: 'bg-amber-100 text-amber-700',    dot: 'bg-amber-400' },
  PLANNED:      { key: 'status_planned',      cls: 'bg-indigo-100 text-indigo-700',  dot: 'bg-indigo-400' },
  IN_PROGRESS:  { key: 'status_in_progress',  cls: 'bg-orange-100 text-orange-700',  dot: 'bg-orange-400' },
  COMPLETED:    { key: 'status_completed',    cls: 'bg-emerald-100 text-emerald-700',dot: 'bg-emerald-400' },
  CANCELLED:    { key: 'status_cancelled',    cls: 'bg-red-100 text-red-600',        dot: 'bg-red-400' },
  ACTIVE:       { key: 'status_active',       cls: 'bg-emerald-100 text-emerald-700',dot: 'bg-emerald-400' },
};

// Dùng TRONG component: const STATUS = getStatusLabels(t);
export const getStatusLabels = (t) =>
  Object.fromEntries(
    Object.entries(STATUS_META).map(([code, m]) => [
      code,
      { ...m, label: t('production', m.key) },
    ])
  );

// Màu progress bar / Gantt theo % tiến độ
export function progressColor(pct) {
  const v = Number(pct || 0);
  if (v > 100) return { bg: 'bg-emerald-700', text: 'text-emerald-700', hex: '#047857' };
  if (v >= 100) return { bg: 'bg-emerald-500', text: 'text-emerald-600', hex: '#10b981' };
  if (v >= 75)  return { bg: 'bg-lime-500',    text: 'text-lime-600',    hex: '#84cc16' };
  if (v >= 50)  return { bg: 'bg-yellow-400',  text: 'text-yellow-600',  hex: '#facc15' };
  if (v >= 25)  return { bg: 'bg-orange-400',  text: 'text-orange-600',  hex: '#fb923c' };
  return             { bg: 'bg-red-400',      text: 'text-red-600',     hex: '#f87171' };
}

/** @deprecated dùng useFmt() để format theo ngôn ngữ đang chọn */
export const fmtDate = (ms) =>
  ms ? new Date(Number(ms)).toLocaleDateString('vi-VN', { day:'2-digit', month:'2-digit', year:'numeric' }) : '—';

/** @deprecated dùng useFmt() */
export const fmtNum = (v) =>
  new Intl.NumberFormat('vi-VN').format(Number(v || 0));

/** @deprecated dùng useFmt() */
export const fmtCurrency = (v) =>
  new Intl.NumberFormat('vi-VN').format(Math.round(Number(v || 0))) + '₫';