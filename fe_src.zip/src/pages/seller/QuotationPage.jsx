import { useLang } from '../../context/LangContext';
import { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import {
  Search, Trash2, X, FileText, ChevronDown, ArrowUpDown, ArrowUp, ArrowDown,
  Plus, Check, PackageX,
} from 'lucide-react';
import { productApi, categoryApi, downloadBlob, quotationApi } from '../../api/services';
import { useToast } from '../../components/common/Toast';
import { useAuth } from '../../context/AuthContext';

const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080';

const VAT_RATES = [0, 5, 8, 10, 12];

// ── Helpers ────────────────────────────────────────────────────────────────
const normalize = (str) =>
  (str || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

/** Làm tròn đến hàng đơn vị (Math.round) */
const roundUnit = (n) => Math.round(n);

/** Format số VND */
const fmt = (n) =>
  new Intl.NumberFormat('vi-VN').format(roundUnit(n || 0)) + ' đ';

/**
 * Tính giá trước thuế và giá sau thuế từ giá chọn + VAT config
 * INCLUSIVE: giá chọn = giá SAU thuế → giá TRƯỚC thuế = price / (1 + rate/100)
 * EXCLUSIVE: giá chọn = giá TRƯỚC thuế → giá SAU thuế = price * (1 + rate/100)
 */
function calcPrices(price, vatRate, vatMode) {
  const rate = vatRate ?? 0;
  const mode = vatMode ?? 'INCLUSIVE';
  if (rate === 0) return { preTax: roundUnit(price), postTax: roundUnit(price) };
  if (mode === 'INCLUSIVE') {
    const preTax = price / (1 + rate / 100);
    return { preTax: roundUnit(preTax), postTax: roundUnit(price) };
  }
  // EXCLUSIVE
  const postTax = price * (1 + rate / 100);
  return { preTax: roundUnit(price), postTax: roundUnit(postTax) };
}

function getImgSrc(url) {
  if (!url) return null;
  if (url.startsWith('http')) return url;
  return `${BASE_URL}/api/auth${url}`;
}

let idCounter = 0;
const newId = () => ++idCounter;

// ── PricePickerModal ───────────────────────────────────────────────────────
// Hiện khi click sản phẩm: chọn giá, VAT rate, VAT mode
function PricePickerModal({ product, existing, onConfirm, onClose }) {
  const hasTiers = product.priceTiers && product.priceTiers.length > 0;

  const [selectedTierId, setSelectedTierId] = useState(existing?.tierId ?? null);
  const [vatRate, setVatRate] = useState(existing?.vatRate ?? (product.vatRate ?? 0));
  const [vatMode, setVatMode] = useState(existing?.vatMode ?? (product.vatMode ?? 'INCLUSIVE'));
  // Sửa giá: khi bật, dùng giá tự nhập thay cho giá lẻ/khung
  const [useCustom, setUseCustom] = useState(existing?.isCustomPrice ?? false);
  const [customPrice, setCustomPrice] = useState(
    existing?.isCustomPrice ? String(existing.unitPrice ?? '') : ''
  );

  // Giá đang chọn
  const selectedPrice = useMemo(() => {
    if (useCustom) return Number(customPrice) || 0;
    if (selectedTierId !== null) {
      const tier = product.priceTiers?.find(t => t.id === selectedTierId);
      return tier?.price ?? product.basePrice ?? 0;
    }
    return product.basePrice ?? 0;
  }, [useCustom, customPrice, selectedTierId, product]);

  const { preTax, postTax } = useMemo(
    () => calcPrices(selectedPrice, vatRate, vatMode),
    [selectedPrice, vatRate, vatMode]
  );

  const handleConfirm = () => {
    if (useCustom && (!customPrice || Number(customPrice) <= 0)) return;
    onConfirm({
      tierId: useCustom ? null : selectedTierId,
      vatRate, vatMode,
      unitPrice: selectedPrice,
      isCustomPrice: useCustom,
    });
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-surface rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden animate-fadeIn">
        {/* Header */}
        <div className="bg-gradient-to-r from-gold to-gold-strong px-5 py-4 flex items-center justify-between">
          <div className="flex-1 min-w-0">
            <p className="text-white/70 text-[10px] uppercase tracking-widest font-semibold">Chọn giá & VAT</p>
            <h3 className="text-white font-bold text-sm mt-0.5 truncate">{product.name}</h3>
          </div>
          <button onClick={onClose}
            className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center text-white hover:bg-white/30 shrink-0 ml-2">
            <X size={14} />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Chọn giá */}
          <div>
            <p className="text-[11px] font-bold text-muted uppercase tracking-wider mb-2">Loại giá</p>
            <div className="space-y-2">
              {/* Giá lẻ */}
              <button
                onClick={() => { setSelectedTierId(null); setUseCustom(false); }}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border-2 transition-all
                  ${!useCustom && selectedTierId === null
                    ? 'border-sky-400 bg-sky-50 dark:bg-sky-500/10'
                    : 'border-line hover:border-sky-300 dark:border-sky-500/35 hover:bg-sky-50/40 dark:bg-sky-500/4'}`}
              >
                <div className="flex items-center gap-2">
                  {!useCustom && selectedTierId === null && <Check size={13} className="text-sky-500" />}
                  <span className="text-sm font-semibold text-ink">Giá lẻ</span>
                </div>
                <span className="text-sm font-bold text-sky-600 dark:text-sky-300">{fmt(product.basePrice)}</span>
              </button>

              {/* Các tier */}
              {hasTiers && product.priceTiers
                .slice().sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0))
                .map((tier, idx) => (
                  <button
                    key={tier.id}
                    onClick={() => { setSelectedTierId(tier.id); setUseCustom(false); }}
                    className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border-2 transition-all
                      ${!useCustom && selectedTierId === tier.id
                        ? 'border-orange-400 bg-orange-50 dark:bg-orange-500/10'
                        : 'border-line hover:border-orange-300 dark:border-orange-500/35 hover:bg-orange-50/40 dark:bg-orange-500/4'}`}
                  >
                    <div className="flex items-center gap-2">
                      {!useCustom && selectedTierId === tier.id && <Check size={13} className="text-orange-500" />}
                      <span className="text-sm font-semibold text-ink">
                        {tier.tierName || `Sỉ ${idx + 1}`}
                      </span>
                      <span className="text-[10px] text-muted">
                        {tier.minQuantity ?? 0}{tier.maxQuantity ? `–${tier.maxQuantity}` : '+'}
                      </span>
                    </div>
                    <span className="text-sm font-bold text-orange-600 dark:text-orange-300">{fmt(tier.price)}</span>
                  </button>
                ))
              }

              {/* Giá tùy chỉnh (sửa giá) */}
              <button
                onClick={() => setUseCustom(true)}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border-2 transition-all
                  ${useCustom
                    ? 'border-emerald-400 bg-emerald-50 dark:bg-emerald-500/10'
                    : 'border-line hover:border-emerald-300 dark:border-emerald-500/35 hover:bg-emerald-50/40 dark:bg-emerald-500/4'}`}
              >
                <div className="flex items-center gap-2">
                  {useCustom && <Check size={13} className="text-emerald-500" />}
                  <span className="text-sm font-semibold text-ink">Giá tùy chỉnh</span>
                </div>
                <span className="text-[10px] text-muted">Tự nhập giá</span>
              </button>
              {useCustom && (
                <div className="px-1 pt-1">
                  <input
                    type="number" min="0" step="1000" autoFocus
                    value={customPrice}
                    onChange={e => setCustomPrice(e.target.value)}
                    placeholder="Nhập giá (đ)"
                    className="w-full px-4 py-2.5 rounded-xl border-2 border-emerald-300 dark:border-emerald-500/35 text-sm font-semibold text-right
                      focus:outline-none focus:border-emerald-500 bg-emerald-50/40 dark:bg-emerald-500/4"
                  />
                  {(!customPrice || Number(customPrice) <= 0) && (
                    <p className="text-[11px] text-red-500 mt-1 ml-1">Vui lòng nhập giá lớn hơn 0</p>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* VAT Rate */}
          <div>
            <p className="text-[11px] font-bold text-muted uppercase tracking-wider mb-2">Tỷ suất VAT</p>
            <div className="flex gap-1.5 flex-wrap">
              {VAT_RATES.map(r => (
                <button
                  key={r}
                  onClick={() => setVatRate(r)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors
                    ${vatRate === r
                      ? 'bg-gold text-white border-gold'
                      : 'bg-surface text-muted border-line hover:border-gold'}`}
                >
                  {r}%
                </button>
              ))}
            </div>
          </div>

          {/* VAT Mode */}
          <div>
            <p className="text-[11px] font-bold text-muted uppercase tracking-wider mb-2">Loại VAT</p>
            <div className="flex rounded-xl border border-line overflow-hidden text-xs">
              {[
                ['INCLUSIVE', 'Trong giá'],
                ['EXCLUSIVE', 'Ngoài giá'],
              ].map(([val, label], i) => (
                <button
                  key={val}
                  onClick={() => setVatMode(val)}
                  className={`flex-1 py-2 font-semibold transition-colors
                    ${i > 0 ? 'border-l border-line' : ''}
                    ${vatMode === val ? 'bg-gold text-white' : 'text-muted hover:bg-surface-2'}`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Preview tính toán */}
          <div className="bg-canvas rounded-xl p-3 border border-line-soft space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-muted">Giá trước thuế</span>
              <span className="font-semibold text-ink">{fmt(preTax)}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-muted">VAT ({vatRate}% — {vatMode === 'INCLUSIVE' ? 'trong giá' : 'ngoài giá'})</span>
              <span className="font-semibold text-gold">{fmt(postTax - preTax)}</span>
            </div>
            <div className="flex justify-between text-xs pt-1 border-t border-line">
              <span className="text-muted">Giá sau thuế</span>
              <span className="font-bold text-ink">{fmt(postTax)}</span>
            </div>
          </div>
        </div>

        <div className="px-4 pb-4 flex gap-2">
          <button onClick={onClose}
            className="flex-1 py-2.5 rounded-xl border border-line text-muted text-sm font-medium hover:bg-surface-2 transition-colors">
            Huỷ
          </button>
          <button onClick={handleConfirm}
            disabled={useCustom && (!customPrice || Number(customPrice) <= 0)}
            className="flex-1 py-2.5 rounded-xl bg-gold text-white text-sm font-bold hover:bg-gold-strong transition-colors disabled:opacity-40 disabled:cursor-not-allowed">
            {existing ? 'Cập nhật' : 'Thêm vào báo giá'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── QuotationCartItem ──────────────────────────────────────────────────────
function QuotationCartItem({ item, onEdit, onRemove }) {
  const { preTax, postTax } = calcPrices(item.unitPrice, item.vatRate, item.vatMode);
  const tierLabel = item.isCustomPrice
    ? 'Giá tùy chỉnh'
    : item.tierId
      ? (item.tierName || 'Giá sỉ')
      : 'Giá lẻ';

  return (
    <div className="flex items-start gap-3 py-3 border-b border-line-soft last:border-0">
      {/* Ảnh */}
      <div className="w-10 h-10 rounded-lg bg-surface-2 overflow-hidden shrink-0 mt-0.5">
        {getImgSrc(item.productImageUrl)
          ? <img src={getImgSrc(item.productImageUrl)} alt={item.productName} className="w-full h-full object-cover" />
          : <div className="w-full h-full flex items-center justify-center text-base">🍽️</div>
        }
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <p className="text-xs font-semibold text-ink truncate">{item.productName}</p>

        {/* Badges */}
        <div className="flex items-center gap-1 flex-wrap mt-0.5">
          <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-semibold border
            ${item.tierId
              ? 'bg-orange-50 dark:bg-orange-500/10 text-orange-700 dark:text-orange-300 border-orange-200 dark:border-orange-500/28'
              : 'bg-sky-50 dark:bg-sky-500/10 text-sky-700 dark:text-sky-300 border-sky-200 dark:border-sky-500/28'}`}>
            {tierLabel}
          </span>
          <span className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold border bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-500/28">
            VAT {item.vatRate}%
          </span>
          <span className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold border bg-surface-2 text-muted border-line">
            {item.vatMode === 'INCLUSIVE' ? 'Trong giá' : 'Ngoài giá'}
          </span>
        </div>

        {/* Giá */}
        <div className="mt-1 space-y-0.5">
          <div className="flex justify-between text-[10px]">
            <span className="text-muted">Trước thuế</span>
            <span className="font-semibold text-ink">{fmt(preTax)}</span>
          </div>
          <div className="flex justify-between text-[10px]">
            <span className="text-muted">Sau thuế</span>
            <span className="font-bold text-gold">{fmt(postTax)}</span>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-col items-end gap-1.5 shrink-0">
        <button onClick={() => onRemove(item.id)}
          className="w-5 h-5 rounded-full text-faint hover:text-red-400 hover:bg-red-50 dark:bg-red-500/10 flex items-center justify-center transition-colors">
          <Trash2 size={11} />
        </button>
        <button onClick={() => onEdit(item)}
          className="text-[9px] px-2 py-1 rounded-lg border border-line text-muted hover:border-gold hover:text-gold transition-colors">
          Sửa
        </button>
      </div>
    </div>
  );
}

// ── ExportModal ────────────────────────────────────────────────────────────
function ExportModal({ onConfirm, onClose, exporting }) {
  const [customerName, setCustomerName] = useState('');
  const [content, setContent] = useState('');

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-surface rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden animate-fadeIn">
        <div className="bg-gradient-to-r from-gold to-gold-strong px-5 py-4 flex items-center justify-between">
          <div>
            <p className="text-white/70 text-[10px] uppercase tracking-widest font-semibold">Xuất báo giá</p>
            <h3 className="text-white font-bold text-base mt-0.5">Thông tin báo giá</h3>
          </div>
          <button onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center text-white hover:bg-white/30">
            <X size={15} />
          </button>
        </div>

        <div className="px-5 py-4 space-y-4">
          <div>
            <label className="block text-[11px] font-bold text-muted uppercase tracking-wider mb-1.5">
              Kính gửi
            </label>
            <input
              type="text"
              value={customerName}
              onChange={e => setCustomerName(e.target.value)}
              placeholder="Để trống → QUÝ KHÁCH HÀNG"
              className="w-full rounded-xl border-2 border-line px-4 py-2.5 text-sm focus:outline-none focus:border-gold bg-surface"
            />
            <p className="text-[10px] text-faint mt-1">
              Nếu để trống sẽ hiển thị: <em>QUÝ KHÁCH HÀNG</em>
            </p>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-muted uppercase tracking-wider mb-1.5">
              Nội dung báo giá
            </label>
            <input
              type="text"
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder="VD: SẢN PHẨM ICEHOT & RICH'S"
              className="w-full rounded-xl border-2 border-line px-4 py-2.5 text-sm focus:outline-none focus:border-gold bg-surface"
            />
          </div>
        </div>

        <div className="px-5 pb-5 flex gap-3">
          <button onClick={onClose}
            className="flex-1 py-2.5 rounded-xl border border-line text-muted text-sm font-semibold hover:bg-surface-2 transition-colors">
            Huỷ
          </button>
          <button
            onClick={() => onConfirm({ customerName: customerName.trim(), content: content.trim() })}
            disabled={exporting}
            className="flex-1 py-2.5 rounded-xl bg-gold text-white text-sm font-bold hover:bg-gold-strong disabled:opacity-50 flex items-center justify-center gap-2 transition-colors"
          >
            {exporting
              ? <><div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" /> Đang tạo...</>
              : <><FileText size={14} /> Tạo PDF</>
            }
          </button>
        </div>
      </div>
    </div>
  );
}

// ── ProductCard (dành riêng cho Quotation — không hiện tồn kho) ─────────────
function QuotationProductCard({ product, onAdd, isInCart }) {
  const priceVal = product.basePrice ?? 0;
  const hasTiers = product.priceTiers && product.priceTiers.length > 0;
  const imageUrl = getImgSrc(product.imageUrl);

  return (
    <button
      onClick={() => onAdd(product)}
      className="card-product rounded-xl overflow-hidden text-left w-full flex flex-col cursor-pointer active:scale-95 transition-transform relative"
    >
      {/* Badge đã thêm */}
      {isInCart && (
        <div className="absolute top-2 right-2 z-30 w-5 h-5 rounded-full bg-gold flex items-center justify-center shadow">
          <Check size={11} className="text-white" />
        </div>
      )}

      <div className="relative aspect-square bg-surface-2 overflow-hidden w-full">
        {imageUrl
          ? <img src={imageUrl} alt={product.name} className="w-full h-full object-cover"
              onError={e => { e.target.style.display = 'none'; e.target.nextSibling.style.display = 'flex'; }} />
          : null
        }
        <div className="absolute inset-0 items-center justify-center text-faint text-3xl"
          style={{ display: imageUrl ? 'none' : 'flex' }}>
          🍽️
        </div>

        <div className="absolute inset-x-0 bottom-0 z-20
          bg-gradient-to-t from-black/80 via-black/45 to-transparent
          px-2.5 pt-8 pb-2 flex flex-col gap-0.5">
          <p className="text-white text-[11px] sm:text-xs font-semibold leading-tight line-clamp-2 drop-shadow">
            {product.name}
          </p>
          <div className="flex items-center justify-between gap-1 mt-0.5">
            <div className="flex flex-col gap-0.5">
              <span className="text-gold text-[11px] sm:text-xs font-bold drop-shadow">
                {new Intl.NumberFormat('vi-VN').format(Math.round(priceVal))} đ
              </span>
              {hasTiers && (
                <span className="text-[9px] bg-orange-400/80 text-white rounded px-1 py-0.5 font-semibold w-fit">
                  Có giá sỉ
                </span>
              )}
            </div>
            {product.sku && (
              <span className="text-[8px] text-white/70 font-mono">{product.sku}</span>
            )}
          </div>
        </div>
      </div>
    </button>
  );
}

// ── QuotationPage (main) ────────────────────────────────────────────────────
export default function QuotationPage() {
  const toast = useToast();
  const { user } = useAuth();

  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(false);

  const [inputSearch, setInputSearch] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('ALL');
  const [sortField, setSortField] = useState(null);
  const [sortDir, setSortDir] = useState('asc');

  // Cart: list sản phẩm đã thêm vào báo giá
  const [cartItems, setCartItems] = useState([]);

  // Modal chọn giá
  const [pickerProduct, setPickerProduct] = useState(null);   // product đang mở picker
  const [pickerExisting, setPickerExisting] = useState(null); // cartItem nếu đang edit

  // Modal export
  const [exportModalOpen, setExportModalOpen] = useState(false);
  const [exporting, setExporting] = useState(false);

  // Load sản phẩm và danh mục
  useEffect(() => {
    setLoading(true);
    productApi.getAll({ page: 0, size: 500 })
      .then(res => setProducts(res.data?.data?.content || []))
      .catch(() => toast('Không thể tải sản phẩm', 'error'))
      .finally(() => setLoading(false));

    categoryApi.getAll()
      .then(res => setCategories(res.data?.data || res.data || []))
      .catch(() => {});
  }, []);

  // Debounce search
  const searchDebounceRef = useRef(null);
  const handleSearchChange = (val) => {
    setInputSearch(val);
    clearTimeout(searchDebounceRef.current);
    searchDebounceRef.current = setTimeout(() => setSearchQuery(val), 300);
  };

  // Filter + sort sản phẩm
  const filteredProducts = useMemo(() => {
    let list = products;
    if (activeCategory !== 'ALL')
      list = list.filter(p => p.categoryId == activeCategory || p.category === activeCategory);
    if (searchQuery.trim()) {
      const q = normalize(searchQuery);
      list = list.filter(p => normalize(p.name).includes(q));
    }
    if (sortField) {
      list = [...list].sort((a, b) => {
        if (sortField === 'name') {
          const av = normalize(a.name), bv = normalize(b.name);
          return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
        }
        if (sortField === 'price') {
          const av = a.basePrice ?? 0, bv = b.basePrice ?? 0;
          return sortDir === 'asc' ? av - bv : bv - av;
        }
        return 0;
      });
    }
    return list;
  }, [products, activeCategory, searchQuery, sortField, sortDir]);

  // IDs đã trong giỏ
  const cartProductIds = useMemo(() => new Set(cartItems.map(i => i.productId)), [cartItems]);

  // Click sản phẩm: mở picker
  const handleAddProduct = useCallback((product) => {
    setPickerProduct(product);
    setPickerExisting(null);
  }, []);

  // Click "Sửa" item trong giỏ
  const handleEditItem = useCallback((item) => {
    const product = products.find(p => p.id === item.productId);
    if (!product) return;
    setPickerProduct(product);
    setPickerExisting(item);
  }, [products]);

  // Confirm từ PricePickerModal
  const handlePickerConfirm = useCallback(({ tierId, vatRate, vatMode, unitPrice, isCustomPrice }) => {
    const tierName = tierId
      ? pickerProduct.priceTiers?.find(t => t.id === tierId)?.tierName || 'Giá sỉ'
      : null;

    if (pickerExisting) {
      // Edit existing
      setCartItems(prev => prev.map(i =>
        i.id === pickerExisting.id
          ? { ...i, tierId, tierName, vatRate, vatMode, unitPrice, isCustomPrice }
          : i
      ));
    } else {
      // Add new (replace nếu cùng sản phẩm)
      const newItem = {
        id: newId(),
        productId: pickerProduct.id,
        productName: pickerProduct.name,
        productImageUrl: pickerProduct.imageUrl,
        sku: pickerProduct.sku || '',
        packagingDescription: pickerProduct.packagingDescription || '',
        storageInstruction: pickerProduct.storageInstruction || '',
        unit: pickerProduct.unit || '',
        tierId,
        tierName,
        vatRate,
        vatMode,
        unitPrice,
        isCustomPrice,
      };
      setCartItems(prev => {
        // Nếu đã có sản phẩm này rồi → replace
        const exists = prev.find(i => i.productId === pickerProduct.id);
        if (exists) return prev.map(i => i.productId === pickerProduct.id ? { ...newItem, id: i.id } : i);
        return [...prev, newItem];
      });
    }

    setPickerProduct(null);
    setPickerExisting(null);
  }, [pickerProduct, pickerExisting]);

  const handleRemoveItem = useCallback((id) => {
    setCartItems(prev => prev.filter(i => i.id !== id));
  }, []);

  // Xuất PDF
  const handleExport = useCallback(async ({ customerName, content }) => {
    if (cartItems.length === 0) {
      toast('Vui lòng thêm ít nhất 1 sản phẩm', 'warning');
      return;
    }
    setExporting(true);
    try {
      const payload = {
        customerName: customerName || null,
        quotationContent: content || null,
        items: cartItems.map(i => ({
          productId: i.productId,
          tierId: i.isCustomPrice ? null : (i.tierId ?? null),
          vatRate: i.vatRate,
          vatMode: i.vatMode,
          customPrice: !!i.isCustomPrice,
          customUnitPrice: i.isCustomPrice ? i.unitPrice : null,
        })),
      };
      const res = await quotationApi.exportPdf(payload);
      const now = new Date();
      const stamp = `${now.getDate().toString().padStart(2, '0')}${(now.getMonth() + 1).toString().padStart(2, '0')}${now.getFullYear()}`;
      downloadBlob(res.data, `BaoGia_${stamp}.pdf`);
      toast('Xuất báo giá thành công', 'success');
      setExportModalOpen(false);
    } catch (err) {
      toast(err?.response?.data?.message || 'Lỗi khi tạo báo giá', 'error');
    } finally {
      setExporting(false);
    }
  }, [cartItems, toast]);

  return (
    <div className="h-full flex flex-col lg:flex-row overflow-hidden bg-canvas">

      {/* ── Product panel ── */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Search + Filter */}
        <div className="flex-shrink-0 px-3 pt-3 pb-2 bg-surface border-b border-line-soft space-y-2">
          <div className="flex items-center justify-between">
            <h1 className="text-base font-bold text-ink">Tạo báo giá</h1>
            {/* Mobile: nút tạo báo giá */}
            <button
              onClick={() => setExportModalOpen(true)}
              disabled={cartItems.length === 0}
              className="lg:hidden flex items-center gap-1.5 px-3 py-2 rounded-xl bg-gold text-white text-xs font-bold disabled:opacity-40 transition-colors"
            >
              <FileText size={13} />
              Xuất ({cartItems.length})
            </button>
          </div>

          {/* Search */}
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
              <input
                type="text"
                placeholder="Tìm sản phẩm (có thể không dấu)..."
                value={inputSearch}
                onChange={e => handleSearchChange(e.target.value)}
                className="input-elegant w-full rounded-xl pl-9 pr-4 py-2 text-sm"
              />
            </div>
            {/* Sort */}
            {[{ field: 'name', label: 'Tên' }, { field: 'price', label: 'Giá' }].map(({ field, label }) => {
              const active = sortField === field;
              const Icon = active ? (sortDir === 'asc' ? ArrowUp : ArrowDown) : ArrowUpDown;
              return (
                <button key={field} onClick={() => {
                  if (!active) { setSortField(field); setSortDir('asc'); }
                  else if (sortDir === 'asc') setSortDir('desc');
                  else { setSortField(null); setSortDir('asc'); }
                }}
                  className={`shrink-0 flex items-center gap-1 px-3 py-2 rounded-xl border text-xs font-medium transition-colors
                    ${active ? 'border-gold bg-gold/10 text-gold' : 'border-line text-muted hover:border-gold'}`}>
                  <Icon size={13} />{label}
                </button>
              );
            })}
          </div>

          {/* Categories */}
          <div className="flex gap-1.5 overflow-x-auto pb-0.5 scrollbar-hide">
            <button onClick={() => setActiveCategory('ALL')}
              className={`shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors
                ${activeCategory === 'ALL' ? 'bg-gold text-white' : 'bg-surface-2 text-muted hover:bg-surface-3'}`}>
              Tất cả
            </button>
            {categories.map(cat => (
              <button key={cat.id} onClick={() => setActiveCategory(cat.id)}
                className={`shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors
                  ${activeCategory === cat.id ? 'bg-gold text-white' : 'bg-surface-2 text-muted hover:bg-surface-3'}`}>
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* Product grid */}
        <div className="flex-1 overflow-y-auto p-3">
          {loading ? (
            <div className="flex justify-center items-center h-40">
              <div className="w-8 h-8 border-2 border-gold border-t-transparent rounded-full animate-spin" />
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 text-muted gap-2">
              <span className="text-3xl">🔍</span>
              <p className="text-sm">Không tìm thấy sản phẩm</p>
            </div>
          ) : (
            <div className="grid grid-cols-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-3 sm:gap-4">
              {filteredProducts.map(p => (
                <QuotationProductCard
                  key={p.id}
                  product={p}
                  onAdd={handleAddProduct}
                  isInCart={cartProductIds.has(p.id)}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ── Cart / Quotation list panel (Desktop) ── */}
      <div className="hidden lg:flex flex-col w-80 xl:w-96 border-l border-line h-full bg-surface">
        {/* Header */}
        <div className="px-4 py-3 border-b border-line-soft flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText size={16} className="text-gold" />
            <span className="font-semibold text-sm text-ink">Danh sách báo giá</span>
            {cartItems.length > 0 && (
              <span className="bg-gold text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                {cartItems.length}
              </span>
            )}
          </div>
          {cartItems.length > 0 && (
            <button onClick={() => setCartItems([])}
              className="flex items-center gap-1 text-[10px] text-red-400 hover:text-red-600 dark:text-red-300">
              <Trash2 size={11} /> Xoá tất cả
            </button>
          )}
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto px-4">
          {cartItems.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-faint gap-2 py-8">
              <FileText size={32} strokeWidth={1} />
              <p className="text-sm text-center">Chưa có sản phẩm nào<br/>Click sản phẩm để thêm</p>
            </div>
          ) : (
            cartItems.map(item => (
              <QuotationCartItem
                key={item.id}
                item={item}
                onEdit={handleEditItem}
                onRemove={handleRemoveItem}
              />
            ))
          )}
        </div>

        {/* Footer: nút xuất */}
        <div className="px-4 pb-4 pt-3 border-t border-line-soft">
          <p className="text-[10px] text-faint mb-2 text-center">
            {cartItems.length} sản phẩm trong báo giá
          </p>
          <button
            onClick={() => setExportModalOpen(true)}
            disabled={cartItems.length === 0}
            className="w-full py-3 rounded-xl bg-gold hover:bg-gold-strong text-white text-sm font-bold disabled:opacity-40 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
          >
            <FileText size={15} />
            Tạo báo giá PDF
          </button>
        </div>
      </div>

      {/* ── Modals ── */}
      {pickerProduct && (
        <PricePickerModal
          product={pickerProduct}
          existing={pickerExisting}
          onConfirm={handlePickerConfirm}
          onClose={() => { setPickerProduct(null); setPickerExisting(null); }}
        />
      )}

      {exportModalOpen && (
        <ExportModal
          onConfirm={handleExport}
          onClose={() => setExportModalOpen(false)}
          exporting={exporting}
        />
      )}
    </div>
  );
}