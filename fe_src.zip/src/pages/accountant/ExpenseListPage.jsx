// src/pages/accountant/ExpenseListPage.jsx
import { useState, useEffect, useCallback, useRef } from 'react';
import { expenseApi, downloadBlob } from '../../api/services';
import { useToast } from '../../components/common/Toast';
import DateRangePicker from '../../components/ui/DateRangePicker';
import {
  Receipt, Search, ChevronLeft, ChevronRight,
  X, Plus, CheckCircle, XCircle, Clock,
  Building2, Eye, TrendingDown, TrendingUp, Wallet,
  Landmark, ShieldCheck, Filter,
  Download, Upload, Loader2, AlertTriangle, FileSpreadsheet
} from 'lucide-react';
import ExpenseCreateModal from './ExpenseCreateModal';
import ExpenseDetailModal from './ExpenseDetailModal';

function formatVND(n) {
  if (!n && n !== 0) return '0 đ';
  return new Intl.NumberFormat('vi-VN').format(n) + ' đ';
}
function formatDate(ms) {
  if (!ms) return '';
  const d = new Date(ms);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')} ${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
}
function dayRange(date) {
  const d = new Date(date + 'T00:00:00');
  return { from: d.getTime(), to: d.getTime() + 86399999 };
}
function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

const STATUS_CFG = {
  PENDING: { label: 'Chờ duyệt', cls: 'bg-amber-100 text-amber-700', icon: Clock },
  APPROVED: { label: 'Đã duyệt', cls: 'bg-green-100 text-green-700', icon: CheckCircle },
  REJECTED: { label: 'Từ chối', cls: 'bg-red-100 text-red-600', icon: XCircle },
};
const PAGE_SIZE = 10;

export default function ExpenseListPage() {
  const toast = useToast();
  const searchDebounce = useRef(null);
  const searchTextRef = useRef('');
  const fileInputRef = useRef(null);

  const [selectedDate, setSelectedDate] = useState(todayStr());
  const [dateRange, setDateRange] = useState(null);
  const [searchText, setSearchText] = useState('');
  const [vouchers, setVouchers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [totalElements, setTotalElements] = useState(0);
  const [totalAmount, setTotalAmount] = useState(0);
  const [showCreate, setShowCreate] = useState(false);
  const [detailVoucher, setDetailVoucher] = useState(null);
  const [creatorFilter, setCreatorFilter] = useState('');
  const [approverFilter, setApproverFilter] = useState('');
  const [downloadingTpl, setDownloadingTpl] = useState(false);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState(null);
  const [showExport, setShowExport] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [exportPaymentType, setExportPaymentType] = useState('ALL'); // ALL | CASH | BANK_TRANSFER

  const calcTotal = (list) => list.reduce((s, v) => s + (Number(v.totalAmount) || 0), 0);

  const load = useCallback(async (p = 0) => {
    setLoading(true);
    try {
      const q = searchTextRef.current.trim();

      // Quy tắc lọc ngày khi tìm kiếm (giống phiếu thu):
      //  - dateRange === null → mặc định "hôm nay" (user chưa chỉnh):
      //      không search → lọc hôm nay; có search → BỎ filter ngày (tìm toàn bộ).
      //  - dateRange !== null → user đã chọn khoảng ngày → luôn áp filter đó.
      //  Nút X gọi setDateRange(null) → về hôm nay → search lại thành không-filter.
      const userPickedRange = dateRange !== null;
      const ignoreDateForSearch = !!q && !userPickedRange;

      const range = dateRange || dayRange(selectedDate);
      const from = ignoreDateForSearch ? undefined : range.from;
      const to = ignoreDateForSearch ? undefined : range.to;

      const res = q
        ? await expenseApi.search(q, from, to, { page: p, size: PAGE_SIZE })
        : await expenseApi.listByDate(range.from, range.to, { page: p, size: PAGE_SIZE });
      const data = res.data?.data || res.data || {};
      const content = data.content || [];
      setVouchers(content);
      setTotalPages(data.totalPages || 0);
      setTotalElements(data.totalElements || 0);
      setTotalAmount(calcTotal(content));
      setPage(p);
    } catch { toast('Lỗi tải danh sách', 'error'); }
    finally { setLoading(false); }
  }, [selectedDate, dateRange]);

  useEffect(() => { load(0); }, [selectedDate, dateRange]);

  const handleSearchChange = (val) => {
    setSearchText(val);
    searchTextRef.current = val;
    clearTimeout(searchDebounce.current);
    searchDebounce.current = setTimeout(() => load(0), 500);
  };

  const clearSearch = () => {
    setSearchText(''); searchTextRef.current = '';
    clearTimeout(searchDebounce.current);
    load(0);
  };

  const handleDateRangeChange = (r) => {
    setDateRange(!r.from && !r.to ? null : r);
  };

  const handleDownloadTemplate = async () => {
    setDownloadingTpl(true);
    try {
      const res = await expenseApi.downloadImportTemplate();
      const today = todayStr().replace(/-/g, '');
      downloadBlob(res.data, `mau-nhap-phieu-chi-${today}.xlsx`);
    } catch {
      toast('Không tải được file mẫu', 'error');
    } finally {
      setDownloadingTpl(false);
    }
  };

  const handlePickFile = () => fileInputRef.current?.click();

  const handleFileChange = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = ''; // cho phép chọn lại cùng 1 file
    if (!file) return;
    setImporting(true);
    try {
      const res = await expenseApi.importExcel(file);
      const data = res.data?.data || res.data || {};
      setImportResult(data);
      if ((data.created || 0) > 0) {
        toast(`Đã tạo ${data.created} phiếu chi từ Excel`, 'success');
        load(0);
      } else if ((data.failed || 0) > 0) {
        toast('Không tạo được phiếu nào — xem chi tiết lỗi', 'error');
      }
    } catch (err) {
      toast(err?.response?.data?.message || 'Lỗi nhập file Excel', 'error');
    } finally {
      setImporting(false);
    }
  };

  const handleExportReport = async () => {
    const range = dateRange || dayRange(selectedDate);
    setExporting(true);
    try {
      const res = await expenseApi.exportReport(range.from, range.to, exportPaymentType);
      const d = new Date(range.from);
      const dEnd = new Date(range.to);
      const fmt = (dt) => `${String(dt.getDate()).padStart(2, '0')}-${String(dt.getMonth() + 1).padStart(2, '0')}-${dt.getFullYear()}`;
      downloadBlob(res.data, `phieu-chi-${fmt(d)}_${fmt(dEnd)}.xlsx`);
      toast('Xuất báo cáo thành công', 'success');
      setShowExport(false);
    } catch {
      toast('Lỗi xuất báo cáo', 'error');
    } finally {
      setExporting(false);
    }
  };

  const currentRange = dateRange || dayRange(selectedDate);

  // Lọc client-side theo người tạo / người duyệt trên danh sách đang hiển thị
  const creatorOptions = [...new Set(vouchers.map(v => v.createdByName).filter(Boolean))];
  const approverOptions = [...new Set(vouchers.map(v => v.approvedByName).filter(Boolean))];
  const displayed = vouchers.filter(v =>
    (!creatorFilter || v.createdByName === creatorFilter) &&
    (!approverFilter || v.approvedByName === approverFilter)
  );

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-4 pb-24">
      <div className="flex items-center gap-3">
        <Receipt size={22} className="text-[#C9A84C]" />
        <h1 className="text-xl font-bold text-[#1C1C1E]">Phiếu chi</h1>
        <span className="text-xs text-[#8E8878] ml-1">{totalElements} phiếu</span>
      </div>

      <div className="bg-gradient-to-r from-[#C9A84C]/10 to-[#C9A84C]/5 rounded-2xl p-4 flex items-center justify-between">
        <div>
          <p className="text-xs text-[#8E8878] font-medium">
            {searchText ? `Tìm "${searchText}" trong kỳ` : 'Tổng chi trong kỳ'}
          </p>
          <p className="text-2xl font-bold text-[#C9A84C] mt-0.5">{formatVND(totalAmount)}</p>
        </div>
        <TrendingDown size={28} className="text-[#C9A84C]/40" />
      </div>

      {/* Nhập từ Excel */}
      <div className="flex items-center gap-2 flex-wrap">
        <button
          onClick={handleDownloadTemplate}
          disabled={downloadingTpl}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#E8DDD0] bg-white text-sm font-semibold text-[#1C1C1E] hover:bg-[#FAF7F2] disabled:opacity-50 transition"
        >
          {downloadingTpl ? <Loader2 size={15} className="animate-spin" /> : <Download size={15} className="text-[#C9A84C]" />}
          Tải template
        </button>
        <button
          onClick={handlePickFile}
          disabled={importing}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#C9A84C] hover:bg-[#B8923E] text-sm font-semibold text-white disabled:opacity-60 transition"
        >
          {importing ? <Loader2 size={15} className="animate-spin" /> : <Upload size={15} />}
          {importing ? 'Đang nhập...' : 'Tạo từ file Excel'}
        </button>
        <button
          onClick={() => setShowExport(true)}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#E8DDD0] bg-white text-sm font-semibold text-[#1C1C1E] hover:bg-[#FAF7F2] transition"
        >
          <FileSpreadsheet size={15} className="text-[#C9A84C]" />
          Export báo cáo
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
          onChange={handleFileChange}
          className="hidden"
        />
      </div>

      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8E8878]" />
          <input
            value={searchText}
            onChange={e => handleSearchChange(e.target.value)}
            placeholder="Tìm số phiếu chi, lý do, nhà cung cấp, số tiền..."
            className="w-full pl-9 pr-8 py-2 rounded-xl border border-[#E8DDD0] text-sm bg-white focus:outline-none focus:border-[#C9A84C]"
          />
          {searchText && (
            <button onClick={clearSearch} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#8E8878] hover:text-[#1C1C1E]">
              <X size={13} />
            </button>
          )}
        </div>
        <div className="flex-shrink-0">
          <DateRangePicker from={currentRange.from} to={currentRange.to} onChange={handleDateRangeChange} placeholder="Chọn ngày" align="right" />
        </div>
        {dateRange && (
          <button onClick={() => setDateRange(null)} className="p-2 rounded-xl border border-[#E8DDD0] text-[#8E8878] hover:bg-[#FAF7F2] transition flex-shrink-0" title="Về hôm nay">
            <X size={14} />
          </button>
        )}
      </div>

      {/* Bộ lọc người tạo / người duyệt */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="inline-flex items-center gap-1 text-xs text-[#8E8878] font-medium">
          <Filter size={12} /> Lọc:
        </span>
        <select value={creatorFilter} onChange={e => setCreatorFilter(e.target.value)}
          className="px-3 py-1.5 rounded-lg border border-[#E8DDD0] text-xs bg-white focus:outline-none focus:border-[#C9A84C] max-w-[45%]">
          <option value="">Tất cả người tạo</option>
          {creatorOptions.map(n => <option key={n} value={n}>{n}</option>)}
        </select>
        <select value={approverFilter} onChange={e => setApproverFilter(e.target.value)}
          className="px-3 py-1.5 rounded-lg border border-[#E8DDD0] text-xs bg-white focus:outline-none focus:border-[#C9A84C] max-w-[45%]">
          <option value="">Tất cả người duyệt</option>
          {approverOptions.map(n => <option key={n} value={n}>{n}</option>)}
        </select>
        {(creatorFilter || approverFilter) && (
          <button onClick={() => { setCreatorFilter(''); setApproverFilter(''); }}
            className="text-xs text-[#C9A84C] hover:underline font-semibold">Xoá lọc</button>
        )}
      </div>

      {loading ? (
        <div className="space-y-3">{[...Array(5)].map((_, i) => <div key={i} className="h-20 bg-gray-100 rounded-2xl animate-pulse" />)}</div>
      ) : displayed.length === 0 ? (
        <div className="text-center py-16 text-[#8E8878]">
          <Receipt size={40} className="mx-auto mb-3 opacity-30" />
          <p className="font-medium">Không có phiếu chi nào</p>
          <p className="text-sm mt-1">{searchText || creatorFilter || approverFilter ? 'Thử điều kiện lọc khác' : 'Trong khoảng thời gian này'}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {displayed.map(v => {
            const s = STATUS_CFG[v.status] || STATUS_CFG.PENDING;
            const StatusIcon = s.icon;
            const isBank = v.paymentType === 'BANK_TRANSFER';
            return (
              <div key={v.id} onClick={() => setDetailVoucher(v)}
                className="bg-white rounded-2xl border border-black/5 shadow-sm p-4 hover:border-[#C9A84C]/40 hover:shadow-md transition cursor-pointer">
                {/* Row 1: mã + badge + tiền */}
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono text-xs font-bold text-[#C9A84C]">Số phiếu chi {v.paymentNumber || v.voucherCode}</span>
                    <span className={`inline-flex items-center gap-1 text-xs px-1.5 py-0.5 rounded-full font-medium ${s.cls}`}>
                      <StatusIcon size={9} /> {s.label}
                    </span>
                    <span className={`inline-flex items-center gap-1 text-xs px-1.5 py-0.5 rounded-full font-medium ${isBank ? 'bg-sky-50 text-sky-700' : 'bg-emerald-50 text-emerald-700'}`}>
                      {isBank ? <Landmark size={9} /> : <Wallet size={9} />} {isBank ? 'CK' : 'Tiền mặt'}
                    </span>
                    {v.voucherType === 'VENDOR_DEBT_PAYMENT' && (
                      <span className="inline-flex items-center gap-1 text-xs px-1.5 py-0.5 rounded-full font-medium bg-amber-50 text-amber-700">
                        <Wallet size={9} /> Trả công nợ NCC
                      </span>
                    )}
                  </div>
                  <p className="font-bold text-[#1C1C1E] text-sm">{formatVND(v.totalAmount)}</p>
                </div>
                {/* Row 2: lý do */}
                <p className="text-sm font-semibold text-[#1C1C1E] truncate mb-1.5">Nội dung: {v.reason}</p>
                {/* Row 3: meta */}
                <div className="flex items-center justify-between text-xs text-[#8E8878]">
                  <div className="flex items-center gap-1.5 min-w-0">
                    Nhà cung cấp: {v.vendorName && <span className="flex items-center gap-1">{v.vendorName}</span>}
                  </div>
                  <span className="flex-shrink-0">{formatDate(v.createdAt)}</span>
                </div>
                <div className="flex items-center justify-between mt-0.5">
                  <p className="text-xs text-[#8E8878]">Tạo bởi {v.createdByName}</p>
                  {v.approvedByName ? (
                    <span className="inline-flex items-center gap-1 text-xs px-1.5 py-0.5 rounded-full font-medium bg-[#C9A84C]/10 text-[#B8923E]">
                      <ShieldCheck size={9} /> Người duyệt: {v.approvedByName}
                    </span>
                  ) : v.status === 'PENDING' && (
                    <span className="inline-flex items-center gap-1 text-xs px-1.5 py-0.5 rounded-full font-medium bg-amber-50 text-amber-600">
                      <Clock size={9} /> {v.approverScope === 'SUPER_ACCOUNTANT' ? 'Chờ KT trưởng' : 'Chờ chủ/quản trị'}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 pt-2">
          <button disabled={page === 0} onClick={() => load(page - 1)} className="p-2 rounded-lg border border-black/10 hover:bg-[#FAF7F2] disabled:opacity-30 transition"><ChevronLeft size={16} /></button>
          {[...Array(Math.min(totalPages, 7))].map((_, i) => (
            <button key={i} onClick={() => load(i)} className={`w-9 h-9 rounded-lg text-sm font-semibold transition ${i === page ? 'bg-[#C9A84C] text-white' : 'border border-black/10 hover:bg-[#FAF7F2] text-[#1C1C1E]'}`}>{i + 1}</button>
          ))}
          <button disabled={page >= totalPages - 1} onClick={() => load(page + 1)} className="p-2 rounded-lg border border-black/10 hover:bg-[#FAF7F2] disabled:opacity-30 transition"><ChevronRight size={16} /></button>
        </div>
      )}

      <button
        onClick={() => setShowCreate(true)}
        className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-[#C9A84C] hover:bg-[#B8923E] shadow-xl flex items-center justify-center transition-all"
      >
        <Plus size={26} className="text-white" />
      </button>

      {showCreate && <ExpenseCreateModal onClose={() => setShowCreate(false)} onCreated={() => { setShowCreate(false); load(0); }} />}
      {detailVoucher && <ExpenseDetailModal voucher={detailVoucher} onClose={() => setDetailVoucher(null)} onChanged={() => load(page)} />}

      {/* ── Export báo cáo Modal ── */}
      {showExport && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/50 p-4" onClick={() => !exporting && setShowExport(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden" onClick={e => e.stopPropagation()}>
            <div className="bg-gradient-to-r from-[#C9A84C] to-[#B8923E] px-5 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center">
                  <Download size={16} className="text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">Xuất báo cáo phiếu chi</h3>
                  <p className="text-white/70 text-[10px]">File Excel · gộp khoản chi theo phiếu</p>
                </div>
              </div>
              <button onClick={() => setShowExport(false)}
                className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center text-white hover:bg-white/30 transition-colors">
                <X size={14} />
              </button>
            </div>

            <div className="p-5 space-y-3">
              <div className="rounded-xl bg-[#FAF7F2] border border-[#E8DDD0] px-4 py-3">
                <p className="text-[10px] font-bold text-[#B8923E] uppercase tracking-wider mb-1">Khoảng thời gian</p>
                <p className="text-sm font-semibold text-[#5C4E3D]">
                  {formatDate(currentRange.from).split(' ').slice(1).join(' ')}
                  {' — '}
                  {formatDate(currentRange.to).split(' ').slice(1).join(' ')}
                </p>
                <p className="text-[10px] text-[#C9A84C] mt-1 italic">Theo bộ lọc ngày đang chọn (mặc định hôm nay)</p>
              </div>

              <div>
                <p className="text-[10px] font-bold text-[#8E8878] uppercase tracking-wider mb-1.5">Phương thức thanh toán</p>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { key: 'CASH', label: 'Tiền mặt' },
                    { key: 'BANK_TRANSFER', label: 'Chuyển khoản' },
                    { key: 'ALL', label: 'Cả 2' },
                  ].map(opt => (
                    <button
                      key={opt.key}
                      onClick={() => setExportPaymentType(opt.key)}
                      className={`py-2 rounded-xl text-xs font-semibold border transition-colors ${
                        exportPaymentType === opt.key
                          ? 'bg-[#C9A84C] text-white border-[#C9A84C]'
                          : 'bg-white text-[#5C5C5C] border-[#E8DDD0] hover:bg-[#F0EBE3]'
                      }`}>
                      {opt.label}
                    </button>
                  ))}
                </div>
                {exportPaymentType === 'ALL' && (
                  <p className="text-[10px] text-[#C9A84C] mt-1 italic">File sẽ có thêm cột "Phương thức thanh toán"</p>
                )}
              </div>

              <div className="space-y-1.5">
                <p className="text-[10px] font-bold text-[#8E8878] uppercase tracking-wider">Nội dung file</p>
                {[
                  'Thời gian tạo · Trạng thái · Thời gian duyệt',
                  'Người tạo · Người duyệt · Nhà cung cấp',
                  'Thời gian/Kỳ · Nội dung · Tổng tiền',
                  ...(exportPaymentType === 'ALL' ? ['Phương thức thanh toán'] : []),
                  'Danh mục khoản chi · Số tiền mỗi khoản',
                ].map(col => (
                  <div key={col} className="flex items-center gap-2 text-xs text-[#5C4E3D]">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#C9A84C] flex-shrink-0" />
                    {col}
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-2 px-5 pb-5">
              <button onClick={() => setShowExport(false)} disabled={exporting}
                className="flex-1 py-2.5 rounded-xl border border-[#E8DDD0] text-sm text-[#5C5C5C] hover:bg-[#F0EBE3] transition-colors font-medium disabled:opacity-50">
                Huỷ
              </button>
              <button onClick={handleExportReport} disabled={exporting}
                className="flex-1 py-2.5 rounded-xl bg-[#C9A84C] hover:bg-[#B8923E] text-white text-sm font-semibold transition-colors disabled:opacity-60 flex items-center justify-center gap-1.5">
                {exporting ? <Loader2 size={15} className="animate-spin" /> : <Download size={15} />}
                {exporting ? 'Đang xuất...' : 'Xuất Excel'}
              </button>
            </div>
          </div>
        </div>
      )}

      {importResult && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/50 p-4" onClick={() => setImportResult(null)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md flex flex-col max-h-[85vh]" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-black/5">
              <div className="flex items-center gap-2">
                <FileSpreadsheet size={18} className="text-[#C9A84C]" />
                <h3 className="font-bold text-[#1C1C1E]">Kết quả nhập từ Excel</h3>
              </div>
              <button onClick={() => setImportResult(null)} className="p-1.5 rounded-xl hover:bg-[#FAF7F2] text-[#8E8878]">
                <X size={18} />
              </button>
            </div>

            <div className="p-5 space-y-4 overflow-y-auto">
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="rounded-xl bg-[#FAF7F2] p-3">
                  <p className="text-2xl font-bold text-[#1C1C1E]">{importResult.totalVouchers || 0}</p>
                  <p className="text-xs text-[#8E8878] mt-0.5">Tổng phiếu</p>
                </div>
                <div className="rounded-xl bg-green-50 p-3">
                  <p className="text-2xl font-bold text-green-600">{importResult.created || 0}</p>
                  <p className="text-xs text-green-700 mt-0.5">Thành công</p>
                </div>
                <div className="rounded-xl bg-red-50 p-3">
                  <p className="text-2xl font-bold text-red-500">{importResult.failed || 0}</p>
                  <p className="text-xs text-red-600 mt-0.5">Bị lỗi</p>
                </div>
              </div>

              {Array.isArray(importResult.errors) && importResult.errors.length > 0 && (
                <div>
                  <p className="text-xs font-semibold text-[#1C1C1E] mb-2 flex items-center gap-1.5">
                    <AlertTriangle size={13} className="text-amber-500" /> Các phiếu chưa nhập được:
                  </p>
                  <div className="space-y-2">
                    {importResult.errors.map((er, i) => (
                      <div key={i} className="rounded-xl border border-red-100 bg-red-50/50 p-3 text-sm">
                        <p className="font-semibold text-[#1C1C1E]">
                          {er.groupKey ? `Số phiếu chi "${er.groupKey}"` : 'Phiếu'} <span className="text-xs text-[#8E8878] font-normal">(dòng {er.excelRow})</span>
                        </p>
                        <p className="text-red-600 text-xs mt-0.5">{er.message}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {(importResult.created || 0) > 0 && (importResult.failed || 0) === 0 && (
                <div className="rounded-xl bg-green-50 p-3 flex items-center gap-2 text-sm text-green-700">
                  <CheckCircle size={16} /> Đã nhập tất cả phiếu chi thành công.
                </div>
              )}
            </div>

            <div className="p-4 border-t border-black/5">
              <button onClick={() => setImportResult(null)}
                className="w-full py-2.5 rounded-xl bg-[#C9A84C] hover:bg-[#B8923E] text-white text-sm font-semibold transition">
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}