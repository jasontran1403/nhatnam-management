// src/pages/owner/AttendanceSheetsPage.jsx
// BẢNG CHẤM CÔNG — OWNER quản lý dữ liệu lương theo THÁNG × BỘ PHẬN.
//
//   Bộ phận:  Xưởng sản xuất · Kinh doanh · Kho · Kế toán · Tài xế
//
//   Mỗi bộ phận (trừ Tài xế) có 3 loại file RIÊNG cho mỗi tháng:
//     1. Bảng chấm công (xuất từ máy chấm công)
//     2. Lịch nghỉ / đi trễ / về sớm
//     3. Đơn xin đi trễ / về sớm / nghỉ phép của cá nhân
//   Mỗi loại tối đa 1 file/tháng — đã có thì phải xoá rồi mới tải lại được.
//
//   Xử lý xong → bấm "HOÀN TẤT". Lúc đó nhân viên của bộ phận mới xem được
//   phiếu lương; chưa hoàn tất thì họ thấy "Đang xử lý lương".
//   Hoàn tất rồi vẫn xoá/đổi file được — cờ hoàn tất tự gỡ, bấm Hoàn tất lần
//   nữa sẽ tính lại theo file MỚI NHẤT.
import { useState, useEffect, useCallback, useRef } from 'react';
import {
  ClipboardCheck, Upload, RefreshCw, AlertCircle, CheckCircle2, Trash2,
  FileSpreadsheet, Calculator, Download, CalendarDays, ChevronDown,
  CalendarClock, UserCheck, Clock, Lock, Unlock, Users, Receipt, Truck, Route,
} from 'lucide-react';
import { factoryPayrollApi } from '../../api/factoryPayrollApi';
import {
  PageHeader, SectionCard, LoadingSpinner, SecondaryButton, PrimaryButton,
  Table, Thead, Th, Td, Tr, formatDateTime, formatCurrency,
} from '../../components/ui';
import Modal from '../../components/ui/Modal';
import { useToast } from '../../components/common/Toast';

const fmtNum = (v, d = 2) =>
  v == null ? '—' : Number(v).toLocaleString('vi-VN', { maximumFractionDigits: d });

// ══════════════════════════════════════════════════════════════════════════════
// CHỌN THÁNG — tháng hiện tại + quá khứ, KHÔNG có tương lai
// ══════════════════════════════════════════════════════════════════════════════

function MonthPicker({ periods, value, onChange, disabled }) {
  const [open, setOpen] = useState(false);
  const current = periods.find(p => p.month === value?.month && p.year === value?.year);

  const grouped = periods.reduce((acc, p) => {
    (acc[p.year] ||= []).push(p);
    return acc;
  }, {});

  return (
    <div className="relative">
      <button onClick={() => setOpen(o => !o)} disabled={disabled || !periods.length}
        className="flex items-center gap-2.5 px-4 py-2.5 rounded-2xl bg-white border border-black/10
          shadow-sm hover:border-[#C9A84C]/50 transition-colors disabled:opacity-50 min-w-[190px]">
        <CalendarDays size={16} className="text-[#C9A84C] shrink-0" />
        <span className="flex-1 text-left text-sm font-bold text-[#1C1C1E]">
          {current?.label || 'Chọn tháng'}
        </span>
        <ChevronDown size={15} className={`text-[#8E8878] transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-20" onClick={() => setOpen(false)} />
          <div className="absolute z-30 mt-2 w-full min-w-[220px] max-h-[360px] overflow-y-auto
            bg-white rounded-2xl border border-black/10 shadow-xl p-2">
            {Object.entries(grouped).sort((a, b) => b[0] - a[0]).map(([year, items]) => (
              <div key={year} className="mb-1 last:mb-0">
                <p className="px-3 py-1.5 text-[11px] font-bold uppercase tracking-wider text-[#8E8878]">
                  Năm {year}
                </p>
                {items.map(p => {
                  const active = p.month === value?.month && p.year === value?.year;
                  return (
                    <button key={`${p.year}-${p.month}`}
                      onClick={() => { onChange(p); setOpen(false); }}
                      className={`w-full flex items-center justify-between gap-2 px-3 py-2 rounded-xl
                        text-sm transition-colors
                        ${active ? 'bg-[#C9A84C] text-white font-bold' : 'text-[#1C1C1E] hover:bg-[#FAF7F2]'}`}>
                      <span>Tháng {p.month}</span>
                      {p.finalized && (
                        <CheckCircle2 size={13} className={active ? 'text-white' : 'text-emerald-500'} />
                      )}
                    </button>
                  );
                })}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// TAB BỘ PHẬN
// ══════════════════════════════════════════════════════════════════════════════

function DepartmentTabs({ statuses, value, onChange }) {
  return (
    <div className="flex gap-1.5 overflow-x-auto pb-1 -mx-1 px-1">
      {statuses.map(s => {
        const active = s.department === value;
        return (
          <button key={s.department} onClick={() => onChange(s.department)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-sm font-bold
              whitespace-nowrap border transition-colors shrink-0
              ${active
                ? 'bg-[#1C1C1E] text-white border-[#1C1C1E]'
                : 'bg-white text-[#1C1C1E] border-black/10 hover:border-[#C9A84C]/50'}`}>
            {s.department === 'DRIVER'
              ? <Truck size={14} className={active ? 'text-[#C9A84C]' : 'text-[#8E8878]'} />
              : <Users size={14} className={active ? 'text-[#C9A84C]' : 'text-[#8E8878]'} />}
            <span>{s.departmentLabel}</span>
            <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-md
              ${active ? 'bg-white/15 text-white/80' : 'bg-[#FAF7F2] text-[#8E8878]'}`}>
              {s.employeeCount ?? 0}
            </span>
            {s.finalized && (
              <CheckCircle2 size={13} className={active ? 'text-emerald-400' : 'text-emerald-500'} />
            )}
          </button>
        );
      })}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// KHỐI 1 LOẠI FILE
// ══════════════════════════════════════════════════════════════════════════════

function FileSlot({ icon: Icon, title, description, hint,
                    exists, fileName, uploadedAt, rowCount, rowLabel,
                    onUpload, onDelete, onTemplate, uploading, deleting }) {
  const fileRef = useRef(null);

  return (
    <div className={`rounded-2xl border overflow-hidden transition-colors
      ${exists ? 'border-emerald-200 bg-emerald-50/30' : 'border-black/10 bg-white'}`}>

      <div className="flex items-start gap-3 px-4 py-3.5 border-b border-black/5">
        <span className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0
          ${exists ? 'bg-emerald-100' : 'bg-[#FAF7F2]'}`}>
          <Icon size={16} className={exists ? 'text-emerald-600' : 'text-[#8E8878]'} />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-bold text-[#1C1C1E] leading-tight">{title}</p>
          <p className="text-[11px] text-[#8E8878] mt-0.5 leading-snug">{description}</p>
        </div>
        {exists && (
          <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-1 rounded-lg
            bg-emerald-100 text-emerald-700 shrink-0">
            <CheckCircle2 size={11} /> Đã có
          </span>
        )}
      </div>

      {exists && (
        <div className="px-4 py-2.5 bg-white/60 border-b border-black/5">
          <p className="text-[11px] text-[#5A5548] truncate" title={fileName}>{fileName || '—'}</p>
          <p className="text-[10px] text-[#8E8878] mt-0.5">
            {uploadedAt ? formatDateTime(uploadedAt) : '—'}
            {rowCount != null && ` · ${rowCount} ${rowLabel}`}
          </p>
        </div>
      )}

      <div className="px-4 py-3 space-y-2">
        {hint && !exists && <p className="text-[10px] text-[#8E8878] leading-snug">{hint}</p>}

        <div className="flex gap-2">
          {onTemplate && (
            <button onClick={onTemplate}
              className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-[11px]
                font-semibold bg-white border border-black/10 text-[#1C1C1E]
                hover:bg-[#FAF7F2] transition-colors shrink-0">
              <Download size={12} /> Tải mẫu
            </button>
          )}

          {!exists ? (
            <label className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl
              text-[11px] font-bold text-white transition-colors
              ${uploading ? 'bg-[#C4B9A8] cursor-wait' : 'bg-[#C9A84C] hover:bg-[#A07830] cursor-pointer'}`}>
              {uploading ? (
                <>
                  <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Đang xử lý
                </>
              ) : (
                <><Upload size={12} /> Tải file lên</>
              )}
              <input ref={fileRef} type="file" accept=".xlsx,.xls" className="hidden" disabled={uploading}
                onChange={e => { if (e.target.files[0]) { onUpload(e.target.files[0]); e.target.value = ''; } }} />
            </label>
          ) : (
            <button onClick={onDelete} disabled={deleting}
              className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl
                text-[11px] font-bold bg-white border border-red-200 text-red-600
                hover:bg-red-50 transition-colors disabled:opacity-50">
              <Trash2 size={12} />
              {deleting ? 'Đang xoá...' : 'Xoá file cũ, tải lại'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// BÁO CÁO KẾT QUẢ IMPORT — file có bao nhiêu NV, thiếu của ai
// ══════════════════════════════════════════════════════════════════════════════

function ImportResultModal({ result, title, onClose }) {
  const [tab, setTab] = useState('unmatched');
  if (!result) return null;

  const matched = result.matchedRows || [];
  const unmatched = result.unmatchedRows || [];
  const unused = result.unusedBlocks || [];
  const MATCH_LABEL = { CODE: 'mã chấm công', EXACT_NAME: 'họ tên' };

  const tabs = [
    { id: 'unmatched', label: `Thiếu (${unmatched.length})`, show: true },
    { id: 'matched', label: `Đã khớp (${matched.length})`, show: matched.length > 0 },
    { id: 'unused', label: `Không dùng (${unused.length})`, show: unused.length > 0 },
  ].filter(t => t.show);

  return (
    <Modal open onClose={onClose} title={title} size="md">
      <div className="space-y-3 py-1">
        {/* Tóm tắt: file có bao nhiêu người / khớp / thiếu */}
        <div className="grid grid-cols-4 gap-2">
          {[
            { label: 'NV trong file', value: result.blocksInFile ?? 0, color: 'text-[#1C1C1E]' },
            { label: 'NV bộ phận', value: result.departmentEmployees ?? 0, color: 'text-[#1C1C1E]' },
            { label: 'Đã khớp', value: result.matched ?? 0, color: 'text-emerald-600' },
            { label: 'Thiếu', value: result.skipped ?? 0, color: 'text-amber-600' },
          ].map(s => (
            <div key={s.label} className="bg-[#FAF7F2] rounded-xl px-2 py-2.5 text-center">
              <p className="text-[10px] text-[#8E8878] font-semibold leading-tight">{s.label}</p>
              <p className={`text-xl font-bold mt-0.5 ${s.color}`}>{s.value}</p>
            </div>
          ))}
        </div>

        {result.departmentLabel && (
          <p className="text-[11px] text-[#8E8878]">
            Bộ phận: <strong className="text-[#1C1C1E]">{result.departmentLabel}</strong>
            {' · '}Tháng {result.month}/{result.year}
          </p>
        )}

        {result.skipped > 0 && (
          <div className="flex items-start gap-2 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2.5">
            <AlertCircle size={14} className="text-amber-600 shrink-0 mt-0.5" />
            <p className="text-[11px] text-amber-800 leading-snug">
              File thiếu dữ liệu của <strong>{result.skipped} nhân viên</strong> —
              xem danh sách ở tab "Thiếu". Những người này sẽ được ghi nhận 0 công cho tháng.
            </p>
          </div>
        )}

        {tabs.length > 1 && (
          <div className="flex gap-1 bg-[#FAF7F2] rounded-xl p-1">
            {tabs.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`flex-1 px-2 py-1.5 rounded-lg text-[11px] font-semibold transition-colors
                  ${tab === t.id ? 'bg-white text-[#1C1C1E] shadow-sm' : 'text-[#8E8878] hover:text-[#1C1C1E]'}`}>
                {t.label}
              </button>
            ))}
          </div>
        )}

        <div className="max-h-52 overflow-y-auto rounded-xl border border-black/5 divide-y divide-black/5">
          {tab === 'matched' && (matched.length === 0
            ? <p className="text-[11px] text-[#8E8878] text-center py-6">Không có dữ liệu</p>
            : matched.map((r, i) => (
              <div key={r.userId ?? i} className="flex items-center justify-between gap-3 px-3 py-2.5">
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-[#1C1C1E] truncate">{r.fullName}</p>
                  <p className="text-[10px] text-[#8E8878] truncate">
                    {r.roleLabel || '—'}
                    {r.employeeCode ? ` · mã ${r.employeeCode}` : ''}
                    {r.matchedBy ? ` · khớp theo ${MATCH_LABEL[r.matchedBy] || r.matchedBy}` : ''}
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-xs font-bold text-emerald-600">{r.actualDays ?? 0} công</p>
                  <p className="text-[10px] text-[#8E8878]">{r.presentDays ?? 0} ngày chấm</p>
                </div>
              </div>
            )))}

          {tab === 'unmatched' && (unmatched.length === 0
            ? <p className="text-[11px] text-emerald-700 text-center py-6">
                Không có ai bị bỏ sót — file đủ toàn bộ nhân viên của bộ phận.
              </p>
            : unmatched.map((r, i) => (
              <div key={r.userId ?? i} className="px-3 py-2.5">
                <p className="text-xs font-semibold text-[#1C1C1E]">{r.fullName}</p>
                <p className="text-[10px] text-[#8E8878]">
                  {r.roleLabel || 'Không tìm thấy trong hệ thống'}
                </p>
              </div>
            )))}

          {tab === 'unused' && unused.map((u, i) => (
            <p key={i} className="px-3 py-2 text-[11px] text-[#5A5548]">{u}</p>
          ))}
        </div>

        {result.errors?.length > 0 && (
          <details className="bg-[#FAF7F2] rounded-xl px-3 py-2.5">
            <summary className="text-[11px] font-semibold text-[#8E8878] cursor-pointer">
              {result.errors.length} cảnh báo khi đọc file
            </summary>
            <div className="mt-2 space-y-1 max-h-32 overflow-y-auto">
              {result.errors.map((e, i) => (
                <p key={i} className="text-[10px] text-amber-700 leading-snug">{e}</p>
              ))}
            </div>
          </details>
        )}
      </div>
    </Modal>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// 2 BẢNG SAU KHI HOÀN TẤT — Phiếu lương & Chi tiết ngày công
// ══════════════════════════════════════════════════════════════════════════════

function PayrollTables({ data, loading }) {
  if (loading) return <SectionCard><LoadingSpinner label="Đang tải bảng lương..." /></SectionCard>;
  if (!data) return null;

  const rows = data.rows || [];
  const isDriver = !data.attendanceBased;

  return (
    <>
      {/* ── BẢNG 1: PHIẾU LƯƠNG ─────────────────────────────────────────── */}
      <SectionCard>
        <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-black/5 flex-wrap">
          <div className="flex items-center gap-2">
            <Receipt size={16} className="text-[#C9A84C]" />
            <h3 className="text-sm font-bold text-[#1C1C1E]">
              Phiếu lương — {data.departmentLabel} · {data.periodLabel}
            </h3>
          </div>
          <div className="flex items-center gap-4 text-xs">
            <span className="text-[#8E8878]">
              Tổng NET: <strong className="text-emerald-700">{formatCurrency(data.totalNetSalary)}</strong>
            </span>
            {data.hasKpiBonus && (
              <span className="text-[#8E8878]">
                Tổng KPI: <strong className="text-[#C9A84C]">{formatCurrency(data.totalKpiBonus)}</strong>
              </span>
            )}
          </div>
        </div>

        <div className="overflow-x-auto">
          <Table>
            <Thead>
              <Tr>
                <Th>Nhân viên</Th>
                <Th right>Lương cơ bản</Th>
                <Th right>Phụ cấp</Th>
                <Th right>Thưởng</Th>
                <Th right>GROSS</Th>
                <Th right>Bảo hiểm NLĐ</Th>
                <Th right>Thuế TNCN</Th>
                <Th right>Lương NET</Th>
                {data.hasKpiBonus && <Th right>Thưởng KPI</Th>}
              </Tr>
            </Thead>
            <tbody>
              {rows.map(r => (
                <Tr key={r.userId}>
                  <Td>
                    <div className="font-medium">{r.userFullName}</div>
                    <div className="text-xs text-[#8E8878]">
                      {r.roleLabel || '—'}
                      {r.salaryStatus === 'NO_SALARY' && (
                        <span className="ml-1.5 text-amber-600 font-semibold">· chưa có hồ sơ lương</span>
                      )}
                    </div>
                  </Td>
                  <Td right>{formatCurrency(r.baseSalary)}</Td>
                  <Td right>{formatCurrency(r.allowance)}</Td>
                  <Td right>{formatCurrency(r.bonus)}</Td>
                  <Td right>{formatCurrency(r.grossSalary)}</Td>
                  <Td right>{formatCurrency(r.employeeInsuranceTotal)}</Td>
                  <Td right>{formatCurrency(r.personalIncomeTax)}</Td>
                  <Td right>
                    <span className="font-semibold text-emerald-700">{formatCurrency(r.netSalary)}</span>
                  </Td>
                  {data.hasKpiBonus && (
                    <Td right><span className="text-[#C9A84C] font-semibold">
                      {formatCurrency(r.kpiBonus)}</span></Td>
                  )}
                </Tr>
              ))}
              {rows.length === 0 && (
                <Tr><Td className="text-center text-[#8E8878] py-8">
                  Bộ phận này chưa có nhân viên nào</Td></Tr>
              )}
            </tbody>
          </Table>
        </div>
      </SectionCard>

      {/* ── BẢNG 2: CHI TIẾT NGÀY CÔNG (hoặc số km với tài xế) ──────────── */}
      <SectionCard>
        <div className="flex items-center gap-2 px-5 py-4 border-b border-black/5">
          {isDriver
            ? <Route size={16} className="text-[#C9A84C]" />
            : <Clock size={16} className="text-[#C9A84C]" />}
          <h3 className="text-sm font-bold text-[#1C1C1E]">
            {isDriver ? 'Chi tiết số km theo tháng' : 'Chi tiết ngày công'} — {data.periodLabel}
          </h3>
        </div>

        <div className="overflow-x-auto">
          <Table>
            <Thead>
              {isDriver ? (
                <Tr>
                  <Th>Tài xế</Th>
                  <Th right>Tổng km</Th>
                  <Th right>Số đơn đã giao</Th>
                </Tr>
              ) : (
                <Tr>
                  <Th>Nhân viên</Th>
                  <Th>Mã chấm công</Th>
                  <Th right>Công chuẩn</Th>
                  <Th right>Công thực tế</Th>
                  <Th right>Ngày có chấm</Th>
                  <Th right>Đi trễ</Th>
                  <Th right>Về sớm</Th>
                </Tr>
              )}
            </Thead>
            <tbody>
              {rows.map(r => (
                <Tr key={r.userId}>
                  <Td>
                    <div className="font-medium">{r.userFullName}</div>
                    <div className="text-xs text-[#8E8878]">{r.roleLabel || '—'}</div>
                  </Td>

                  {isDriver ? (
                    <>
                      <Td right><span className="font-semibold text-[#C9A84C]">
                        {fmtNum(r.totalKm, 1)} km</span></Td>
                      <Td right>{r.totalOrders ?? 0}</Td>
                    </>
                  ) : (
                    <>
                      <Td>
                        {r.employeeCode || (
                          <span className="text-amber-600 text-xs font-semibold">Thiếu trong file</span>
                        )}
                      </Td>
                      <Td right>{fmtNum(r.standardDays)}</Td>
                      <Td right>
                        <span className={r.hasAttendance ? 'font-semibold text-emerald-700' : 'text-amber-600'}>
                          {fmtNum(r.actualDays)}
                        </span>
                      </Td>
                      <Td right>{r.presentDays ?? 0}</Td>
                      <Td right>
                        {r.lateCount ? `${r.lateCount} ngày · ${r.lateMinutes} phút` : '—'}
                      </Td>
                      <Td right>
                        {r.earlyCount ? `${r.earlyCount} ngày · ${r.earlyMinutes} phút` : '—'}
                      </Td>
                    </>
                  )}
                </Tr>
              ))}
              {rows.length === 0 && (
                <Tr><Td className="text-center text-[#8E8878] py-8">Không có dữ liệu</Td></Tr>
              )}
            </tbody>
          </Table>
        </div>
      </SectionCard>
    </>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// TRANG CHÍNH
// ══════════════════════════════════════════════════════════════════════════════

export default function AttendanceSheetsPage() {
  const [periods, setPeriods] = useState([]);
  const [selected, setSelected] = useState(null);
  const [department, setDepartment] = useState('FACTORY');
  const [statuses, setStatuses] = useState([]);           // trạng thái CẢ 5 bộ phận
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(null);                 // 'attendance' | 'exception' | 'leave'
  const [deleting, setDeleting] = useState(null);
  const [finalizing, setFinalizing] = useState(false);
  const [result, setResult] = useState(null);
  const [resultTitle, setResultTitle] = useState('');
  const [recomputing, setRecomputing] = useState(false);
  const [payroll, setPayroll] = useState(null);
  const [loadingPayroll, setLoadingPayroll] = useState(false);
  const toast = useToast();

  const status = statuses.find(s => s.department === department) || null;

  // ── Nạp danh sách tháng ───────────────────────────────────────────────────
  useEffect(() => {
    (async () => {
      try {
        const list = await factoryPayrollApi.uploadablePeriods('FACTORY');
        const arr = Array.isArray(list) ? list : [];
        setPeriods(arr);
        if (arr.length) setSelected(arr[0]);
      } catch (e) {
        toast(e?.response?.data?.message || 'Không tải được danh sách tháng', 'error');
      } finally {
        setLoading(false);
      }
    })();
  }, []); // eslint-disable-line

  // ── Nạp trạng thái CẢ 5 bộ phận khi đổi tháng ─────────────────────────────
  const loadStatus = useCallback(async (p) => {
    if (!p) return;
    try {
      const list = await factoryPayrollApi.monthStatusAll(p.month, p.year);
      setStatuses(Array.isArray(list) ? list : []);
    } catch (e) {
      toast(e?.response?.data?.message || 'Không tải được trạng thái tháng', 'error');
    }
  }, []); // eslint-disable-line

  useEffect(() => { loadStatus(selected); }, [selected, loadStatus]);

  // ── Nạp 2 bảng lương khi đã HOÀN TẤT ──────────────────────────────────────
  const loadPayroll = useCallback(async (p, dept, finalized) => {
    if (!p || !finalized) { setPayroll(null); return; }
    setLoadingPayroll(true);
    try {
      setPayroll(await factoryPayrollApi.departmentPayroll(p.month, p.year, dept));
    } catch (e) {
      toast(e?.response?.data?.message || 'Không tải được bảng lương', 'error');
      setPayroll(null);
    } finally {
      setLoadingPayroll(false);
    }
  }, []); // eslint-disable-line

  useEffect(() => {
    loadPayroll(selected, department, status?.finalized);
  }, [selected, department, status?.finalized, loadPayroll]);

  // ── Hành động ─────────────────────────────────────────────────────────────
  const upload = async (kind, file) => {
    if (!selected) return;
    setBusy(kind);
    try {
      const fn = { attendance: 'uploadSheet', exception: 'uploadExceptions', leave: 'uploadLeaves' }[kind];
      const res = await factoryPayrollApi[fn](file, selected.month, selected.year, department);
      setResult(res);
      setResultTitle({
        attendance: 'Kết quả import bảng chấm công',
        exception:  'Kết quả import lịch nghỉ',
        leave:      'Kết quả import đơn xin nghỉ',
      }[kind]);
      toast(`${status?.departmentLabel} · tháng ${selected.month}/${selected.year}: đã xử lý ${res?.matched ?? 0} dòng`, 'success');
      await loadStatus(selected);
    } catch (e) {
      toast(e?.response?.data?.message || e?.message || 'Lỗi tải file', 'error');
    } finally {
      setBusy(null);
    }
  };

  const remove = async (kind) => {
    if (!selected) return;
    setDeleting(kind);
    try {
      await factoryPayrollApi.deleteFile(kind, selected.month, selected.year, department);
      toast('Đã xoá file. Tải file mới rồi bấm "Hoàn tất" lại để tính theo file mới nhất.', 'success');
      await loadStatus(selected);
    } catch (e) {
      toast(e?.response?.data?.message || 'Lỗi xoá file', 'error');
    } finally {
      setDeleting(null);
    }
  };

  const template = async (kind) => {
    if (!selected) return;
    try {
      await factoryPayrollApi.downloadTemplate(kind, selected.month, selected.year, department);
    } catch {
      toast('Không tải được file mẫu', 'error');
    }
  };

  const doFinalize = async () => {
    if (!selected) return;
    setFinalizing(true);
    try {
      await factoryPayrollApi.finalize(selected.month, selected.year, department);
      toast(`Đã hoàn tất lương ${status?.departmentLabel} tháng ${selected.month}/${selected.year}`, 'success');
      await loadStatus(selected);
    } catch (e) {
      toast(e?.response?.data?.message || 'Lỗi hoàn tất', 'error');
    } finally {
      setFinalizing(false);
    }
  };

  const doReopen = async () => {
    if (!selected) return;
    setFinalizing(true);
    try {
      await factoryPayrollApi.reopen(selected.month, selected.year, department);
      toast('Đã mở lại tháng — nhân viên sẽ thấy "Đang xử lý lương"', 'success');
      await loadStatus(selected);
    } catch (e) {
      toast(e?.response?.data?.message || 'Lỗi mở lại', 'error');
    } finally {
      setFinalizing(false);
    }
  };

  const recompute = async () => {
    if (!selected) return;
    setRecomputing(true);
    try {
      await factoryPayrollApi.recomputeKpi(selected.month, selected.year);
      toast(`Đã tính lại thưởng KPI tháng ${selected.month}/${selected.year}`, 'success');
    } catch (e) {
      toast(e?.response?.data?.message || 'Lỗi tính lại KPI', 'error');
    } finally {
      setRecomputing(false);
    }
  };

  const period = selected ? `${String(selected.month).padStart(2, '0')}_${selected.year}` : '—';
  const attendanceBased = department !== 'DRIVER';

  return (
    <div className="p-4 sm:p-6 space-y-5">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <PageHeader icon={ClipboardCheck} title="Bảng chấm công"
          subtitle="Quản lý dữ liệu chấm công & chốt lương theo từng bộ phận — nhân viên xem phiếu lương sau khi bấm Hoàn tất" />
        <div className="flex items-center gap-2 flex-wrap">
          <MonthPicker periods={periods} value={selected} onChange={setSelected} disabled={loading} />
          <SecondaryButton onClick={() => loadStatus(selected)} disabled={loading}>
            <RefreshCw size={14} /> Làm mới
          </SecondaryButton>
        </div>
      </div>

      {loading ? (
        <SectionCard><LoadingSpinner label="Đang tải..." /></SectionCard>
      ) : !selected ? (
        <SectionCard>
          <p className="text-center text-sm text-[#8E8878] py-10">Chưa chọn tháng</p>
        </SectionCard>
      ) : (
        <>
          {/* Tab bộ phận */}
          <DepartmentTabs statuses={statuses} value={department} onChange={setDepartment} />

          {/* Thanh trạng thái + nút HOÀN TẤT */}
          <SectionCard>
            <div className="flex items-center justify-between gap-4 px-5 py-4 flex-wrap">
              <div className="flex items-center gap-3 min-w-0">
                <span className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0
                  ${status?.finalized ? 'bg-emerald-100' : 'bg-amber-50'}`}>
                  {status?.finalized
                    ? <Lock size={17} className="text-emerald-600" />
                    : <Unlock size={17} className="text-amber-600" />}
                </span>
                <div className="min-w-0">
                  <p className="text-sm font-bold text-[#1C1C1E]">
                    {status?.finalized ? 'Đã hoàn tất xử lý lương' : 'Chưa hoàn tất — nhân viên thấy "Đang xử lý lương"'}
                  </p>
                  <p className="text-[11px] text-[#8E8878] mt-0.5">
                    {status?.departmentLabel} · {status?.employeeCount ?? 0} nhân viên
                    {status?.finalized && status?.finalizedAt
                      ? ` · chốt lúc ${formatDateTime(status.finalizedAt)}`
                      : ''}
                    {status?.finalizedByName ? ` bởi ${status.finalizedByName}` : ''}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {status?.finalized ? (
                  <SecondaryButton onClick={doReopen} disabled={finalizing}>
                    <Unlock size={14} /> Mở lại tháng
                  </SecondaryButton>
                ) : (
                  <PrimaryButton onClick={doFinalize} loading={finalizing}
                    disabled={!status?.canFinalize}>
                    <CheckCircle2 size={14} /> Hoàn tất
                  </PrimaryButton>
                )}
              </div>
            </div>

            {!status?.finalized && !status?.canFinalize && attendanceBased && (
              <p className="px-5 pb-4 text-[11px] text-amber-700">
                Cần tải lên bảng chấm công của bộ phận này trước khi bấm Hoàn tất.
              </p>
            )}
          </SectionCard>

          {attendanceBased ? (
            <>
              {/* Đường dẫn lưu trữ */}
              <div className="flex items-center gap-2 text-[11px] text-[#8E8878] bg-[#FAF7F2]
                rounded-xl px-3.5 py-2.5">
                <FileSpreadsheet size={13} className="shrink-0" />
                <span>Cả 3 file của bộ phận này được lưu trong thư mục
                  <strong className="text-[#1C1C1E]"> attendance/{period}/{department}/</strong></span>
              </div>

              {/* 3 khối file */}
              <div className="grid gap-4 lg:grid-cols-3">
                <FileSlot
                  icon={Clock}
                  title="Bảng chấm công"
                  description="File xuất từ máy chấm công, chứa giờ vào/ra từng ngày"
                  hint="Mỗi nhân viên là một block riêng có dòng Mã nhân viên / Tên nhân viên."
                  exists={status?.hasAttendanceFile}
                  fileName={status?.fileName}
                  uploadedAt={status?.uploadedAt}
                  rowCount={status?.parsedRows}
                  rowLabel="nhân viên"
                  uploading={busy === 'attendance'}
                  deleting={deleting === 'attendance'}
                  onUpload={f => upload('attendance', f)}
                  onDelete={() => remove('attendance')}
                />

                <FileSlot
                  icon={CalendarClock}
                  title="Lịch nghỉ / đi trễ / về sớm"
                  description="Áp dụng cho TOÀN BỘ nhân viên của bộ phận trong ngày được khai báo"
                  hint="Tải file mẫu, chọn Loại ở những ngày có ngoại lệ rồi tải lên."
                  exists={status?.hasExceptionFile}
                  fileName={status?.exceptionFileName}
                  uploadedAt={status?.exceptionUploadedAt}
                  rowCount={status?.exceptionRows}
                  rowLabel="ngày"
                  uploading={busy === 'exception'}
                  deleting={deleting === 'exception'}
                  onUpload={f => upload('exception', f)}
                  onDelete={() => remove('exception')}
                  onTemplate={() => template('exception')}
                />

                <FileSlot
                  icon={UserCheck}
                  title="Đơn xin đi trễ / nghỉ phép"
                  description="Đơn của từng cá nhân — chỉ đơn Đã duyệt mới được tính đủ công"
                  hint="Mỗi dòng là 1 đơn, họ tên phải trùng với hồ sơ nhân sự của bộ phận."
                  exists={status?.hasLeaveFile}
                  fileName={status?.leaveFileName}
                  uploadedAt={status?.leaveUploadedAt}
                  rowCount={status?.leaveRows}
                  rowLabel="đơn"
                  uploading={busy === 'leave'}
                  deleting={deleting === 'leave'}
                  onUpload={f => upload('leave', f)}
                  onDelete={() => remove('leave')}
                  onTemplate={() => template('leave')}
                />
              </div>
            </>
          ) : (
            <SectionCard>
              <div className="flex items-start gap-3 px-5 py-5">
                <span className="w-10 h-10 rounded-xl bg-[#FAF7F2] flex items-center justify-center shrink-0">
                  <Truck size={17} className="text-[#C9A84C]" />
                </span>
                <div>
                  <p className="text-sm font-bold text-[#1C1C1E]">Tài xế không dùng bảng chấm công</p>
                  <p className="text-xs text-[#8E8878] mt-1 leading-relaxed max-w-2xl">
                    Số công của tài xế được tính theo <strong>tổng số km chạy mỗi ngày</strong>, ước tính
                    từ các đơn hàng đã và đang giao được phân công trong ngày. Ngày nào kho có chốt odo
                    vào ca / kết ca thì hệ thống lấy đúng số km thật. Bạn chỉ cần bấm
                    <strong> Hoàn tất</strong> để chốt lương tháng cho bộ phận này.
                  </p>
                </div>
              </div>
            </SectionCard>
          )}

          {/* 2 bảng sau khi HOÀN TẤT */}
          {status?.finalized && <PayrollTables data={payroll} loading={loadingPayroll} />}

          {/* Ghi chú cách tính + tính lại KPI (chỉ Xưởng) */}
          {attendanceBased && (
            <SectionCard>
              <div className="flex items-center justify-between gap-3 px-5 py-3.5 border-b border-black/5">
                <h3 className="text-sm font-bold text-[#1C1C1E]">Cách tính công</h3>
                {department === 'FACTORY' && (
                  <button onClick={recompute} disabled={recomputing}
                    className="flex items-center gap-1.5 text-xs font-semibold text-[#C9A84C]
                      hover:underline disabled:opacity-50">
                    <Calculator size={13} />
                    {recomputing ? 'Đang tính...' : 'Tính lại thưởng KPI'}
                  </button>
                )}
              </div>
              <div className="px-5 py-4 grid gap-2.5 sm:grid-cols-2 text-[11px] text-[#5A5548]">
                {[
                  ['Ca chuẩn', '08:00 – 17:00. Vào muộn hơn tính trễ, ra sớm hơn tính về sớm.'],
                  ['Nghỉ cả ngày', 'Đủ 1 công vô điều kiện, kể cả không chấm công.'],
                  ['Nghỉ nửa ngày – Sáng', 'Ca thu còn 13:30 – 17:00.'],
                  ['Nghỉ nửa ngày – Chiều', 'Ca thu còn 08:00 – 12:00.'],
                  ['Đi trễ có phép', 'Mốc 10:00 → vào 10:00 đủ công, vào 10:01 trễ 1 phút.'],
                  ['Về sớm có phép', 'Mốc 14:00 → ra 14:00 đủ công, ra 13:59 sớm 1 phút.'],
                  ['Thiếu giờ vào hoặc giờ ra', 'Không có ngoại lệ thì ngày đó 0 công.'],
                  ['Đơn cá nhân', 'Ghi đè lịch bộ phận. Chỉ trạng thái Đã duyệt mới có hiệu lực.'],
                  ['Nhân viên kiêm nhiệm', 'Chỉ tính ở bộ phận của ROLE NHẬN LƯƠNG, không nằm ở 2 bộ phận.'],
                  ['Đổi file sau khi hoàn tất', 'Xoá file cũ → tải file mới → bấm Hoàn tất lại để tính theo file mới nhất.'],
                ].map(([k, v]) => (
                  <div key={k} className="flex gap-2">
                    <span className="text-[#C9A84C] shrink-0">•</span>
                    <span><strong className="text-[#1C1C1E]">{k}</strong> — {v}</span>
                  </div>
                ))}
              </div>
            </SectionCard>
          )}

          {status?.note && (
            <div className="flex items-start gap-2 bg-amber-50 border border-amber-200 rounded-xl px-4 py-3">
              <AlertCircle size={15} className="text-amber-600 shrink-0 mt-0.5" />
              <p className="text-xs text-amber-800 leading-snug">{status.note}</p>
            </div>
          )}
        </>
      )}

      {result && (
        <ImportResultModal result={result} title={resultTitle} onClose={() => setResult(null)} />
      )}
    </div>
  );
}