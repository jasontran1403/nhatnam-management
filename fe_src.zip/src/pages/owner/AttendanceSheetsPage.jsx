// src/pages/owner/AttendanceSheetsPage.jsx
// BẢNG CHẤM CÔNG — OWNER quản lý dữ liệu lương theo THÁNG × BỘ PHẬN.
//
//   Bộ phận:  Xưởng sản xuất · Kinh doanh · Kho · Kế toán · Tài xế
//
//   Mỗi bộ phận (trừ Tài xế) có 3 loại file RIÊNG cho mỗi tháng:
//     1. Bảng chấm công (xuất từ máy chấm công)
//     2. Lịch nghỉ / đi trễ / về sớm
//     3. Đơn xin đi trễ / về sớm / nghỉ phép của cá nhân
//   Mỗi loại tối đa 1 file/tháng — đã có thì phải xoá rồi mới tải lại được.
//
//   Xử lý xong → bấm "HOÀN TẤT". Lúc đó nhân viên của bộ phận mới xem được
//   phiếu lương; chưa hoàn tất thì họ thấy "Đang xử lý lương".
//   Hoàn tất rồi vẫn xoá/đổi file được — cờ hoàn tất tự gỡ, bấm Hoàn tất lần
//   nữa sẽ tính lại theo file MỚI NHẤT.
import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  ClipboardCheck, Upload, RefreshCw, AlertCircle, CheckCircle2, Trash2,
  FileSpreadsheet, Calculator, Download, CalendarDays, ChevronDown, Gift, Wallet,
  CalendarClock, UserCheck, Clock, Lock, Unlock, Users, Receipt, Truck, Route, ShieldCheck,
  PiggyBank, Plus, X, Search, CornerDownRight, MapPin, User as UserIcon, Package, Eye, Award,
  Landmark, Hash, Percent, TrendingUp, Settings, Check,
} from 'lucide-react';
import { factoryPayrollApi } from '../../api/factoryPayrollApi';
import { companyPayrollApi } from '../../api/companyPayrollApi';
import CompanyPayrollPanel from './CompanyPayrollPanel';   // Phase 3 — panel chung
import { BackButton } from '../../components/common/SubPageNav';
import { useNavigate } from 'react-router-dom';
import {
  PageHeader, SectionCard, LoadingSpinner, SecondaryButton, PrimaryButton,
  Table, Thead, Th, Td, Tr, EmptyState, formatDateTime, formatCurrency,
} from '../../components/ui';
import Modal from '../../components/ui/Modal';
import { SalesBonusV2ConfigModal, SalesBonusV2ReviewModal } from './SalesBonusV2Modals';
import AttendanceDayCalendar from '../../components/hr/AttendanceDayCalendar';
import { useToast } from '../../components/common/Toast';
import ConfirmModal from '../../components/common/ConfirmModal';
import SalaryBreakdownCards from '../../components/hr/SalaryBreakdownCards';

const fmtNum = (v, d = 2) =>
  v == null ? '—' : Number(v).toLocaleString('vi-VN', { maximumFractionDigits: d });

// (10/2026) Phân loại nhân viên "chính" của phòng vs "hỗ trợ" (NV phòng khác
// có doanh thu / tham gia tính hoa hồng). Dùng chung với AccountantBonusViewPage.
const _normNoAccent = (s) => (s || '').toString().toLowerCase()
  .normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd');
function isSupportForDept(dept, roleLabel) {
  const r = _normNoAccent(roleLabel);
  if (!r) return false;
  if (dept === 'SALES')      return !r.includes('kinh doanh');
  if (dept === 'ACCOUNTING') return !r.includes('ke toan');
  return false;
}

// ══════════════════════════════════════════════════════════════════════════════
// CHỌN THÁNG — tháng hiện tại + quá khứ, KHÔNG có tương lai
// ══════════════════════════════════════════════════════════════════════════════

export function MonthPicker({ periods, value, onChange, disabled }) {
  const [open, setOpen] = useState(false);
  const current = periods.find(p => p.month === value?.month && p.year === value?.year);

  const grouped = periods.reduce((acc, p) => {
    (acc[p.year] ||= []).push(p);
    return acc;
  }, {});

  return (
    <div className="relative">
      <button onClick={() => setOpen(o => !o)} disabled={disabled || !periods.length}
        className="flex items-center gap-2.5 px-4 py-2.5 rounded-2xl bg-surface border border-hairline-2
          shadow-sm hover:border-gold/50 transition-colors disabled:opacity-50 min-w-[190px]">
        <CalendarDays size={16} className="text-gold shrink-0" />
        <span className="flex-1 text-left text-sm font-bold text-ink">
          {current?.label || 'Chọn tháng'}
        </span>
        <ChevronDown size={15} className={`text-muted transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-20" onClick={() => setOpen(false)} />
          <div className="absolute z-30 mt-2 w-full min-w-[220px] max-h-[360px] overflow-y-auto
            bg-surface rounded-2xl border border-hairline-2 shadow-xl p-2">
            {Object.entries(grouped).sort((a, b) => b[0] - a[0]).map(([year, items]) => (
              <div key={year} className="mb-1 last:mb-0">
                <p className="px-3 py-1.5 text-[11px] font-bold uppercase tracking-wider text-muted">
                  Năm {year}
                </p>
                {items.map(p => {
                  const active = p.month === value?.month && p.year === value?.year;
                  return (
                    <button key={`${p.year}-${p.month}`}
                      onClick={() => { onChange(p); setOpen(false); }}
                      className={`w-full flex items-center justify-between gap-2 px-3 py-2 rounded-xl
                        text-sm transition-colors
                        ${active ? 'bg-gold text-white font-bold' : 'text-ink hover:bg-canvas'}`}>
                      <span>Tháng {p.month}</span>
                      {p.finalized && (
                        <CheckCircle2 size={13} className={active ? 'text-white' : 'text-emerald-500'} />
                      )}
                    </button>
                  );
                })}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// TAB BỘ PHẬN
// ══════════════════════════════════════════════════════════════════════════════

// Gõ tiền kiểu Việt Nam: chỉ giữ chữ số, chèn dấu chấm ngăn cách hàng nghìn.
// Giữ ở dạng chuỗi trong state để người dùng xoá trắng được (số 0 sẽ dính lại).
const formatVnInt = (v) => {
  const d = String(v ?? '').replace(/[^\d]/g, '');
  return d ? Number(d).toLocaleString('vi-VN') : '';
};

/**
 * MODAL "CHI TIẾT BỘ PHẬN" — ai đang thuộc bộ phận này ngay lúc mở.
 *
 * Không gắn với kỳ lương nào: dùng để đối chiếu nhân sự TRƯỚC khi tải bảng chấm
 * công lên, nên phải phản ánh hiện trạng chứ không phải ảnh chụp của tháng.
 */
function DepartmentMembersModal({ open, department, departmentLabel, onClose }) {
  const toast = useToast();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open || !department) return;
    let alive = true;
    (async () => {
      setLoading(true);
      try {
        const d = await factoryPayrollApi.departmentMembers(department);
        if (alive) setData(d);
      } catch (e) {
        if (alive) toast(e?.response?.data?.message || 'Không tải được danh sách nhân sự', 'error');
      } finally {
        if (alive) setLoading(false);
      }
    })();
    // Cờ alive chặn setState sau khi modal đã đóng — đổi bộ phận liên tục sẽ
    // khiến response cũ về sau response mới và ghi đè danh sách đúng.
    return () => { alive = false; };
  }, [open, department, toast]);

  const members = data?.members ?? [];

  return (
    <Modal
      open={open}
      onClose={onClose}
      size="lg"
      title={`Chi tiết bộ phận — ${departmentLabel || ''}`}
    >
      {loading ? (
        <LoadingSpinner label="Đang tải danh sách…" />
      ) : members.length === 0 ? (
        <EmptyState
          icon={Users}
          title="Bộ phận chưa có nhân viên"
          description="Gán bộ phận cho nhân viên ở trang Nhân sự để họ xuất hiện tại đây."
        />
      ) : (
        <div className="space-y-3">
          <p className="text-xs text-muted">{data.total} nhân viên</p>
          <Table>
            <Thead>
              <Tr className="bg-canvas text-muted">
                <Th>Nhân viên</Th>
                <Th>Chức vụ</Th>
                <Th>Chức danh trả lương</Th>
              </Tr>
            </Thead>
            <tbody>
              {members.map(m => (
                <Tr key={m.userId}>
                  <Td>
                    <div className="font-medium text-ink">{m.fullName}</div>
                    <div className="flex flex-wrap gap-1.5 mt-1">
                      {!m.hasSalary && (
                        <span className="text-[10px] font-semibold text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-500/10
                          border border-amber-200 dark:border-amber-500/28 rounded px-1.5 py-0.5">
                          chưa có hồ sơ lương
                        </span>
                      )}
                      {m.attendanceExempt && (
                        <span className="text-[10px] font-semibold text-muted bg-canvas
                          border border-hairline-2 rounded px-1.5 py-0.5">
                          không chấm công
                        </span>
                      )}
                    </div>
                  </Td>
                  <Td className="text-ink">
                    {m.position || <span className="text-faint">—</span>}
                    {m.division && (
                      <div className="text-[11px] text-muted">{m.division}</div>
                    )}
                  </Td>
                  {/* Lệch với cột Chức vụ nghĩa là người này đang được tính lương
                      ở bộ phận khác với hồ sơ — đáng để OWNER để ý. */}
                  <Td className="text-muted">{m.roleLabel || '—'}</Td>
                </Tr>
              ))}
            </tbody>
          </Table>
        </div>
      )}
    </Modal>
  );
}

function DepartmentTabs({ statuses, value, onChange }) {
  // Phase 3 (10/2026): MANAGEMENT đã bị gỡ khỏi hệ thống tính lương. Lọc an
  // toàn ở FE phòng khi BE legacy vẫn còn trả về bản ghi cũ cho tháng chưa
  // migrate.
  const visibleStatuses = statuses.filter(s => s.department !== 'MANAGEMENT');
  return (
    <div className="flex gap-1.5 overflow-x-auto pb-1 -mx-1 px-1">
      {visibleStatuses.map(s => {
        const active = s.department === value;
        return (
          <button key={s.department} onClick={() => onChange(s.department)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-sm font-bold
              whitespace-nowrap border transition-colors shrink-0
              ${active
                ? 'bg-chrome text-white border-chrome'
                : 'bg-surface text-ink border-hairline-2 hover:border-gold/50'}`}>
            {(() => {
              // Tài xế có biểu tượng riêng; các bộ phận còn lại dùng icon Users
              // chung (MANAGEMENT đã gỡ).
              const Icon = s.department === 'DRIVER' ? Truck : Users;
              return <Icon size={14} className={active ? 'text-gold' : 'text-muted'} />;
            })()}
            <span>{s.departmentLabel}</span>
            <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-md
              ${active ? 'bg-white/15 text-white/80' : 'bg-canvas text-muted'}`}>
              {s.employeeCount ?? 0}
            </span>
            {s.finalized && (
              <CheckCircle2 size={13} className={active ? 'text-emerald-400' : 'text-emerald-500'} />
            )}
            {s.finalized && !s.kpiFinalized && (
              <span className={`text-[9px] font-bold px-1 py-0.5 rounded
                ${active ? 'bg-amber-400/30 text-amber-200' : 'bg-amber-100 text-amber-700'}`}>
                KPI?
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// KHỐI 1 LOẠI FILE
// ══════════════════════════════════════════════════════════════════════════════

function FileSlot({ icon: Icon, title, description, hint,
  exists, fileName, uploadedAt, rowCount, rowLabel,
  onUpload, onDelete, onTemplate, uploading, deleting }) {
  const fileRef = useRef(null);

  return (
    <div className={`rounded-2xl border overflow-hidden transition-colors
      ${exists ? 'border-emerald-200 dark:border-emerald-500/28 bg-emerald-50/30 dark:bg-emerald-500/4' : 'border-hairline-2 bg-surface'}`}>

      <div className="flex items-start gap-3 px-4 py-3.5 border-b border-hairline">
        <span className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0
          ${exists ? 'bg-emerald-100 dark:bg-emerald-500/18' : 'bg-canvas'}`}>
          <Icon size={16} className={exists ? 'text-emerald-600 dark:text-emerald-300' : 'text-muted'} />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-bold text-ink leading-tight">{title}</p>
          <p className="text-[11px] text-muted mt-0.5 leading-snug">{description}</p>
        </div>
        {exists && (
          <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-1 rounded-lg
            bg-emerald-100 dark:bg-emerald-500/18 text-emerald-700 dark:text-emerald-300 shrink-0">
            <CheckCircle2 size={11} /> Đã có
          </span>
        )}
      </div>

      {exists && (
        <div className="px-4 py-2.5 bg-surface/60 border-b border-hairline">
          <p className="text-[11px] text-ink-2 truncate" title={fileName}>{fileName || '—'}</p>
          <p className="text-[10px] text-muted mt-0.5">
            {uploadedAt ? formatDateTime(uploadedAt) : '—'}
            {rowCount != null && ` · ${rowCount} ${rowLabel}`}
          </p>
        </div>
      )}

      <div className="px-4 py-3 space-y-2">
        {hint && !exists && <p className="text-[10px] text-muted leading-snug">{hint}</p>}

        <div className="flex gap-2">
          {onTemplate && (
            <button onClick={onTemplate}
              className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-[11px]
                font-semibold bg-surface border border-hairline-2 text-ink
                hover:bg-canvas transition-colors shrink-0">
              <Download size={12} /> Tải mẫu
            </button>
          )}

          {!exists ? (
            <label className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl
              text-[11px] font-bold text-white transition-colors
              ${uploading ? 'bg-faint cursor-wait' : 'bg-gold hover:bg-gold-deep cursor-pointer'}`}>
              {uploading ? (
                <>
                  <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Đang xử lý
                </>
              ) : (
                <><Upload size={12} /> Tải file lên</>
              )}
              <input ref={fileRef} type="file" accept=".xlsx,.xls" className="hidden" disabled={uploading}
                onChange={e => { if (e.target.files[0]) { onUpload(e.target.files[0]); e.target.value = ''; } }} />
            </label>
          ) : (
            <button onClick={onDelete} disabled={deleting}
              className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl
                text-[11px] font-bold bg-surface border border-red-200 dark:border-red-500/28 text-red-600 dark:text-red-300
                hover:bg-red-50 dark:bg-red-500/10 transition-colors disabled:opacity-50">
              <Trash2 size={12} />
              {deleting ? 'Đang xoá...' : 'Xoá file cũ, tải lại'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// BÁO CÁO KẾT QUẢ IMPORT — file có bao nhiêu NV, thiếu của ai
// ══════════════════════════════════════════════════════════════════════════════

function ImportResultModal({ result, title, onClose }) {
  const [tab, setTab] = useState('unmatched');
  if (!result) return null;

  const matched = result.matchedRows || [];
  const unmatched = result.unmatchedRows || [];
  const unused = result.unusedBlocks || [];
  const MATCH_LABEL = { CODE: 'mã chấm công', EXACT_NAME: 'họ tên' };

  const tabs = [
    { id: 'unmatched', label: `Thiếu (${unmatched.length})`, show: true },
    { id: 'matched', label: `Đã khớp (${matched.length})`, show: matched.length > 0 },
    { id: 'unused', label: `Không dùng (${unused.length})`, show: unused.length > 0 },
  ].filter(t => t.show);

  return (
    <Modal open onClose={onClose} title={title} size="md">
      <div className="space-y-3 py-1">
        {/* Tóm tắt: file có bao nhiêu người / khớp / thiếu */}
        <div className="grid grid-cols-4 gap-2">
          {[
            { label: 'NV trong file', value: result.blocksInFile ?? 0, color: 'text-ink' },
            { label: 'NV bộ phận', value: result.departmentEmployees ?? 0, color: 'text-ink' },
            { label: 'Đã khớp', value: result.matched ?? 0, color: 'text-emerald-600 dark:text-emerald-300' },
            { label: 'Thiếu', value: result.skipped ?? 0, color: 'text-amber-600 dark:text-amber-300' },
          ].map(s => (
            <div key={s.label} className="bg-canvas rounded-xl px-2 py-2.5 text-center">
              <p className="text-[10px] text-muted font-semibold leading-tight">{s.label}</p>
              <p className={`text-xl font-bold mt-0.5 ${s.color}`}>{s.value}</p>
            </div>
          ))}
        </div>

        {result.departmentLabel && (
          <p className="text-[11px] text-muted">
            Bộ phận: <strong className="text-ink">{result.departmentLabel}</strong>
            {' · '}Tháng {result.month}/{result.year}
          </p>
        )}

        {result.skipped > 0 && (
          <div className="flex items-start gap-2 bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/28 rounded-xl px-3 py-2.5">
            <AlertCircle size={14} className="text-amber-600 dark:text-amber-300 shrink-0 mt-0.5" />
            <p className="text-[11px] text-amber-800 dark:text-amber-300 leading-snug">
              File thiếu dữ liệu của <strong>{result.skipped} nhân viên</strong> —
              xem danh sách ở tab "Thiếu". Những người này sẽ được ghi nhận 0 công cho tháng.
            </p>
          </div>
        )}

        {tabs.length > 1 && (
          <div className="flex gap-1 bg-canvas rounded-xl p-1">
            {tabs.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`flex-1 px-2 py-1.5 rounded-lg text-[11px] font-semibold transition-colors
                  ${tab === t.id ? 'bg-surface text-ink shadow-sm' : 'text-muted hover:text-ink'}`}>
                {t.label}
              </button>
            ))}
          </div>
        )}

        <div className="max-h-52 overflow-y-auto rounded-xl border border-hairline divide-y divide-hairline">
          {tab === 'matched' && (matched.length === 0
            ? <p className="text-[11px] text-muted text-center py-6">Không có dữ liệu</p>
            : matched.map((r, i) => (
              <div key={r.userId ?? i} className="flex items-center justify-between gap-3 px-3 py-2.5">
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-ink truncate">{r.fullName}</p>
                  <p className="text-[10px] text-muted truncate">
                    {r.roleLabel || '—'}
                    {r.employeeCode ? ` · mã ${r.employeeCode}` : ''}
                    {r.matchedBy ? ` · khớp theo ${MATCH_LABEL[r.matchedBy] || r.matchedBy}` : ''}
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-xs font-bold text-emerald-600 dark:text-emerald-300">{r.actualDays ?? 0} công</p>
                  <p className="text-[10px] text-muted">{r.presentDays ?? 0} ngày chấm</p>
                </div>
              </div>
            )))}

          {tab === 'unmatched' && (unmatched.length === 0
            ? <p className="text-[11px] text-emerald-700 dark:text-emerald-300 text-center py-6">
              Không có ai bị bỏ sót — file đủ toàn bộ nhân viên của bộ phận.
            </p>
            : unmatched.map((r, i) => (
              <div key={r.userId ?? i} className="px-3 py-2.5">
                <p className="text-xs font-semibold text-ink">{r.fullName}</p>
                <p className="text-[10px] text-muted">
                  {r.roleLabel || 'Không tìm thấy trong hệ thống'}
                </p>
              </div>
            )))}

          {tab === 'unused' && unused.map((u, i) => (
            <p key={i} className="px-3 py-2 text-[11px] text-ink-2">{u}</p>
          ))}
        </div>

        {result.errors?.length > 0 && (
          <details className="bg-canvas rounded-xl px-3 py-2.5">
            <summary className="text-[11px] font-semibold text-muted cursor-pointer">
              {result.errors.length} cảnh báo khi đọc file
            </summary>
            <div className="mt-2 space-y-1 max-h-32 overflow-y-auto">
              {result.errors.map((e, i) => (
                <p key={i} className="text-[10px] text-amber-700 dark:text-amber-300 leading-snug">{e}</p>
              ))}
            </div>
          </details>
        )}
      </div>
    </Modal>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// KẾT QUẢ IMPORT THƯỞNG / PHỤ CẤP
// ══════════════════════════════════════════════════════════════════════════════
//
// Modal riêng, KHÔNG dùng chung ImportResultModal của bảng chấm công vì kết quả
// ở đó theo cấu trúc khớp/không khớp từng người, còn ở đây là lỗi theo DÒNG.

function AdjustmentResultModal({ result, title, onClose }) {
  if (!result) return null;

  const savedItems = result.savedItems || [];
  const unmatched = result.unmatchedItems || [];
  const errors = result.errors || [];
  const warnings = result.warnings || [];

  const savedTotal = savedItems.reduce((s, i) => s + (i.amount || 0), 0);
  const newItems = savedItems.filter(i => !i.alreadyExisted);
  const existedItems = savedItems.filter(i => i.alreadyExisted);

  return (
    <Modal open onClose={onClose} title={title} size="lg">
      <div className="space-y-4 py-1">
        {/* Tóm tắt */}
        <div className="grid gap-2 sm:grid-cols-3">
          <div className="rounded-xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/28 px-3 py-2.5">
            <p className="text-[10px] uppercase font-bold text-emerald-700 dark:text-emerald-300 tracking-wider">Đã lưu</p>
            <p className="text-sm font-bold text-ink mt-0.5">{result.saved ?? 0} khoản</p>
            {result.totalAmount > 0 && <p className="text-[10px] text-muted">{formatCurrency(result.totalAmount)}</p>}
          </div>
          {existedItems.length > 0 && (
            <div className="rounded-xl bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/28 px-3 py-2.5">
              <p className="text-[10px] uppercase font-bold text-amber-700 dark:text-amber-300 tracking-wider">Đã có sẵn</p>
              <p className="text-sm font-bold text-ink mt-0.5">{existedItems.length} người</p>
              <p className="text-[10px] text-muted">bỏ qua, giữ số cũ</p>
            </div>
          )}
          {unmatched.length > 0 && (
            <div className="rounded-xl bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/28 px-3 py-2.5">
              <p className="text-[10px] uppercase font-bold text-red-700 dark:text-red-300 tracking-wider">Không tìm thấy</p>
              <p className="text-sm font-bold text-ink mt-0.5">{unmatched.length} dòng</p>
              <p className="text-[10px] text-muted">import nhầm file / sai tên</p>
            </div>
          )}
        </div>

        {/* PHẦN 1: Danh sách đã xử lý */}
        {savedItems.length > 0 && (
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wide text-emerald-700 dark:text-emerald-300 mb-1.5">
              Nhân viên đã xử lý ({savedItems.length}) · Tổng {formatCurrency(savedTotal)}
            </p>
            <div className="rounded-xl border border-emerald-200 dark:border-emerald-500/28 overflow-hidden max-h-64 overflow-y-auto">
              <table className="w-full text-xs">
                <thead className="bg-emerald-50 dark:bg-emerald-500/10 sticky top-0">
                  <tr className="text-left text-emerald-700 dark:text-emerald-300">
                    <th className="px-3 py-1.5 font-semibold">Nhân viên</th>
                    <th className="px-3 py-1.5 font-semibold">Khoản</th>
                    <th className="px-3 py-1.5 font-semibold text-right">Số tiền</th>
                    <th className="px-3 py-1.5 font-semibold text-center">Ghi chú</th>
                  </tr>
                </thead>
                <tbody>
                  {savedItems.map((it, i) => (
                    <tr key={i} className="border-t border-emerald-100 dark:border-emerald-500/20">
                      <td className="px-3 py-1.5 font-medium text-ink">{it.employeeName || `#${it.userId}`}</td>
                      <td className="px-3 py-1.5 text-ink">{it.label || '—'}</td>
                      <td className="px-3 py-1.5 text-right font-semibold text-gold">{formatCurrency(it.amount)}</td>
                      <td className="px-3 py-1.5 text-center text-[10px]">
                        {it.alreadyExisted
                          ? <span className="text-amber-600 dark:text-amber-300">Đã có, giữ nguyên</span>
                          : <span className="text-emerald-600 dark:text-emerald-300">Thêm mới</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* PHẦN 2: Không tìm thấy — thường do import nhầm file khác bộ phận */}
        {unmatched.length > 0 && (
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wide text-red-600 dark:text-red-300 mb-1.5">
              Không tìm thấy nhân viên ({unmatched.length})
            </p>
            <p className="text-[10px] text-muted mb-1.5">
              Các dòng dưới đây không khớp được nhân viên nào trong bộ phận. Kiểm tra
              xem có phải import nhầm file của bộ phận khác không, hoặc tên bị gõ sai.
            </p>
            <div className="rounded-xl border border-red-200 dark:border-red-500/28 overflow-hidden max-h-56 overflow-y-auto">
              <table className="w-full text-xs">
                <thead className="bg-red-50 dark:bg-red-500/10 sticky top-0">
                  <tr className="text-left text-red-700 dark:text-red-300">
                    <th className="px-3 py-1.5 font-semibold">Dòng</th>
                    <th className="px-3 py-1.5 font-semibold">Tên trong file</th>
                    <th className="px-3 py-1.5 font-semibold">Khoản / lý do</th>
                    <th className="px-3 py-1.5 font-semibold text-right">Số tiền</th>
                  </tr>
                </thead>
                <tbody>
                  {unmatched.map((it, i) => (
                    <tr key={i} className="border-t border-red-100 dark:border-red-500/20">
                      <td className="px-3 py-1.5 text-muted">{it.rowNumber}</td>
                      <td className="px-3 py-1.5 font-medium text-ink">
                        {it.rawName || <span className="italic text-muted">(trống)</span>}
                        {it.rawIdString && <span className="text-[10px] text-muted ml-1">ID: {it.rawIdString}</span>}
                      </td>
                      <td className="px-3 py-1.5 text-[11px]">
                        {it.label && <div className="text-ink">{it.label}</div>}
                        <div className="text-red-600 dark:text-red-300 text-[10px]">{it.reason}</div>
                      </td>
                      <td className="px-3 py-1.5 text-right text-ink">
                        {it.amount != null ? formatCurrency(it.amount) : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Cảnh báo/lỗi khác (VD nhãn phụ cấp không có trong danh mục) */}
        {errors.length > 0 && (
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wide text-red-600 dark:text-red-300 mb-1.5">
              Lỗi khác ({errors.length})
            </p>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {errors.map((e, i) => (
                <p key={i} className="text-[11px] text-red-800 dark:text-red-300 bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/28
                  rounded-lg px-3 py-2 leading-snug">{e}</p>
              ))}
            </div>
          </div>
        )}

        {warnings.length > 0 && (
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wide text-amber-600 dark:text-amber-300 mb-1.5">
              Cảnh báo ({warnings.length})
            </p>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {warnings.map((w, i) => (
                <p key={i} className="text-[11px] text-amber-800 dark:text-amber-300 bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/28
                  rounded-lg px-3 py-2 leading-snug">{w}</p>
              ))}
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// THẺ IMPORT THƯỞNG / PHỤ CẤP THEO THÁNG
// ══════════════════════════════════════════════════════════════════════════════
//
// Khác FileSlot ở chỗ KHÔNG lưu file gốc — dữ liệu được đọc thẳng vào bảng
// monthly_adjustment. Vì vậy chỉ hiện SỐ DÒNG đã import, và nút "Xoá" là xoá dữ
// liệu của kỳ chứ không phải xoá file.

function AdjustmentSlot({ icon: Icon, title, description, hint, count, rowLabel,
  onUpload, onClear, onTemplate, uploading, clearing,
  batches, onDeleteBatch, deletingLabel, onPreview }) {
  const fileRef = useRef(null);
  const has = (count ?? 0) > 0;
  const isBonus = Array.isArray(batches);

  return (
    <div className={`rounded-2xl border overflow-hidden transition-colors
      ${has ? 'border-emerald-200 dark:border-emerald-500/28 bg-emerald-50/30 dark:bg-emerald-500/4' : 'border-hairline-2 bg-surface'}`}>

      <div className="flex items-start gap-3 px-4 py-3.5 border-b border-hairline">
        <span className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0
          ${has ? 'bg-emerald-100 dark:bg-emerald-500/18' : 'bg-canvas'}`}>
          <Icon size={16} className={has ? 'text-emerald-600 dark:text-emerald-300' : 'text-muted'} />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-bold text-ink leading-tight">{title}</p>
          <p className="text-[11px] text-muted mt-0.5 leading-snug">{description}</p>
        </div>
        {has && (
          <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-1 rounded-lg
            bg-emerald-100 dark:bg-emerald-500/18 text-emerald-700 dark:text-emerald-300 shrink-0">
            <CheckCircle2 size={11} /> {count} {rowLabel}
          </span>
        )}
      </div>

      <div className="px-4 py-3.5 space-y-3">
        <p className="text-[11px] text-muted leading-relaxed">{hint}</p>

        {/* Liệt kê TỪNG KHOẢN đã tải lên (BONUS). Mỗi khoản có nút Xem + Xoá. */}
        {isBonus && batches.length > 0 && (
          <div className="space-y-1.5">
            {batches.map(b => (
              <div key={b.label}
                className="flex items-center gap-2 px-2.5 py-2 rounded-xl bg-surface border border-hairline-2">
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold text-ink truncate">{b.label}</p>
                  <p className="text-[10px] text-muted">
                    {b.employeeCount} người · {formatCurrency(b.totalAmount)}
                  </p>
                </div>
                {onPreview && (
                  <button
                    onClick={() => onPreview('BONUS', b.label)}
                    title={`Xem lại nội dung khoản "${b.label}"`}
                    className="p-1.5 rounded-lg text-muted hover:text-gold hover:bg-canvas transition-colors shrink-0">
                    <Eye size={13} />
                  </button>
                )}
                {onDeleteBatch && (
                  <button
                    onClick={() => onDeleteBatch(b.label)}
                    disabled={deletingLabel === b.label}
                    title={`Xoá khoản "${b.label}"`}
                    className="p-1.5 rounded-lg text-muted hover:text-red-600 dark:text-red-300 hover:bg-red-50 dark:bg-red-500/10
                      transition-colors shrink-0 disabled:opacity-50">
                    <Trash2 size={13} />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Phụ cấp: nút Xem toàn khối (không có batch riêng). */}
        {!isBonus && has && onPreview && (
          <button type="button" onClick={() => onPreview('ALLOWANCE')}
            className="w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl border border-hairline-2
              bg-surface hover:bg-canvas text-ink text-[11px] font-semibold transition-colors">
            <Eye size={13} /> Xem lại nội dung đã import
          </button>
        )}

        <input ref={fileRef} type="file" accept=".xlsx,.xls" className="hidden"
          onChange={e => {
            const f = e.target.files?.[0];
            // Reset value để chọn LẠI CÙNG một file vẫn kích hoạt onChange
            e.target.value = '';
            if (f) onUpload(f);
          }} />

        <div className="flex items-center gap-2">
          <SecondaryButton onClick={onTemplate} className="shrink-0">
            <Download size={14} /> Tải mẫu
          </SecondaryButton>
          <PrimaryButton onClick={() => fileRef.current?.click()}
            disabled={uploading} className="flex-1 justify-center">
            <Upload size={14} /> {uploading ? 'Đang tải lên...' : 'Tải file lên'}
          </PrimaryButton>
        </div>

        {has && (
          <button type="button" onClick={onClear} disabled={clearing}
            className="w-full flex items-center justify-center gap-1.5 text-[11px] font-semibold
              text-red-500 hover:text-red-600 dark:text-red-300 py-1.5 rounded-lg hover:bg-red-50 dark:bg-red-500/10
              transition-colors disabled:opacity-50">
            <Trash2 size={13} /> {clearing ? 'Đang xoá...' : 'Xoá dữ liệu đã import'}
          </button>
        )}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// TỔNG HỢP QUỸ THƯỞNG KPI — hiện sau khi đã tính
// ══════════════════════════════════════════════════════════════════════════════

export function KpiSummary({ kpi }) {
  if (!kpi) return null;

  const pool = kpi.bonusPool ?? 0;
  const carryIn = kpi.carryOverIn ?? 0;
  const distributed = (kpi.distributedTotal ?? 0) + (kpi.securityTotal ?? 0);
  const remaining = kpi.carryOverOut ?? 0;
  const detail = kpi.carryOverInDetail || [];

  const cards = [
    {
      label: 'Tổng sản lượng tháng', value: `${fmtNum(kpi.totalOutputKg)} kg`,
      sub: `${fmtNum(kpi.totalOutputTon, 4)} tấn`
    },
    { label: 'Đơn giá thưởng', value: `${formatCurrency(kpi.ratePerTon)}`, sub: 'mỗi tấn' },
    {
      label: 'Tổng bonus tháng', value: formatCurrency(pool), gold: true,
      sub: 'sản lượng × đơn giá'
    },
    {
      label: 'Quỹ dư các tháng trước', value: formatCurrency(carryIn),
      sub: detail.length ? detail.map(c => `${formatCurrency(c.amount)} · ${c.label}`).join(' — ') : 'không có'
    },
    {
      label: 'Đã chia cho nhân viên', value: formatCurrency(distributed),
      sub: 'gồm cả thưởng cố định của bảo vệ'
    },
    {
      label: 'Còn lại chưa chia', value: formatCurrency(remaining), gold: true,
      sub: 'chuyển sang quỹ tháng sau'
    },
  ];

  // (10/2026) Danh sách CHI TIẾT NV được chia — hiện cho OWNER và Kế Toán
  // Trưởng. Bảo vệ (fixedAmountRole = true) hiển thị "Thưởng cố định".
  //   • Nhóm thường: sort theo weight DESC rồi amount DESC
  //   • Nhóm bảo vệ (cố định): hiện cuối, có badge
  const items = Array.isArray(kpi.items) ? kpi.items : [];
  const regular = items
    .filter(i => !i.fixedAmountRole)
    .slice()
    .sort((a, b) => (b.amount || 0) - (a.amount || 0));
  const fixed = items
    .filter(i => i.fixedAmountRole)
    .slice()
    .sort((a, b) => (b.amount || 0) - (a.amount || 0));

  return (
    <SectionCard>
      <div className="flex items-center gap-2 px-5 py-4 border-b border-hairline">
        <Calculator size={16} className="text-gold" />
        <h3 className="text-sm font-bold text-ink">Quỹ thưởng KPI sản xuất</h3>
      </div>
      <div className="p-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {cards.map(c => (
          <div key={c.label}
            className={`rounded-xl px-4 py-3 border
              ${c.gold ? 'bg-gold/10 border-gold/25' : 'bg-canvas border-transparent'}`}>
            <p className="text-[11px] text-muted font-medium">{c.label}</p>
            <p className={`text-lg font-bold mt-0.5 leading-tight
              ${c.gold ? 'text-gold' : 'text-ink'}`}>{c.value}</p>
            {c.sub && <p className="text-[10px] text-muted mt-1 leading-snug">{c.sub}</p>}
          </div>
        ))}
      </div>

      {/* ── Chi tiết NV được chia (10/2026) ─────────────────────────────── */}
      {items.length > 0 && (
        <div className="border-t border-hairline">
          <div className="flex items-center justify-between px-5 py-3">
            <h4 className="text-xs font-bold text-ink uppercase tracking-wider">
              Chi tiết nhân viên được chia ({items.length} người)
            </h4>
          </div>
          <div className="px-5 pb-4">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-[11px] uppercase tracking-wider text-muted border-b border-hairline">
                  <th className="py-1.5 font-semibold">Nhân viên</th>
                  <th className="py-1.5 font-semibold">Chức vụ</th>
                  <th className="py-1.5 text-right font-semibold">Thưởng sản xuất</th>
                </tr>
              </thead>
              <tbody>
                {regular.map(i => (
                  <tr key={i.userId || i.userFullName} className="border-b border-hairline/40 last:border-0">
                    <td className="py-1.5 text-ink">{i.userFullName}</td>
                    <td className="py-1.5 text-muted">{i.roleLabel || '—'}</td>
                    <td className="py-1.5 text-right font-semibold text-ink">
                      {formatCurrency(i.amount || 0)}
                    </td>
                  </tr>
                ))}
                {fixed.map(i => (
                  <tr key={i.userId || i.userFullName} className="border-b border-hairline/40 last:border-0 bg-amber-50/40 dark:bg-amber-900/10">
                    <td className="py-1.5 text-ink">{i.userFullName}</td>
                    <td className="py-1.5 text-muted">
                      {i.roleLabel || '—'}
                      <span className="ml-1.5 inline-block text-[10px] px-1.5 py-0.5 rounded
                                       bg-amber-100 dark:bg-amber-500/20 text-amber-800 dark:text-amber-200
                                       font-semibold">
                        Thưởng cố định
                      </span>
                    </td>
                    <td className="py-1.5 text-right font-semibold text-ink">
                      {formatCurrency(i.amount || 0)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </SectionCard>
  );
}


// ══════════════════════════════════════════════════════════════════════════════
// QUỸ DƯ KHAI BÁO TAY
// ══════════════════════════════════════════════════════════════════════════════
//
// Quỹ thưởng chia không hết thì phần lẻ tự chuyển sang tháng sau — nhưng cơ chế
// đó chỉ chạy khi CẢ HAI tháng đều được tính trong app.
//
// Lúc mới đưa app vào dùng: tháng trước phòng sản xuất đã chia tay và còn dư,
// tháng đó không hề có trong hệ thống ⇒ không có sổ dư nào để kế thừa ⇒ tiền dư
// biến mất. Panel này là chỗ khai báo tay khoản đó.
//
// Cố ý KHÔNG tự gọi recompute sau khi thêm/xoá: người nhập thường thêm vài dòng
// liên tiếp, recompute mỗi lần vừa chậm vừa dễ ghi đè số đang xem. Nút "Tính lại
// thưởng KPI" ở dưới trang mới là chỗ áp dụng.

function CarryOverSeedPanel({ month, year, periodLabel, onChanged }) {
  const toast = useToast();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [adding, setAdding] = useState(false);
  const [saving, setSaving] = useState(false);

  // Mặc định nguồn = tháng liền trước tháng đang xem (trường hợp phổ biến nhất)
  const prev = month === 1 ? { m: 12, y: year - 1 } : { m: month - 1, y: year };
  const [form, setForm] = useState({
    sourceMonth: prev.m, sourceYear: prev.y, amount: '', note: '',
  });

  const load = useCallback(async () => {
    if (!month || !year) return;
    setLoading(true);
    try {
      const list = await factoryPayrollApi.carryOverSeeds(month, year);
      setRows(Array.isArray(list) ? list : []);
    } catch (e) {
      toast(e?.response?.data?.message || 'Không tải được quỹ dư khai báo tay', 'error');
    } finally { setLoading(false); }
  }, [month, year, toast]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    const p = month === 1 ? { m: 12, y: year - 1 } : { m: month - 1, y: year };
    setForm(f => ({ ...f, sourceMonth: p.m, sourceYear: p.y }));
  }, [month, year]);

  const total = rows.reduce((s, r) => s + (r.amount || 0), 0);

  const submit = async () => {
    const amt = Number(String(form.amount).replace(/[^\d]/g, ''));
    if (!amt || amt <= 0) return toast('Nhập số tiền dư lớn hơn 0', 'error');

    setSaving(true);
    try {
      await factoryPayrollApi.addCarryOverSeed({
        applyMonth: month, applyYear: year,
        sourceMonth: Number(form.sourceMonth), sourceYear: Number(form.sourceYear),
        amount: amt, note: form.note?.trim() || null,
      });
      toast('Đã lưu. Bấm "Tính lại thưởng KPI" để cộng vào quỹ.', 'success');
      setForm(f => ({ ...f, amount: '', note: '' }));
      setAdding(false);
      await load();
      onChanged?.();
    } catch (e) {
      toast(e?.response?.data?.message || 'Không lưu được', 'error');
    } finally { setSaving(false); }
  };

  const remove = async (row) => {
    try {
      await factoryPayrollApi.deleteCarryOverSeed(row.id);
      toast('Đã xoá. Bấm "Tính lại thưởng KPI" để cập nhật quỹ.', 'success');
      await load();
      onChanged?.();
    } catch (e) {
      toast(e?.response?.data?.message || 'Không xoá được', 'error');
    }
  };

  return (
    <SectionCard>
      <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-hairline">
        <div className="flex items-center gap-2 min-w-0">
          <PiggyBank size={16} className="text-gold shrink-0" />
          <h3 className="text-sm font-bold text-ink truncate">
            Quỹ dư khai báo tay {periodLabel ? `— ${periodLabel}` : ''}
          </h3>
        </div>

        <button
          type="button"
          onClick={() => setAdding(v => !v)}
          className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-hairline-2
                     text-xs font-semibold text-ink hover:border-gold/50 hover:text-gold transition"
        >
          {adding ? <><X size={14} /> Đóng</> : <><Plus size={14} /> Thêm khoản dư</>}
        </button>
      </div>

      <div className="p-5 space-y-4">
        <p className="text-xs text-muted leading-relaxed">
          Dùng khi tháng trước đã chia thưởng <b>ngoài app</b> và còn dư — hệ thống
          không có bản ghi nào của tháng đó để kế thừa quỹ dư. Khoản khai báo ở đây
          sẽ được cộng vào quỹ chia của kỳ đang chọn.
          {' '}<b className="text-ink">Chỉ khai báo cho một tháng duy nhất</b>;
          phần chưa tiêu hết sẽ tự chuyển tiếp cho các tháng sau như bình thường.
        </p>

        {adding && (
          <div className="rounded-2xl border border-gold/30 bg-gold-tint p-4 space-y-3">
            <div className="grid gap-3 sm:grid-cols-3">
              <div>
                <label className="block text-[11px] font-semibold text-muted mb-1">
                  Tháng phát sinh
                </label>
                <div className="flex gap-2">
                  <input type="number" min={1} max={12} value={form.sourceMonth}
                    onChange={e => setForm(f => ({ ...f, sourceMonth: e.target.value }))}
                    className="w-16 px-2.5 py-2 rounded-xl border border-hairline-2 text-sm
                               focus:outline-none focus:border-gold" />
                  <input type="number" value={form.sourceYear}
                    onChange={e => setForm(f => ({ ...f, sourceYear: e.target.value }))}
                    className="w-24 px-2.5 py-2 rounded-xl border border-hairline-2 text-sm
                               focus:outline-none focus:border-gold" />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-muted mb-1">
                  Số tiền dư (VNĐ)
                </label>
                <input type="text" inputMode="numeric" value={form.amount}
                  placeholder="VD 513000"
                  onChange={e => setForm(f => ({ ...f, amount: e.target.value }))}
                  className="w-full px-3 py-2 rounded-xl border border-hairline-2 text-sm
                             focus:outline-none focus:border-gold" />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-muted mb-1">
                  Ghi chú
                </label>
                <input type="text" value={form.note}
                  placeholder="Chốt tay theo phiếu thưởng"
                  onChange={e => setForm(f => ({ ...f, note: e.target.value }))}
                  className="w-full px-3 py-2 rounded-xl border border-hairline-2 text-sm
                             focus:outline-none focus:border-gold" />
              </div>
            </div>

            <button onClick={submit} disabled={saving}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gold text-white text-sm
                         font-semibold hover:bg-gold-strong transition disabled:opacity-50">
              {saving ? 'Đang lưu...' : 'Lưu khoản dư'}
            </button>
          </div>
        )}

        {loading ? (
          <LoadingSpinner label="Đang tải..." />
        ) : !rows.length ? (
          <p className="text-xs text-faint py-2">
            Chưa khai báo khoản dư nào cho kỳ này.
          </p>
        ) : (
          <div className="space-y-2">
            {rows.map(r => (
              <div key={r.id}
                className="flex items-center gap-3 px-4 py-3 rounded-xl bg-canvas border border-hairline">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold text-ink">
                    {formatCurrency(r.amount)}
                    <span className="text-xs font-medium text-muted"> · nguồn {r.sourceLabel}</span>
                  </p>
                  <p className="text-[11px] text-muted mt-0.5 truncate">
                    {r.note || 'Không có ghi chú'}
                    {r.createdBy ? ` — ${r.createdBy}` : ''}
                  </p>
                </div>
                <button onClick={() => remove(r)} title="Xoá khoản này"
                  className="shrink-0 p-2 rounded-lg text-faint hover:text-red-500 hover:bg-red-50 dark:bg-red-500/10 transition">
                  <Trash2 size={15} />
                </button>
              </div>
            ))}

            <div className="flex justify-between items-center px-4 pt-2">
              <span className="text-xs font-semibold text-muted">Tổng khai báo tay</span>
              <span className="text-sm font-bold text-gold">{formatCurrency(total)}</span>
            </div>
          </div>
        )}
      </div>
    </SectionCard>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// MODAL "CHI TIẾT NGÀY CÔNG" CỦA 1 NHÂN VIÊN
// ══════════════════════════════════════════════════════════════════════════════
//
// Trước đây trang này có hẳn một BẢNG chi tiết ngày công liệt kê mọi nhân viên —
// chỉ xem được số tổng (công chuẩn / công thực tế / đi trễ / về sớm), không xem
// được từng ngày. Nay bảng đó được bỏ, thay bằng nút mở modal ở từng dòng Phiếu
// lương, dùng CHUNG lịch chấm công với trang "Quản lý lương" của nhân viên.

function EmployeeAttendanceModal({ employee, month, year, periodLabel, onClose }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!employee) return;
    let cancelled = false;

    (async () => {
      setLoading(true);
      setError(null);
      setData(null);
      try {
        // factoryPayrollApi đã bóc sẵn ApiResponse → trả thẳng AttendanceSummaryDto
        const res = await factoryPayrollApi.employeeAttendance(employee.userId, month, year);
        if (!cancelled) setData(res || null);
      } catch (e) {
        if (!cancelled) setError(e?.response?.data?.message || e.message || 'Không tải được dữ liệu');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    // Đổi nhân viên / đóng modal khi request đang bay → bỏ qua kết quả cũ để
    // không ghi đè dữ liệu của người vừa chọn.
    return () => { cancelled = true; };
  }, [employee, month, year]);

  return (
    <Modal
      open={!!employee}
      onClose={onClose}
      size="2xl"
      title={`Chi tiết ngày công — ${employee?.userFullName || ''} · ${periodLabel || ''}`}
    >
      {loading && <LoadingSpinner label="Đang tải chi tiết ngày công..." />}

      {!loading && error && (
        <div className="flex items-start gap-2 bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/28 rounded-xl px-4 py-3 m-1">
          <AlertCircle size={15} className="text-red-600 dark:text-red-300 shrink-0 mt-0.5" />
          <p className="text-xs text-red-800 dark:text-red-300 leading-relaxed">{error}</p>
        </div>
      )}

      {!loading && !error && (
        <AttendanceDayCalendar
          attendance={data}
          month={month}
          year={year}
          showHeader={false}
        />
      )}
    </Modal>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// 2 BẢNG SAU KHI HOÀN TẤT — Phiếu lương & Chi tiết ngày công
// ══════════════════════════════════════════════════════════════════════════════

/**
 * DẢI SỐ LIỆU TỔNG QUAN trên đầu bảng Phiếu lương.
 *
 * Ba trạng thái, quyết định bằng cờ từ server chứ không suy từ số liệu — quỹ
 * thưởng bằng 0 là hợp lệ và khác hẳn với "chưa tính":
 *   · Bộ phận có KPI + ĐÃ tính  → đủ 6 ô: sản lượng, đơn giá, quỹ thưởng,
 *                                 quỹ dư đợt trước, tổng NET, tổng KPI
 *   · Bộ phận có KPI + CHƯA tính → chỉ tổng NET, kèm nhắc bấm "Tính lại KPI"
 *   · Bộ phận không có KPI       → chỉ tổng NET
 */
function PayrollSummary({ data }) {
  const kpiReady = data.hasKpiBonus && data.kpiComputed;

  const fmtTon = (v) =>
    v == null ? '—' : `${Number(v).toLocaleString('vi-VN', { maximumFractionDigits: 3 })} tấn`;

  const Stat = ({ label, value, tone = 'text-ink', hint }) => (
    <div className="min-w-0 sm:min-w-[120px]">
      <p className="text-[10px] font-semibold text-muted uppercase tracking-wider">{label}</p>
      <p className={`text-sm font-bold mt-0.5 ${tone}`}>{value}</p>
      {hint && <p className="text-[10px] text-faint mt-0.5">{hint}</p>}
    </div>
  );

  return (
    <div className="space-y-2.5">
      {/* Điện thoại: lưới 2 cột, ô cột phải canh phải để hai mép thẳng hàng.
          Trước đây dùng flex-wrap nên trên màn hẹp các ô rơi xuống lệch nhau,
          cột phải vẫn canh trái và nhìn như bị lỗi tràn.
          Từ sm trở lên quay về flex-wrap như cũ. */}
      <div className="grid grid-cols-2 gap-x-4 gap-y-3
                      [&>div:nth-child(even)]:text-right
                      sm:flex sm:flex-wrap sm:gap-x-7
                      sm:[&>div:nth-child(even)]:text-left">
        {kpiReady && (
          <>
            <Stat
              label="Tổng sản lượng tháng"
              value={fmtTon(data.kpiTotalOutputTon)}
              hint={data.kpiTotalOutputKg != null
                ? `${Number(data.kpiTotalOutputKg).toLocaleString('vi-VN')} kg` : null}
            />
            <Stat label="Đơn giá thưởng" value={`${formatCurrency(data.kpiRatePerTon)} / tấn`} />
            <Stat label="Tổng tiền thưởng" value={formatCurrency(data.kpiBonusPool)} tone="text-gold" />
            <Stat
              label="Tiền dư đợt trước"
              value={formatCurrency(data.kpiCarryOverIn)}
              hint={data.kpiCarryOverInDetail?.length
                ? data.kpiCarryOverInDetail
                  .map(c => `${c.label}: ${formatCurrency(c.amount)}`).join(' · ')
                : null}
            />
          </>
        )}

        <Stat label="Tổng NET" value={formatCurrency(data.totalNetSalary)} tone="text-emerald-700 dark:text-emerald-300" />

        {kpiReady && (
          <Stat label="Tổng KPI" value={formatCurrency(data.totalKpiBonus)} tone="text-gold" />
        )}
      </div>

      {data.hasKpiBonus && !data.kpiComputed && (
        <p className="text-[11px] text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/28 rounded-lg px-2.5 py-1.5 inline-block">
          Chưa tính thưởng KPI cho kỳ này — bấm "Tính lại KPI" hoặc "Hoàn tất" để tính.
        </p>
      )}
    </div>
  );
}


// Bỏ dấu tiếng Việt để "nga" tìm được "Nguyễn Thị Hồng Nga" và "hong nga" cũng
// khớp. Chuẩn hoá NFD tách dấu thành ký tự tổ hợp rồi xoá; riêng đ/Đ không có
// dạng tổ hợp nên phải thay tay.
const normText = (v) =>
  String(v ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .toLowerCase()
    .trim();

// Số công: bỏ đuôi ,00 cho gọn (27,00 → 27 · 25,28 giữ nguyên)
const fmtDays = (v) =>
  v == null ? '—' : Number(v).toLocaleString('vi-VN', { maximumFractionDigits: 2 });

// Tháng này có bị trừ lương vì thiếu công không — dùng để tô cảnh báo cột
// "Lương thực tế". So bằng số tiền chứ không so ngày công: nhân viên được miễn
// chấm công hoặc bản ghi cũ thiếu standardDays vẫn cho ra kết quả đúng.
const shortfall = (r) =>
  r.standardBaseSalary != null && r.baseSalary != null && r.baseSalary < r.standardBaseSalary;

// LƯƠNG KHOÁN TRỌN THÁNG — bảo vệ xưởng thuê từ đơn vị bên ngoài. Lương không
// chia theo chấm công, không bảo hiểm/thuế/phụ cấp, nên gộp 2 cột lương và bỏ
// nút "Chi tiết lương".
//
// Ưu tiên cờ attendanceExempt từ BE; so thêm payrollRole để bảng vẫn đúng với
// bản ghi cũ chưa có cờ này.
const flatPay = (r) => !!r.attendanceExempt || r.payrollRole === 'FACTORY_SECURITY';


// ══════════════════════════════════════════════════════════════════════════════
// THẺ PHIẾU LƯƠNG — BẢN ĐIỆN THOẠI
// ══════════════════════════════════════════════════════════════════════════════
//
// Bố cục 2 cột: nhãn/giá trị bên trái canh trái, bên phải canh phải — hai mép
// thẳng hàng nên mắt quét dọc được, không bị so le như khi để flex-wrap.
//
//   ┌──────────────────────────────────────┐
//   │ Tên nhân viên                        │
//   │ Chức vụ                              │
//   ├──────────────────┬───────────────────┤
//   │ Lương cơ bản     │      Lương thực tế│
//   ├──────────────────┼───────────────────┤
//   │ Phụ cấp          │        Thưởng KPI │
//   │ Thưởng           │                   │
//   ├──────────────────┴───────────────────┤
//   │ [Chi tiết lương]     [Ngày công]     │
//   └──────────────────────────────────────┘

function PayrollMobileCard({ row: r, isDriver, showKpi, highlight = false, onAttendance, onSalary }) {
  const flat = flatPay(r);

  // Bảo vệ khoán trọn tháng: không breakdown, không chấm công → không nút nào.
  const showSalaryBtn = !flat && !!r.salaryDetail;
  const showAttendanceBtn = !isDriver && !flat;

  const Cell = ({ label, value, sub, tone = '', right = false }) => (
    <div className={right ? 'text-right' : 'text-left'}>
      <p className="text-[10px] font-semibold text-muted uppercase tracking-wider">{label}</p>
      <p className={`text-sm font-bold mt-0.5 ${tone || 'text-ink'}`}>{value}</p>
      {sub && <p className="text-[11px] text-muted mt-0.5">{sub}</p>}
    </div>
  );

  return (
    <div
      id={`payroll-card-${r.userId}`}
      className={`rounded-2xl border px-4 py-4 space-y-3 transition-colors
        ${highlight
          ? 'border-gold bg-gold/10 shadow-sm'
          : 'border-hairline-2 bg-surface'}`}
    >
      {/* Header — gạch dưới để tách hẳn khỏi phần số liệu */}
      <div className="pb-2.5 border-b border-hairline">
        <p className="font-semibold text-ink leading-snug">{r.userFullName}</p>
        <p className="text-xs text-muted">
          {r.roleLabel || '—'}
          {r.salaryStatus === 'NO_SALARY' && (
            <span className="ml-1.5 text-amber-600 dark:text-amber-300 font-semibold">· chưa có hồ sơ lương</span>
          )}
        </p>
      </div>

      {/* (10/2026) Nghỉ thai sản → ẩn mọi số công/phụ cấp/thưởng, chỉ
          hiện Lương cơ bản + nhãn in nghiêng. Khớp với bảng desktop. */}
      {r.maternityLeave ? (
        <>
          <Cell label="Lương cơ bản" value={formatCurrency(r.standardBaseSalary ?? r.baseSalary)} />
          <div className="pt-2 border-t border-hairline">
            <p className="italic text-amber-700 dark:text-amber-300 font-medium text-center">
              Đang nghỉ thai sản theo chế độ
            </p>
          </div>
        </>
      ) : (
        <>
          {/* Lương cơ bản | Lương thực tế */}
          {flat ? (
            <Cell
              label="Lương khoán trọn tháng"
              value={formatCurrency(r.baseSalary)}
              sub="Hợp đồng thuê ngoài"
            />
          ) : (
            <div className="grid grid-cols-2 gap-3">
              <Cell label="Lương cơ bản" value={formatCurrency(r.standardBaseSalary ?? r.baseSalary)} />
              <Cell
                right
                label="Lương thực tế"
                value={formatCurrency(r.baseSalary)}
                tone={shortfall(r) ? 'text-amber-700 dark:text-amber-300' : ''}
                sub={r.standardDays != null
                  ? `${fmtDays(r.actualDays)} / ${fmtDays(r.standardDays)} công`
                  : null}
              />
            </div>
          )}

          {/* PHASE 7: 3 cột phụ cấp (cơm · trách nhiệm · OT). Thưởng/KPI xem trong
              modal "Chi tiết lương". */}
          {(() => {
            const arr = r.salaryDetail?.allowances || [];
            const pick = (needle) => arr
              .filter(a => (a.label || '').toLowerCase().includes(needle))
              .reduce((s, a) => s + (a.amount || 0), 0);
            const meal = pick('cơm') || pick('com');
            const resp = pick('trách nhiệm') || pick('trach nhiem');
            const ot = pick('ot') || pick('tăng ca');
            return (
              <div className="grid grid-cols-3 gap-3">
                <Cell label="Cơm" value={formatCurrency(meal)} />
                <Cell label="Trách nhiệm" value={formatCurrency(resp)} />
                <Cell label="OT" value={formatCurrency(ot)} tone="text-gold" />
              </div>
            );
          })()}
        </>
      )}

      {/* FIX (10/2026): bỏ 2 nút "Chi tiết lương" + "Chi tiết ngày công"
          khỏi thẻ mobile — khớp cột đã gỡ bên desktop. */}
    </div>
  );
}

/**
 * Props mở rộng (10/2026):
 *   - `embedded`: true = không wrap SectionCard / không render header /
 *                 không render ô search / không render footer scroll hint.
 *                 Dùng khi `CompanyPayrollSection` ở `CompanyPayrollPanel`
 *                 gộp 5 bộ phận vào 1 card chung (user yêu cầu bỏ bớt UI
 *                 chrome lặp lại).
 *   - `externalQuery`: khi `embedded`, nhận chuỗi tìm từ ngoài — bên ngoài
 *                 quản lý state, bên trong chỉ highlight/scroll theo.
 */
export function PayrollTables({ data, loading, preview = false,
  embedded = false, externalQuery = '',
  hideHeader = false, suppressScroll = false }) {
  // ── State nội bộ ─────────────────────────────────────────────────────────
  // Modal chi tiết ngày công / breakdown lương vẫn giữ code (dễ bật lại
  // sau), nhưng NÚT TRIGGER đã GỠ khỏi bảng theo yêu cầu 10/2026 →
  // detailOf / salaryOf hiện không có đường để set true. Code của modal
  // được giữ nguyên trong file này cho mục đích tương lai.
  const [detailOf, setDetailOf] = useState(null);
  const [salaryOf, setSalaryOf] = useState(null);

  // ── TÌM NHÂN VIÊN THEO TÊN ────────────────────────────────────────────────
  //   Khi `embedded`, dùng externalQuery từ parent (CompanyPayrollSection) để
  //   mọi bộ phận search chung 1 ô. Khi standalone, dùng state nội bộ.
  const [internalQuery, setQuery] = useState('');
  const query = embedded ? externalQuery : internalQuery;
  const [searchOpen, setSearchOpen] = useState(false);   // ô tìm nổi trên mobile

  // ── MỌI HOOK PHẢI NẰM TRÊN CÁC `return` SỚM ───────────────────────────────
  //   React nhận diện hook theo THỨ TỰ GỌI, không theo tên. Đặt useEffect phía
  //   dưới `if (loading) return ...` thì lần render đang tải chỉ chạy 4 hook,
  //   lần sau chạy 5 → "Rendered more hooks than during the previous render".
  //   Vì vậy phần suy ra dữ liệu bên dưới phải chịu được data = null.
  const rows = data?.rows || [];
  const isDriver = !data?.attendanceBased;

  const q = normText(query);
  const matchIds = q
    ? rows.filter(r => normText(r.userFullName).includes(q)).map(r => r.userId)
    : [];
  const isMatch = (r) => matchIds.includes(r.userId);

  // Chuỗi id thay cho mảng trong deps: mảng tạo mới mỗi lần render nên so sánh
  // tham chiếu luôn khác nhau, effect sẽ chạy vô hạn và cuộn giật liên tục.
  const matchKey = matchIds.join(',');

  // Cuộn tới người khớp ĐẦU TIÊN — chỉ chạy khi standalone. Khi embedded,
  // scroll là trách nhiệm của parent (CompanyPayrollSection) — 5 PayrollTables
  // mỗi cái tự scroll sẽ "cạnh tranh" nhau, cái cuối thắng → scroll sai dept.
  useEffect(() => {
    if (suppressScroll || !matchKey) return;
    const id = matchKey.split(',')[0];
    const el = [
      document.getElementById(`payroll-card-${id}`),
      document.getElementById(`payroll-row-${id}`),
    ].find(e => e && e.offsetParent !== null);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, [matchKey, suppressScroll]);

  if (loading) return <SectionCard><LoadingSpinner label="Đang tải bảng lương..." /></SectionCard>;
  if (!data) return null;

  // FIX (10/2026): Khi `embedded`, bỏ SectionCard + header + ô search + tóm
  // tắt + nút search nổi. Parent (CompanyPayrollSection) đã có 1 header +
  // 1 ô search chung cho cả 5 bộ phận → không lặp lại.
  const Wrapper = embedded ? React.Fragment : SectionCard;
  const wrapperProps = embedded ? {} : {};

  return (
    <>
      {/* ── BẢNG 1: PHIẾU LƯƠNG ─────────────────────────────────────────── */}
      <Wrapper {...wrapperProps}>
        {!embedded && (
          <div className="px-5 py-4 border-b border-hairline">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-3">
              <div className="flex items-center gap-2 min-w-0">
                <Receipt size={16} className="text-gold shrink-0" />
                <h3 className="text-sm font-bold text-ink">
                  Phiếu lương — {data.departmentLabel} · {data.periodLabel}
                  {preview && (
                    <span className="ml-2 text-[10px] font-bold px-1.5 py-0.5 rounded
                      bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-200
                      uppercase tracking-wider align-middle">
                      Xem trước
                    </span>
                  )}
                </h3>
              </div>

              {/* Ô tìm cố định — ẩn trên mobile, nơi đó dùng nút nổi bên dưới */}
              <div className="hidden md:block relative shrink-0">
                <Search size={14}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-faint pointer-events-none" />
                <input
                  type="text"
                  value={query}
                  onChange={e => setQuery(e.target.value)}
                  placeholder="Tìm theo tên nhân viên..."
                  className="w-56 lg:w-64 pl-8 pr-8 py-2 rounded-xl border border-hairline-2 text-xs
                             focus:outline-none focus:border-gold transition-colors"
                />
                {query && (
                  <button onClick={() => setQuery('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded-md
                               text-faint hover:text-ink">
                    <X size={13} />
                  </button>
                )}
              </div>
            </div>

            <PayrollSummary data={data} />

            {query && (
              <p className="text-[11px] text-muted mt-2.5">
                {matchIds.length
                  ? `Tìm thấy ${matchIds.length} nhân viên khớp "${query}"`
                  : `Không có nhân viên nào khớp "${query}"`}
              </p>
            )}
          </div>
        )}

        {/* Bảng đầy đủ — chỉ từ md trở lên. Màn hẹp dùng danh sách thẻ bên dưới.
            FIX (10/2026): dùng `table-fixed` + <colgroup> để các cột của 5
            bộ phận có ĐÚNG width giống nhau. `table-auto` mặc định tự co giãn
            theo nội dung từng bảng — nên bộ phận có số 7-chữ-số làm cột tiền
            rộng hơn bộ phận có số 6-chữ-số, các dòng tiền không thẳng cột. */}
        <div className="hidden md:block overflow-x-auto">
          <Table className="w-full table-fixed">
            <colgroup>
              <col className="w-[22%]" />
              <col className="w-[13%]" />
              <col className="w-[15%]" />
              <col className="w-[12%]" />
              <col className="w-[13%]" />
              <col className="w-[11%]" />
              <col className="w-[14%]" />
            </colgroup>
            {!hideHeader && (
              <Thead>
                <Tr>
                  <Th>Nhân viên</Th>
                  <Th right>Lương cơ bản</Th>
                  <Th right>Lương theo chấm công</Th>
                  <Th right>Phụ cấp cơm</Th>
                  <Th right>Phụ cấp trách nhiệm</Th>
                  <Th right>Phụ cấp OT</Th>
                  <Th right>Thực nhận</Th>
                </Tr>
              </Thead>
            )}
            <tbody>
              {rows.map(r => {
                const allowanceByLabel = (() => {
                  const arr = r.salaryDetail?.allowances || [];
                  const pick = (needle) => arr
                    .filter(a => (a.label || '').toLowerCase().includes(needle))
                    .reduce((s, a) => s + (a.amount || 0), 0);
                  return {
                    meal: pick('cơm') || pick('com') || 0,
                    resp: pick('trách nhiệm') || pick('trach nhiem') || 0,
                    ot: pick('ot') || pick('tăng ca') || 0,
                  };
                })();

                return (
                  <Tr
                    key={r.userId}
                    id={`payroll-row-${r.userId}`}
                    className={
                      // TASK 1 (11/2026): hover highlight = search match highlight
                      //   isMatch  → bg-gold/12 + bold toàn dòng (giữ visual search)
                      //   hover    → cùng visual, dùng hover:! để override hover:bg-canvas/30
                      //              mặc định của <Tr> trong ui/index.jsx
                      //   `hover:[&_*]:font-bold` → tr:hover * { font-weight: 700 }
                      //              phủ qua font-medium của tên và plain text của currency
                      isMatch(r)
                        ? 'bg-gold/12 [&_*]:font-bold'
                        : 'hover:!bg-gold/12 hover:[&_*]:font-bold transition-colors'
                    }
                  >
                    <Td>
                      <div className="font-medium">{r.userFullName}</div>
                      <div className="text-xs text-muted">
                        {r.roleLabel || '—'}
                        {r.salaryStatus === 'NO_SALARY' && (
                          <span className="ml-1.5 text-amber-600 dark:text-amber-300 font-semibold">· chưa có hồ sơ lương</span>
                        )}
                      </div>
                    </Td>

                    {/* (10/2026) NGHỈ THAI SẢN THEO CHẾ ĐỘ ──────────────────
                        Owner yêu cầu: nhân viên đang nghỉ thai sản thì bảng
                        lương KHÔNG hiển thị số công / phụ cấp / thưởng (kể cả
                        khi vẫn có khoản nhập tay) — merge TỪ CỘT "Lương theo
                        chấm công" tới cột "Thực nhận" bằng dòng chữ in nghiêng.
                        Giữ "Lương cơ bản" để người đọc vẫn thấy mức lương hồ
                        sơ hiện hành. BE gắn cờ `maternityLeave` cho đúng người
                        (xem FactoryKpiService.MATERNITY_LEAVE_NAMES). */}
                    {r.maternityLeave ? (
                      <>
                        <Td right>{formatCurrency(r.standardBaseSalary ?? r.baseSalary)}</Td>
                        <Td colSpan={5} className="text-center">
                          <span className="italic text-amber-700 dark:text-amber-300 font-medium">
                            Đang nghỉ thai sản theo chế độ
                          </span>
                        </Td>
                      </>
                    ) : (
                      <>
                        {flatPay(r) ? (
                          <Td right colSpan={2}>
                            <div>{formatCurrency(r.baseSalary)}</div>
                            <div className="text-[11px] text-muted">Khoán trọn tháng</div>
                          </Td>
                        ) : (
                          <>
                            <Td right>{formatCurrency(r.standardBaseSalary ?? r.baseSalary)}</Td>
                            <Td right>
                              <div className={shortfall(r) ? 'text-amber-700 dark:text-amber-300 font-semibold' : ''}>
                                {formatCurrency(r.baseSalary)}
                              </div>
                              <div className="text-[11px] text-muted">
                                {r.standardDays != null
                                  ? `${fmtDays(r.actualDays)} / ${fmtDays(r.standardDays)} công`
                                  : '—'}
                              </div>
                            </Td>
                          </>
                        )}

                        <Td right>{formatCurrency(allowanceByLabel.meal)}</Td>
                        <Td right>{formatCurrency(allowanceByLabel.resp)}</Td>
                        <Td right>{formatCurrency(allowanceByLabel.ot)}</Td>
                        <Td right>
                          <span className="font-bold text-emerald-700 dark:text-emerald-300">
                            {formatCurrency(r.netReceived != null
                              ? r.netReceived
                              : (r.baseSalary || 0) + allowanceByLabel.meal
                              + allowanceByLabel.resp + allowanceByLabel.ot)}
                          </span>
                        </Td>
                      </>
                    )}
                  </Tr>
                );
              })}
              {rows.length === 0 && (
                <Tr><Td className="text-center text-muted py-8">
                  Bộ phận này chưa có nhân viên nào</Td></Tr>
              )}
            </tbody>
          </Table>
        </div>

        {/* ── ĐIỆN THOẠI: mỗi nhân viên một thẻ ───────────────────────────── */}
        <div className="md:hidden p-3 space-y-3">
          {rows.map(r => (
            <PayrollMobileCard
              key={r.userId}
              row={r}
              isDriver={isDriver}
              showKpi={!!data.hasKpiBonus}
              highlight={isMatch(r)}
              onAttendance={() => setDetailOf(r)}
              onSalary={() => setSalaryOf(r)}
            />
          ))}
          {rows.length === 0 && (
            <p className="text-center text-sm text-muted py-10">
              Bộ phận này chưa có nhân viên nào
            </p>
          )}
        </div>
      </Wrapper>

      {/* Bảng "Chi tiết số km theo tháng" đã BỎ — thông tin km/số đơn đã hiện
          đầy đủ trong bảng "Lương tài xế theo km & lượt giao" ở panel bên trên. */}

      {/* ── BẢNG ĐI TRỄ / VỀ SỚM — PHASE 7 ĐÃ GỠ ────────────────────────────
          Dữ liệu đi trễ / về sớm xem ở trang Chuyên cần (nút phía trên).
          Bật `false &&` để giữ cấu trúc JSX, dễ revert nếu cần. */}
      {false && !isDriver && rows.some(r => (r.lateCount > 0 || r.earlyCount > 0)) && (
        <SectionCard>
          <div className="px-5 py-4 border-b border-hairline">
            <div className="flex items-center gap-2">
              <Clock size={16} className="text-amber-500 shrink-0" />
              <h3 className="text-sm font-bold text-ink">
                Đi trễ / Về sớm · {data.periodLabel}
              </h3>
            </div>
            <p className="mt-1 text-xs text-muted">
              Xưởng sản xuất & Kế toán: đi trễ/về sớm được <strong>trừ vào ngày phép trước</strong>
              (du di 5 phút mỗi chiều), hết phép mới trừ lương.
              Kho & các bộ phận khác: trừ thẳng vào ngày công.
            </p>
          </div>

          {/* DESKTOP */}
          <div className="hidden md:block overflow-x-auto">
            <Table>
              <Thead>
                <Tr>
                  <Th>Nhân viên</Th>
                  <Th right>Số lần đi trễ</Th>
                  <Th right>Tổng phút đi trễ</Th>
                  <Th right>Số lần về sớm</Th>
                  <Th right>Tổng phút về sớm</Th>
                  <Th right>Tổng phút vi phạm</Th>
                </Tr>
              </Thead>
              <tbody>
                {rows.filter(r => (r.lateCount > 0 || r.earlyCount > 0)).map(r => {
                  const totalViolation = (r.lateMinutes || 0) + (r.earlyMinutes || 0);
                  return (
                    <Tr key={r.userId}>
                      <Td>
                        <div className="font-medium">{r.userFullName}</div>
                        <div className="text-xs text-muted">{r.roleLabel || '—'}</div>
                      </Td>
                      <Td right>
                        <span className={r.lateCount > 0 ? 'text-amber-600 dark:text-amber-300 font-semibold' : ''}>
                          {r.lateCount || 0}
                        </span>
                      </Td>
                      <Td right>
                        <span className={r.lateMinutes > 0 ? 'text-amber-600 dark:text-amber-300 font-semibold' : ''}>
                          {(r.lateMinutes || 0).toLocaleString('vi-VN')} phút
                        </span>
                      </Td>
                      <Td right>
                        <span className={r.earlyCount > 0 ? 'text-blue-600 dark:text-blue-300 font-semibold' : ''}>
                          {r.earlyCount || 0}
                        </span>
                      </Td>
                      <Td right>
                        <span className={r.earlyMinutes > 0 ? 'text-blue-600 dark:text-blue-300 font-semibold' : ''}>
                          {(r.earlyMinutes || 0).toLocaleString('vi-VN')} phút
                        </span>
                      </Td>
                      <Td right>
                        <span className={totalViolation > 0 ? 'text-red-600 dark:text-red-300 font-bold' : ''}>
                          {totalViolation.toLocaleString('vi-VN')} phút
                        </span>
                      </Td>
                    </Tr>
                  );
                })}
              </tbody>
            </Table>
          </div>

          {/* MOBILE */}
          <div className="md:hidden p-3 space-y-2">
            {rows.filter(r => (r.lateCount > 0 || r.earlyCount > 0)).map(r => {
              const totalViolation = (r.lateMinutes || 0) + (r.earlyMinutes || 0);
              return (
                <div key={r.userId} className="rounded-xl border border-hairline p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-sm text-ink">{r.userFullName}</p>
                      <p className="text-xs text-muted">{r.roleLabel || '—'}</p>
                    </div>
                    <span className={`text-sm font-bold ${totalViolation > 0 ? 'text-red-600 dark:text-red-300' : 'text-muted'}`}>
                      {totalViolation.toLocaleString('vi-VN')} phút
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-1 text-xs">
                    {r.lateCount > 0 && (
                      <span className="text-amber-600 dark:text-amber-300">
                        Đi trễ: {r.lateCount} lần / {(r.lateMinutes || 0).toLocaleString('vi-VN')}p
                      </span>
                    )}
                    {r.earlyCount > 0 && (
                      <span className="text-blue-600 dark:text-blue-300">
                        Về sớm: {r.earlyCount} lần / {(r.earlyMinutes || 0).toLocaleString('vi-VN')}p
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </SectionCard>
      )}

      {/* Modal chi tiết ngày công của nhân viên vừa bấm */}
      <EmployeeAttendanceModal
        employee={detailOf}
        month={data.month}
        year={data.year}
        periodLabel={data.periodLabel}
        onClose={() => setDetailOf(null)}
      />

      {/* Modal breakdown lương — dùng lại đúng component của trang Nhân sự để
          hai màn hình không bao giờ hiện hai cách tính khác nhau. */}
      <SalaryDetailModal row={salaryOf} onClose={() => setSalaryOf(null)} />

      {/* ── NÚT TÌM NỔI — CHỈ TRÊN ĐIỆN THOẠI ─────────────────────────────────
          Danh sách thẻ dài hàng chục màn hình, ô tìm đặt ở đầu bảng sẽ trôi mất
          ngay khi cuộn xuống. Nút nổi bám màn hình nên tìm được ở bất kỳ đâu.
          Ẩn khi đang mở modal để không đè lên nội dung modal.
          FIX (10/2026): ẩn luôn khi `embedded` — parent CompanyPayrollSection
          đã có 1 ô search chung cho cả 5 bộ phận. */}
      {!embedded && !detailOf && !salaryOf && (
        <div className="md:hidden fixed bottom-5 right-4 z-40 flex items-center gap-2">
          {searchOpen && (
            <div className="relative">
              <input
                autoFocus
                type="text"
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Tên nhân viên..."
                className="w-52 pl-3 pr-8 py-3 rounded-2xl border border-hairline-2 bg-surface
                           text-sm shadow-lg focus:outline-none focus:border-gold"
              />
              {query && (
                <button onClick={() => setQuery('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded-md text-faint">
                  <X size={15} />
                </button>
              )}
            </div>
          )}

          <button
            type="button"
            onClick={() => {
              // Đóng thì xoá luôn từ khoá — để lại highlight trong khi ô tìm đã
              // biến mất sẽ khiến người dùng không hiểu vì sao dòng bị tô vàng.
              if (searchOpen) setQuery('');
              setSearchOpen(v => !v);
            }}
            aria-label={searchOpen ? 'Đóng tìm kiếm' : 'Tìm nhân viên'}
            className="shrink-0 rounded-full bg-gradient-to-br from-gold to-gold-deep
                       text-white shadow-lg shadow-gold/30 flex items-center justify-center
                       active:scale-95 transition-transform"
            style={{ width: '3.25rem', height: '3.25rem' }}
          >
            {searchOpen ? <X size={20} /> : <Search size={20} />}
          </button>
        </div>
      )}
    </>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// MODAL "CHI TIẾT LƯƠNG"
// ══════════════════════════════════════════════════════════════════════════════

function SalaryDetailModal({ row, onClose }) {
  if (!row) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />

      <div className="relative bg-surface rounded-2xl shadow-2xl w-full max-w-lg
                      max-h-[88vh] flex flex-col overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-hairline shrink-0">
          <h3 className="font-bold text-ink text-sm">
            Chi tiết lương — {row.userFullName}
          </h3>
          <button onClick={onClose} className="p-1.5 rounded-lg text-muted hover:bg-canvas">
            <X size={18} />
          </button>
        </div>

        <div className="p-5 overflow-y-auto">
          {row.salaryDetail
            ? <SalaryBreakdownCards row={row.salaryDetail} />
            : <p className="text-sm text-muted text-center py-8">
              Nhân viên chưa có hồ sơ lương được duyệt.
            </p>}
        </div>

        <div className="px-5 py-4 border-t border-hairline shrink-0">
          <button onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-canvas text-sm font-semibold
                       text-ink hover:bg-surface-2 transition">
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// TRANG CHÍNH
// ══════════════════════════════════════════════════════════════════════════════

// ══════════════════════════════════════════════════════════════════════════════
// LƯƠNG TÀI XẾ — OWNER nhập giá xăng + đơn giá thưởng (xe máy & xe tải),
// xem bảng lương tách theo loại xe. Bấm 1 dòng → modal 2 tab (đơn hàng + lương).
// ══════════════════════════════════════════════════════════════════════════════

// Format số kiểu Việt Nam: 1234 → "1.234"
const fmtVN = (v) => {
  if (v == null || v === '') return '';
  const n = String(v).replace(/[^\d]/g, '');
  if (!n) return '';
  return n.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
};
const parseVN = (v) => {
  const n = Number(String(v ?? '').replace(/[^\d]/g, ''));
  return Number.isFinite(n) ? n : 0;
};

/** Ô nhập số kiểu VN: gõ ký tự → format ngay, gợi ý "vnđ" phía sau.
 *  (10/2026) Focus: bỏ ring vàng dày (ring-2), chỉ đổi màu viền nhẹ cho tinh tế;
 *  đồng thời select hết text để user gõ đè số mới ngay. */
function VNMoneyInput({ value, onChange, placeholder, disabled }) {
  return (
    <div className={`relative ${disabled ? 'opacity-60' : ''}`}>
      <input
        inputMode="numeric" disabled={disabled}
        value={fmtVN(value)}
        onChange={e => onChange(String(e.target.value).replace(/[^\d]/g, ''))}
        onFocus={e => e.target.select()}
        placeholder={placeholder}
        className="w-full pl-4 pr-14 py-2.5 rounded-xl border border-hairline-2 text-sm text-right
          focus:outline-none focus:border-gold bg-surface disabled:cursor-not-allowed
          disabled:bg-canvas transition-colors"
      />
      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-semibold text-muted pointer-events-none">
        vnđ
      </span>
    </div>
  );
}

function DriverPayrollPanel({ month, year, onSaved,
  onComputePreview, computingPreview, finalizedPeriod,
  bonusCalcStatus, bonusFinalized, publishingBonus, onPublish, onUnpublish }) {
  const toast = useToast();
  const [cfg, setCfg] = useState(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [gasPrice, setGasPrice] = useState('');
  const [bonusMoto, setBonusMoto] = useState('');
  const [bonusTruck, setBonusTruck] = useState('');
  const [modalDriver, setModalDriver] = useState(null); // { userId, name, vehicleType }
  const [configModalOpen, setConfigModalOpen] = useState(false);
  const [calculating, setCalculating] = useState(false);
  // (10/2026) Thưởng cố định tài xế xe tải — mỗi NV 1 số, state key = userId.
  const [truckFixedBonuses, setTruckFixedBonuses] = useState({});

  const finalized = cfg?.finalized === true;

  // (10/2026) 3-state cho Thưởng Tài xế (giống KT/KD).
  //   NONE       = chưa tính           → "Tính tiền thưởng"
  //   CALCULATED = đã tính, chưa Public → "Tính lại" + "Hoàn tất tính thưởng"
  //   PUBLISHED  = đã Public            → "Mở lại"
  const bonusState = bonusCalcStatus || (bonusFinalized ? 'PUBLISHED' : 'NONE');
  const isNone      = bonusState === 'NONE';
  const isCalc      = bonusState === 'CALCULATED';
  const isPublished = bonusState === 'PUBLISHED';

  // 3 giá trị đã lưu + default placeholder nếu chưa có (yêu cầu 10/2026)
  const displayGas       = cfg?.gasPrice ?? null;
  const displayBonusMoto = cfg?.bonusUnitPrice ?? null;
  const displayBonusTruck = cfg?.truckBonusUnitPrice ?? null;

  // (10/2026) Mặc định thưởng cố định tài xế xe tải nếu tháng này chưa nhập.
  // Nếu user không đổi gì → BE lưu 900.000; nếu đổi → lưu số user nhập.
  const TRUCK_DRIVER_DEFAULT_BONUS = 900_000;

  const openConfigModal = () => {
    // Pre-fill với giá trị hiện tại; nếu null, để input show placeholder (488/5000/8000)
    setGasPrice(displayGas != null ? String(displayGas) : '');
    setBonusMoto(displayBonusMoto != null ? String(displayBonusMoto) : '');
    setBonusTruck(displayBonusTruck != null ? String(displayBonusTruck) : '');
    // (10/2026) Pre-fill thưởng cố định tài xế xe tải:
    //   • Có số đã lưu tháng này → dùng số đó.
    //   • Chưa lưu (0 hoặc null) → điền sẵn 900.000 làm default.
    const prefill = {};
    (cfg?.truckDriverRows || []).forEach(r => {
      prefill[r.userId] = r.fixedTruckBonus != null && r.fixedTruckBonus > 0
        ? String(r.fixedTruckBonus)
        : String(TRUCK_DRIVER_DEFAULT_BONUS);
    });
    setTruckFixedBonuses(prefill);
    setConfigModalOpen(true);
  };

  const handleCalculate = async () => {
    // Default: 488 / 5000 / 8000 nếu user để trống
    const gas   = parseVN(gasPrice)   ?? 488;
    const bMoto = parseVN(bonusMoto)  ?? 5000;
    const bTruck = parseVN(bonusTruck) ?? 8000;
    if (gas < 0 || bMoto < 0 || bTruck < 0) {
      return toast('Giá trị không hợp lệ', 'error');
    }
    // (10/2026) Build map thưởng cố định tài xế xe tải. Entry rỗng → bỏ qua
    // (giữ nguyên số đã lưu); entry = 0 → set về 0 (hợp lệ, chủ ý).
    const truckFixedPayload = {};
    Object.entries(truckFixedBonuses).forEach(([uid, raw]) => {
      if (raw === '' || raw == null) return;
      const n = parseVN(raw);
      if (n != null && n >= 0) truckFixedPayload[uid] = n;
    });

    setCalculating(true);
    try {
      await factoryPayrollApi.calculateDriverBonus(month, year, {
        gasPrice: gas,
        bonusUnitPrice: bMoto,
        truckBonusUnitPrice: bTruck,
        truckDriverFixedBonuses: truckFixedPayload,
      });
      toast('Đã tính thưởng tài xế. Bấm "Hoàn tất tính thưởng" để Public.', 'success');
      setConfigModalOpen(false);
      await load();
      onSaved && onSaved();
    } catch (e) {
      toast(e?.response?.data?.message || 'Lỗi tính thưởng tài xế', 'error');
    } finally { setCalculating(false); }
  };
  // Đủ giá xăng + 2 đơn giá thưởng mới cho tính lương xem trước — tránh
  // hiển thị bảng với các cột đều 0đ vì thiếu cấu hình.
  const canPreview = cfg?.gasPrice != null
    && cfg?.bonusUnitPrice != null
    && cfg?.truckBonusUnitPrice != null;

  const load = useCallback(async () => {
    if (!month || !year) return;
    setLoading(true);
    try {
      const data = await factoryPayrollApi.driverConfig(month, year);
      setCfg(data);
      setGasPrice(data?.gasPrice != null ? String(data.gasPrice) : '');
      setBonusMoto(data?.bonusUnitPrice != null ? String(data.bonusUnitPrice) : '');
      setBonusTruck(data?.truckBonusUnitPrice != null ? String(data.truckBonusUnitPrice) : '');
    } catch (e) {
      toast(e?.response?.data?.message || 'Không tải được lương tài xế', 'error');
    } finally { setLoading(false); }
  }, [month, year]); // eslint-disable-line

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    setSaving(true);
    try {
      const data = await factoryPayrollApi.saveDriverConfig(
        month, year, parseVN(gasPrice), parseVN(bonusMoto), parseVN(bonusTruck));
      setCfg(data);
      toast('Đã lưu giá xăng và đơn giá thưởng. Bấm "Hoàn tất" để chốt lương.', 'success');
      onSaved && onSaved();
    } catch (e) {
      toast(e?.response?.data?.message || 'Lỗi khi lưu', 'error');
    } finally { setSaving(false); }
  };

  // FIX (11/2026): Ẩn tài xế KHÔNG có lượt giao đơn nào trong tháng đang chọn
  // (cả xe máy + xe tải = 0 lượt). Những người tạm nghỉ hoặc chưa chạy chuyến
  // nào trong tháng không cần hiện ở bảng "Lương tài xế theo km & lượt giao".
  const rows = (cfg?.rows || []).filter(r =>
    (r.motorbike?.totalTrips || 0) > 0 || (r.truck?.totalTrips || 0) > 0);

  return (
    <SectionCard>
      <div className="px-5 py-5 space-y-5">
        <div className="flex items-start gap-3">
          <span className="w-10 h-10 rounded-xl bg-canvas flex items-center justify-center shrink-0">
            <Truck size={17} className="text-gold" />
          </span>
          <div>
            <p className="text-sm font-bold text-ink">Lương tài xế theo km &amp; lượt giao</p>
            <p className="text-xs text-muted mt-1 leading-relaxed max-w-2xl">
              Lương xe máy = <strong>tổng km × giá xăng</strong> +{' '}
              <strong>lượt xe máy × đơn giá thưởng xe máy</strong>.
              Xe tải chỉ tính <strong>lượt xe tải × đơn giá thưởng xe tải</strong> (lương cứng
              xe tải quản lý riêng ở phần Nhân sự).
              {finalized && (
                <span className="block mt-1 text-emerald-600 dark:text-emerald-300 font-semibold">
                  Đã Hoàn tất — bấm "Mở lại" ở trên để chỉnh sửa.
                </span>
              )}
            </p>
          </div>
        </div>

        {/* (10/2026) 3-state card thay cho 3-input + 2-button cũ.
          *   NONE       → "Tính tiền thưởng" (mở modal nhập 3 thông số)
          *   CALCULATED → hiển thị 3 giá trị readonly + "Tính lại" + "Hoàn tất"
          *   PUBLISHED  → hiển thị 3 giá trị readonly + "Mở lại"
          */}
        <div className="rounded-xl bg-canvas border border-hairline px-4 py-3">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-muted uppercase tracking-wider mb-2">
                {isPublished ? 'Thưởng tài xế — ĐÃ HOÀN TẤT'
                 : isCalc    ? 'Thưởng tài xế — ĐÃ TÍNH, CHƯA Public'
                 :             'Thưởng tài xế — CHƯA TÍNH'}
              </p>
              {(isCalc || isPublished) && (
                <div className="grid grid-cols-3 gap-3 text-sm">
                  <div>
                    <p className="text-[10px] text-muted">Giá xăng (/km)</p>
                    <p className="font-bold text-ink mt-0.5">
                      {displayGas != null ? Number(displayGas).toLocaleString('vi-VN') : '—'}đ
                    </p>
                  </div>
                  <div>
                    <p className="text-[10px] text-muted">Thưởng xe máy (/lượt)</p>
                    <p className="font-bold text-ink mt-0.5">
                      {displayBonusMoto != null ? Number(displayBonusMoto).toLocaleString('vi-VN') : '—'}đ
                    </p>
                  </div>
                  <div>
                    <p className="text-[10px] text-muted">Thưởng xe tải (/lượt)</p>
                    <p className="font-bold text-ink mt-0.5">
                      {displayBonusTruck != null ? Number(displayBonusTruck).toLocaleString('vi-VN') : '—'}đ
                    </p>
                  </div>
                </div>
              )}
            </div>
            <div className="flex items-center gap-2 flex-wrap shrink-0">
              {isNone && (
                <PrimaryButton onClick={openConfigModal} disabled={loading || calculating}>
                  <Calculator size={14} /> Tính tiền thưởng
                </PrimaryButton>
              )}
              {isCalc && (
                <>
                  <SecondaryButton onClick={openConfigModal} disabled={calculating || publishingBonus}>
                    <RefreshCw size={14} /> Tính lại
                  </SecondaryButton>
                  <PrimaryButton
                    onClick={() => onPublish && onPublish()}
                    disabled={publishingBonus || !onPublish}>
                    <Gift size={14} />
                    {publishingBonus ? 'Đang hoàn tất...' : 'Hoàn tất tính thưởng'}
                  </PrimaryButton>
                </>
              )}
              {isPublished && (
                <SecondaryButton
                  onClick={() => onUnpublish && onUnpublish()}
                  disabled={publishingBonus || !onUnpublish}
                  title="Nhân viên tài xế sẽ không còn thấy phiếu thưởng. Data đã tính vẫn giữ.">
                  <Unlock size={13} />
                  {publishingBonus ? 'Đang mở lại...' : 'Mở lại'}
                </SecondaryButton>
              )}
            </div>
          </div>
        </div>

        {/* Modal nhập 3 thông số — mở khi bấm Tính thưởng hoặc Tính lại.
            Placeholder: 488 / 5000 / 8000 (giá trị default nếu user để trống).
            Lưu ý: Modal component cần prop `open` (xem /components/ui/Modal.jsx)
            — nếu chỉ wrap trong {configModalOpen && <Modal>} mà không truyền
            open={true} thì Modal.jsx trả null → modal không bao giờ hiện. */}
        <Modal
          open={configModalOpen}
          onClose={() => !calculating && setConfigModalOpen(false)}
          size="lg"
          title={isNone ? 'Tính tiền thưởng tài xế' : 'Tính lại thưởng tài xế'}>
          <div className="p-5 space-y-5">
              <div>
                <p className="text-xs text-muted">
                  Nhập giá xăng + 2 đơn giá thưởng. Để trống sẽ dùng giá mặc định.
                </p>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-muted mb-1">
                    Giá xăng <span className="font-normal">(đồng/km xe máy)</span>
                  </label>
                  <VNMoneyInput value={gasPrice} onChange={setGasPrice}
                    placeholder="488 (mặc định)" disabled={calculating} />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-muted mb-1">
                    Đơn giá thưởng xe máy <span className="font-normal">(đồng/lượt)</span>
                  </label>
                  <VNMoneyInput value={bonusMoto} onChange={setBonusMoto}
                    placeholder="5.000 (mặc định)" disabled={calculating} />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-muted mb-1">
                    Đơn giá thưởng xe tải <span className="font-normal">(đồng/lượt)</span>
                  </label>
                  <VNMoneyInput value={bonusTruck} onChange={setBonusTruck}
                    placeholder="8.000 (mặc định)" disabled={calculating} />
                </div>
              </div>

              {/* (10/2026) Thưởng CỐ ĐỊNH cho tài xế XE TẢI — mỗi NV 1 ô input.
                  LUÔN hiện section để OWNER thấy phần này tồn tại; nếu danh
                  sách trống → hướng dẫn vào Nhân sự set chức vụ. */}
              <div className="rounded-xl border border-hairline-2 bg-canvas/40 p-3 space-y-2">
                <div>
                  <p className="text-xs font-bold text-ink uppercase tracking-wider">
                    Thưởng cố định — Tài xế xe tải{' '}
                    ({(cfg?.truckDriverRows || []).length})
                  </p>
                  <p className="text-[11px] text-muted mt-0.5">
                    Nhập số tiền thưởng tháng cho từng tài xế xe tải. Không tính theo lượt /
                    km. Để trống = giữ số đã lưu trước đó; nhập 0 = không thưởng tháng này.
                  </p>
                </div>
                {(cfg?.truckDriverRows || []).length === 0 ? (
                  <div className="flex items-start gap-2 bg-amber-50 dark:bg-amber-500/10
                                  border border-amber-200 dark:border-amber-500/28
                                  rounded-lg px-3 py-2.5">
                    <AlertCircle size={14} className="text-amber-600 dark:text-amber-300 shrink-0 mt-0.5" />
                    <p className="text-[11px] text-amber-800 dark:text-amber-300 leading-snug">
                      Chưa có NV nào có chức vụ <b>"Tài xế xe tải"</b>. Vào trang
                      <b> Nhân sự → Thông tin NV</b>, mục Chức vụ chọn "Tài xế xe tải"
                      rồi quay lại tính thưởng.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                    {cfg.truckDriverRows.map(r => (
                      <div key={r.userId} className="flex items-center gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-ink truncate">{r.driverName}</p>
                          <p className="text-[10px] text-muted">Tài xế xe tải</p>
                        </div>
                        <div className="w-44 shrink-0">
                          <VNMoneyInput
                            value={truckFixedBonuses[r.userId] ?? ''}
                            onChange={(v) => setTruckFixedBonuses(prev => ({ ...prev, [r.userId]: v }))}
                            placeholder="VD 3.000.000"
                            disabled={calculating} />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <SecondaryButton onClick={() => setConfigModalOpen(false)} disabled={calculating}>
                  Huỷ
                </SecondaryButton>
                <PrimaryButton onClick={handleCalculate} disabled={calculating}>
                  <Calculator size={14} />
                  {calculating ? 'Đang tính...' : (isNone ? 'Tính thưởng' : 'Tính lại')}
                </PrimaryButton>
              </div>
          </div>
        </Modal>

        {loading ? (
          <LoadingSpinner />
        ) : rows.length === 0 ? (
          <EmptyState title="Chưa có tài xế" description="Không có tài xế nào có tài khoản để tính lương." />
        ) : (
          <>
            {/* ── DESKTOP: bảng, mỗi tài xế 1 dòng xe máy (chính) + 1 dòng xe tải ── */}
            <div className="hidden md:block overflow-x-auto rounded-xl border border-hairline">
              <table className="w-full text-xs">
                <thead className="bg-canvas">
                  <tr className="text-left text-muted">
                    <th className="px-3 py-2 font-semibold">Tài xế</th>
                    <th className="px-3 py-2 font-semibold text-right">Tổng km</th>
                    <th className="px-3 py-2 font-semibold text-right">Số lượt</th>
                    <th className="px-3 py-2 font-semibold text-right">Tiền xăng</th>
                    <th className="px-3 py-2 font-semibold text-right">Thưởng</th>
                    <th className="px-3 py-2 font-semibold text-right">Tổng thưởng</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map(r => <DriverSalaryRows key={r.userId} row={r} onOpen={setModalDriver} />)}
                </tbody>
              </table>
              <div className="flex justify-end p-3 text-sm bg-canvas border-t border-hairline">
                <span className="text-muted mr-2">Tổng chi lương tài xế:</span>
                <span className="font-bold text-gold">{formatCurrency(cfg?.grandTotalSalary || 0)}</span>
              </div>
            </div>

            {/* ── MOBILE: mỗi tài xế 1 card, có card con nếu chạy cả 2 loại ── */}
            <div className="md:hidden space-y-3">
              {rows.map(r => <DriverSalaryCard key={r.userId} row={r} onOpen={setModalDriver} />)}
              <div className="rounded-xl bg-canvas p-3 flex items-center justify-between text-sm">
                <span className="text-muted font-semibold">Tổng chi thưởng tài xế</span>
                <span className="font-bold text-gold">{formatCurrency(cfg?.grandTotalSalary || 0)}</span>
              </div>
            </div>

            {(cfg?.gasPrice == null || cfg?.bonusUnitPrice == null || cfg?.truckBonusUnitPrice == null) && (
              <p className="mt-2 text-xs text-amber-600 dark:text-amber-300 flex items-center gap-1">
                <AlertCircle size={12} /> Cần nhập & lưu đủ 3 giá trên trước khi Hoàn tất.
              </p>
            )}
          </>
        )}

        {/* ── (10/2026) BẢNG 2: Tài xế XE TẢI — thưởng cố định ───────────── */}
        {(cfg?.truckDriverRows || []).length > 0 && (
          <div className="mt-6 space-y-3">
            <div className="flex items-start gap-3">
              <span className="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-500/10 flex items-center justify-center shrink-0">
                <Truck size={14} className="text-amber-600 dark:text-amber-300" />
              </span>
              <div>
                <p className="text-sm font-bold text-ink">Tài xế xe tải — thưởng cố định tháng</p>
                <p className="text-xs text-muted mt-1 leading-relaxed max-w-2xl">
                  Không tính theo lượt / km. Số tiền do OWNER nhập trong modal "Tính thưởng";
                  mỗi tài xế có 1 số riêng, không chịu ảnh hưởng của giá xăng hay đơn giá lượt.
                </p>
              </div>
            </div>
            {/* DESKTOP — (10/2026) Bỏ 5 cột tính theo lượt (Số km → Số lượt xe
                tải). Cột cuối đổi label "Thưởng xe tải (cố định)" → "Thưởng
                trách nhiệm" cho đúng ngữ nghĩa. Table giờ chỉ còn 2 cột. */}
            <div className="hidden md:block overflow-x-auto rounded-xl border border-hairline">
              <table className="w-full text-xs">
                <thead className="bg-canvas">
                  <tr className="text-left text-muted">
                    <th className="px-3 py-2 font-semibold">Tài xế xe tải</th>
                    <th className="px-3 py-2 font-semibold text-right">Thưởng trách nhiệm</th>
                  </tr>
                </thead>
                <tbody>
                  {cfg.truckDriverRows.map(r => (
                    <tr key={r.userId} className="border-t border-hairline hover:bg-canvas/50">
                      <td className="px-3 py-2 font-semibold text-ink">{r.driverName}</td>
                      <td className="px-3 py-2 text-right font-bold text-gold">
                        {r.fixedTruckBonus != null && r.fixedTruckBonus > 0
                          ? formatCurrency(r.fixedTruckBonus)
                          : <span className="text-faint">Chưa nhập</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="flex justify-end p-3 text-sm bg-canvas border-t border-hairline">
                <span className="text-muted mr-2">Tổng thưởng trách nhiệm:</span>
                <span className="font-bold text-gold">
                  {formatCurrency(
                    cfg.truckDriverRows.reduce((s, r) => s + (r.fixedTruckBonus || 0), 0),
                  )}
                </span>
              </div>
            </div>
            {/* MOBILE */}
            <div className="md:hidden space-y-2">
              {cfg.truckDriverRows.map(r => (
                <div key={r.userId} className="rounded-xl border border-hairline p-3 flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-sm text-ink">{r.driverName}</p>
                    <p className="text-xs text-muted">Tài xế xe tải · thưởng trách nhiệm</p>
                  </div>
                  <span className="text-sm font-bold text-gold">
                    {r.fixedTruckBonus != null && r.fixedTruckBonus > 0
                      ? formatCurrency(r.fixedTruckBonus)
                      : <span className="text-faint italic">Chưa nhập</span>}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── Nhân viên ngoài bộ phận Tài xế có hỗ trợ giao hàng ── */}
        {(cfg?.nonDriverRows || []).length > 0 && (
          <div className="mt-6 space-y-3">
            <div className="flex items-start gap-3">
              <span className="w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-950 flex items-center justify-center shrink-0">
                <Truck size={14} className="text-blue-500" />
              </span>
              <div>
                <p className="text-sm font-bold text-ink">Phụ cấp xăng xe & giao hàng cho nhân viên hỗ trợ</p>
                <p className="text-xs text-muted mt-1 leading-relaxed max-w-2xl">
                  Nhân viên thuộc bộ phận khác nhưng có điểm danh ODO / đơn hàng giao trong tháng.
                  Phụ cấp xăng xe (km × đơn giá) và phụ cấp giao hàng (lượt × thưởng) được tính riêng vào lương của bộ phận gốc.
                </p>
              </div>
            </div>
            {/* DESKTOP */}
            <div className="hidden md:block overflow-x-auto rounded-xl border border-hairline">
              <table className="w-full text-xs">
                <thead className="bg-canvas">
                  <tr className="text-left text-muted">
                    <th className="px-3 py-2 font-semibold">Nhân viên</th>
                    <th className="px-3 py-2 font-semibold">Bộ phận / Chức vụ</th>
                    <th className="px-3 py-2 font-semibold text-right">Tổng km</th>
                    <th className="px-3 py-2 font-semibold text-right">Tiền xăng xe</th>
                    <th className="px-3 py-2 font-semibold text-right">Lượt xe máy</th>
                    <th className="px-3 py-2 font-semibold text-right">Lượt xe tải</th>
                    <th className="px-3 py-2 font-semibold text-right">Thưởng giao hàng (/đơn)</th>
                    <th className="px-3 py-2 font-semibold text-right">Tổng cộng</th>
                  </tr>
                </thead>
                <tbody>
                  {cfg.nonDriverRows.map(r => {
                    const fuelPay = r.motorbike?.fuelPay || 0;
                    const deliveryPay = (r.motorbike?.bonusPay || 0) + (r.truck?.bonusPay || 0);
                    return (
                      <tr key={r.userId} className="border-t border-hairline hover:bg-canvas/50">
                        <td className="px-3 py-2 font-semibold text-ink">{r.driverName}</td>
                        <td className="px-3 py-2 text-muted">{[r.department, r.position].filter(Boolean).join(' / ')}</td>
                        <td className="px-3 py-2 text-right">{r.motorbike?.totalKm?.toLocaleString('vi-VN', { maximumFractionDigits: 1 }) || '0'} km</td>
                        <td className="px-3 py-2 text-right text-emerald-600 dark:text-emerald-400 font-semibold">{formatCurrency(fuelPay)}</td>
                        <td className="px-3 py-2 text-right">{r.motorbike?.totalTrips || 0} lượt</td>
                        <td className="px-3 py-2 text-right">{r.truck?.totalTrips || 0} lượt</td>
                        <td className="px-3 py-2 text-right text-amber-600 dark:text-amber-400 font-semibold">{formatCurrency(deliveryPay)}</td>
                        <td className="px-3 py-2 text-right font-bold text-blue-600 dark:text-blue-400">
                          {formatCurrency(r.grandTotalSalary || 0)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {/* (10/2026) Dòng tổng cho nhóm NV hỗ trợ */}
              <div className="flex justify-end p-3 text-sm bg-canvas border-t border-hairline">
                <span className="text-muted mr-2">Tổng chi phụ cấp NV hỗ trợ:</span>
                <span className="font-bold text-blue-600 dark:text-blue-400">
                  {formatCurrency(
                    (cfg.nonDriverRows || []).reduce((s, r) => s + (r.grandTotalSalary || 0), 0),
                  )}
                </span>
              </div>
            </div>
            {/* MOBILE */}
            <div className="md:hidden space-y-2">
              {cfg.nonDriverRows.map(r => {
                const fuelPay = r.motorbike?.fuelPay || 0;
                const deliveryPay = (r.motorbike?.bonusPay || 0) + (r.truck?.bonusPay || 0);
                return (
                  <div key={r.userId} className="rounded-xl border border-hairline p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold text-sm text-ink">{r.driverName}</p>
                        <p className="text-xs text-muted">{[r.department, r.position].filter(Boolean).join(' / ')}</p>
                      </div>
                      <span className="text-sm font-bold text-blue-600 dark:text-blue-400">
                        {formatCurrency(r.grandTotalSalary || 0)}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-1 text-xs">
                      <span className="text-muted">Tổng km: <strong className="text-ink">{r.motorbike?.totalKm?.toLocaleString('vi-VN', { maximumFractionDigits: 1 }) || '0'}</strong></span>
                      <span className="text-emerald-600 dark:text-emerald-400">Xăng xe: {formatCurrency(fuelPay)}</span>
                      <span className="text-muted">Xe máy: {r.motorbike?.totalTrips || 0} lượt · Xe tải: {r.truck?.totalTrips || 0} lượt</span>
                      <span className="text-amber-600 dark:text-amber-400">Giao hàng: {formatCurrency(deliveryPay)}</span>
                    </div>
                  </div>
                );
              })}
              {/* (10/2026) Dòng tổng mobile cho NV hỗ trợ */}
              <div className="rounded-xl bg-canvas p-3 flex items-center justify-between text-sm">
                <span className="text-muted font-semibold">Tổng chi phụ cấp NV hỗ trợ</span>
                <span className="font-bold text-blue-600 dark:text-blue-400">
                  {formatCurrency(
                    (cfg.nonDriverRows || []).reduce((s, r) => s + (r.grandTotalSalary || 0), 0),
                  )}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* (10/2026) Dòng tổng chung cho cả 3 phần: Tài xế xe máy + Tài xế xe tải (cố định) + NV hỗ trợ */}
        {((rows.length > 0) || ((cfg?.truckDriverRows || []).length > 0)
          || ((cfg?.nonDriverRows || []).length > 0)) && (() => {
          const motoSum  = (rows || []).reduce((s, r) => s + (r.grandTotalSalary || 0), 0);
          const truckSum = (cfg?.truckDriverRows || []).reduce(
            (s, r) => s + (r.fixedTruckBonus || 0), 0);
          const supportSum = (cfg?.nonDriverRows || []).reduce(
            (s, r) => s + (r.grandTotalSalary || 0), 0);
          const grand = motoSum + truckSum + supportSum;
          return (
            <div className="mt-5 rounded-xl border border-gold/30 bg-gold/10
                            px-4 py-3 flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2 text-sm">
                <Gift size={14} className="text-gold" />
                <span className="font-bold text-ink uppercase tracking-wider text-xs">
                  Tổng chi lương + phụ cấp tài xế
                </span>
              </div>
              <div className="flex items-center gap-4 text-xs flex-wrap">
                <span className="text-muted">
                  Xe máy: <strong className="text-ink tabular-nums">{formatCurrency(motoSum)}</strong>
                </span>
                <span className="text-muted">
                  + Xe tải: <strong className="text-ink tabular-nums">{formatCurrency(truckSum)}</strong>
                </span>
                <span className="text-muted">
                  + Hỗ trợ: <strong className="text-ink tabular-nums">{formatCurrency(supportSum)}</strong>
                </span>
                <span className="text-base font-bold text-gold tabular-nums">
                  = {formatCurrency(grand)}
                </span>
              </div>
            </div>
          );
        })()}
      </div>

      {modalDriver && (
        <DriverDetailModal driver={modalDriver} month={month} year={year}
          onClose={() => setModalDriver(null)} />
      )}
    </SectionCard>
  );
}

/** 1 dòng chính (xe máy) + 1 dòng phụ (xe tải) cho 1 tài xế, hoặc đảo lại nếu
    chỉ có xe tải. Rowspan cột "Tổng lương tài xế" gộp 2 dòng. */
function DriverSalaryRows({ row, onOpen }) {
  const hasMoto = !!row.motorbike;
  const hasTruck = !!row.truck;
  const rowspan = (hasMoto && hasTruck) ? 2 : 1;

  // FIX (11/2026): shared hover state cho cả 2 <tr>.
  //
  // Vì <tr> không thể bọc trong 1 wrapper (HTML table không cho phép) nên
  // không dùng được Tailwind `group`. Dùng useState để khi hover vào DÒNG
  // NÀO cũng set hovered=true → cả 2 cùng `bg-canvas`. Trước đây mỗi <tr>
  // có hover:bg-canvas riêng nên chỉ highlight đúng dòng chuột trỏ.
  const [hovered, setHovered] = useState(false);
  const trClass = `cursor-pointer transition-colors ${hovered ? 'bg-canvas' : ''}`;
  const onEnter = () => setHovered(true);
  const onLeave = () => setHovered(false);
  const openRow = () => onOpen({
    userId: row.userId, name: row.driverName, vehicleType: row.vehicleType,
  });

  const nameCell = (
    <td rowSpan={rowspan} className="px-3 py-2 font-medium text-ink align-top border-t border-hairline">
      <button onClick={openRow} className="text-left hover:text-gold">
        {row.driverName}
        {/* FIX (11/2026): bỏ nhãn "Xe máy / Xe tải / Xe máy + Xe tải" dưới tên
            — loại đã tách thành 2 dòng con bên dưới (có badge trong SalaryCells),
            nên dòng này chỉ gây lặp thông tin. */}
      </button>
    </td>
  );
  const grandCell = (
    <td rowSpan={rowspan} className="px-3 py-2 text-right align-middle border-t border-hairline">
      <span className="font-bold text-gold">
        {row.grandTotalSalary != null ? formatCurrency(row.grandTotalSalary) : '—'}
      </span>
    </td>
  );

  // Dòng chính: XE MÁY nếu có, ngược lại XE TẢI (khi tài xế chỉ chạy xe tải).
  const first = hasMoto ? { kind: 'MOTO', s: row.motorbike } : { kind: 'TRUCK', s: row.truck };
  const second = (hasMoto && hasTruck) ? { kind: 'TRUCK', s: row.truck } : null;

  return (
    <>
      <tr className={trClass} onClick={openRow}
        onMouseEnter={onEnter} onMouseLeave={onLeave}>
        {nameCell}
        <SalaryCells s={first.s} kind={first.kind} />
        {grandCell}
      </tr>
      {second && (
        <tr className={trClass} onClick={openRow}
          onMouseEnter={onEnter} onMouseLeave={onLeave}>
          <SalaryCells s={second.s} kind={second.kind} subRow />
        </tr>
      )}
    </>
  );
}

function SalaryCells({ s, kind, subRow }) {
  const isTruck = kind === 'TRUCK';
  const label = isTruck ? 'Xe tải' : 'Xe máy';
  return (
    <>
      <td className={`px-3 py-2 text-right ${subRow ? '' : 'border-t border-hairline'}`}>
        <div className="flex items-center justify-end gap-1">
          {subRow && <CornerDownRight size={11} className="text-muted" />}
          <span className="text-[10px] px-1.5 py-0.5 rounded font-medium bg-canvas text-muted">{label}</span>
          {!isTruck && <span className="text-ink font-medium ml-1">{fmtNum(s?.totalKm, 1)}</span>}
        </div>
      </td>
      <td className={`px-3 py-2 text-right ${subRow ? '' : 'border-t border-hairline'}`}>{s?.totalTrips ?? 0}</td>
      <td className={`px-3 py-2 text-right ${subRow ? '' : 'border-t border-hairline'}`}>
        {isTruck ? '—' : (s?.fuelPay != null ? formatCurrency(s.fuelPay) : '—')}
      </td>
      {/* (10/2026) FIX: cột "Thưởng" phải là CHỈ số lượt × đơn giá theo loại
          (bonusPay). Trước đây lấy totalSalary = fuelPay + bonusPay nên bị cộng
          thêm tiền xăng vào — lệch với ý nghĩa cột "Thưởng" ở header + lệch với
          cách bảng Nhân viên hỗ trợ đang hiển thị. */}
      <td className={`px-3 py-2 text-right font-semibold ${subRow ? '' : 'border-t border-hairline'}`}>
        {s?.bonusPay != null ? formatCurrency(s.bonusPay) : '—'}
      </td>
    </>
  );
}

/** Card cho mobile: 1 card chính + card con nếu tài xế chạy cả 2 loại. */
function DriverSalaryCard({ row, onOpen }) {
  const hasMoto = !!row.motorbike;
  const hasTruck = !!row.truck;
  return (
    <div onClick={() => onOpen({ userId: row.userId, name: row.driverName, vehicleType: row.vehicleType })}
      className="rounded-2xl border border-hairline bg-surface p-3 cursor-pointer active:scale-[0.99] transition-transform">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-bold text-ink">{row.driverName}</p>
          {/* FIX (11/2026): bỏ nhãn "Xe máy / Xe tải / Xe máy + Xe tải" dưới tên
              — loại đã có badge trong 2 sub-card bên dưới. */}
        </div>
        <div className="text-right">
          <p className="text-[10px] text-muted uppercase tracking-wider">Tổng lương</p>
          <p className="text-base font-bold text-gold">
            {row.grandTotalSalary != null ? formatCurrency(row.grandTotalSalary) : '—'}
          </p>
        </div>
      </div>
      <div className="mt-3 space-y-2">
        {hasMoto && <VehicleSubCard s={row.motorbike} kind="MOTO" />}
        {hasTruck && <VehicleSubCard s={row.truck} kind="TRUCK" />}
      </div>
    </div>
  );
}

function VehicleSubCard({ s, kind }) {
  const isTruck = kind === 'TRUCK';
  const label = isTruck ? 'Xe tải' : 'Xe máy';
  return (
    <div className="rounded-xl bg-canvas p-2.5">
      <div className="flex items-center justify-between mb-1.5">
        <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${isTruck ? 'bg-blue-500/10 text-blue-600 dark:text-blue-300'
            : 'bg-amber-500/10 text-amber-600 dark:text-amber-300'}`}>
          {label}
        </span>
        <span className="text-sm font-bold text-ink">
          {/* (10/2026) Giống desktop: chỉ hiện BONUS (số lượt × đơn giá), bỏ phần fuel. */}
          {s?.bonusPay != null ? formatCurrency(s.bonusPay) : '—'}
        </span>
      </div>
      <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[11px]">
        {!isTruck && (
          <>
            <span className="text-muted">Tổng km</span>
            <span className="text-right text-ink font-medium">{fmtNum(s?.totalKm, 1)} km</span>
          </>
        )}
        <span className="text-muted">Số đơn</span>
        <span className="text-right text-ink font-medium">{s?.totalOrders ?? 0}</span>
        <span className="text-muted">Số lượt</span>
        <span className="text-right text-ink font-medium">{s?.totalTrips ?? 0}</span>
        {!isTruck && (
          <>
            <span className="text-muted">Tiền xăng</span>
            <span className="text-right text-ink font-medium">
              {s?.fuelPay != null ? formatCurrency(s.fuelPay) : '—'}
            </span>
          </>
        )}
        <span className="text-muted">Thưởng</span>
        <span className="text-right text-ink font-medium">
          {s?.bonusPay != null ? formatCurrency(s.bonusPay) : '—'}
        </span>
      </div>
    </div>
  );
}

/** Modal chi tiết: Tab 1 = đơn hàng theo ngày, Tab 2 = chi tiết lương. */
function DriverDetailModal({ driver, month, year, onClose }) {
  const toast = useToast();
  const [tab, setTab] = useState('orders');
  const [dm, setDm] = useState(null);      // DriverMonthDto (đơn hàng theo ngày)
  const [salary, setSalary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [openDays, setOpenDays] = useState({}); // day -> collapsed?

  useEffect(() => {
    let alive = true;
    (async () => {
      setLoading(true);
      try {
        const [d, s] = await Promise.all([
          factoryPayrollApi.employeeDriver(driver.userId, month, year),
          factoryPayrollApi.driverSalaryDetail(driver.userId, month, year),
        ]);
        if (!alive) return;
        setDm(d); setSalary(s);
        // Mặc định mở tất cả ngày có đơn
        const init = {};
        (d?.days || []).forEach(day => { if ((day.orderCount || 0) > 0) init[day.day] = true; });
        setOpenDays(init);
      } catch (e) {
        toast(e?.response?.data?.message || 'Không tải được chi tiết', 'error');
      } finally { setLoading(false); }
    })();
    return () => { alive = false; };
  }, [driver.userId, month, year]); // eslint-disable-line

  // Danh sách ngày có đơn, sort tăng dần (đã có trong dm.days)
  const daysWithOrders = (dm?.days || []).filter(d => (d.orders?.length || 0) > 0);

  const payStatusColor = (st) => st === 'PAID'
    ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-300'
    : st === 'PARTIAL'
      ? 'bg-amber-500/10 text-amber-600 dark:text-amber-300'
      : 'bg-red-500/10 text-red-600 dark:text-red-300';

  return (
    <div className="fixed inset-0 z-[95] flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4">
      <div className="bg-surface rounded-t-2xl sm:rounded-2xl shadow-2xl w-full max-w-6xl max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-hairline">
          <div>
            <p className="font-bold text-ink text-sm sm:text-base">{driver.name}</p>
            <p className="text-xs text-muted">Tháng {month}/{year}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-canvas text-muted">
            <X size={18} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-hairline shrink-0">
          {[
            { k: 'orders', label: 'Đơn hàng trong tháng' },
            { k: 'salary', label: 'Chi tiết lương' },
          ].map(t => (
            <button key={t.k} onClick={() => setTab(t.k)}
              className={`flex-1 px-4 py-3 text-sm font-semibold transition-colors ${tab === t.k ? 'text-gold border-b-2 border-gold' : 'text-muted hover:text-ink'}`}>
              {t.label}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-5">
          {loading ? <LoadingSpinner /> : tab === 'orders' ? (
            <>
              {daysWithOrders.length === 0 ? (
                <EmptyState title="Không có đơn" description="Tài xế chưa giao đơn nào trong tháng này." />
              ) : (
                <div className="space-y-2">
                  {daysWithOrders.map(day => (
                    <div key={day.day} className="rounded-xl border border-hairline overflow-hidden">
                      <button onClick={() => setOpenDays(o => ({ ...o, [day.day]: !o[day.day] }))}
                        className="w-full flex items-center justify-between px-3 sm:px-4 py-2.5 bg-canvas hover:bg-surface-2 transition">
                        <div className="flex items-center gap-2">
                          <ChevronDown size={14}
                            className={`text-muted transition-transform ${openDays[day.day] ? '' : '-rotate-90'}`} />
                          <span className="text-sm font-bold text-ink">
                            {String(day.day).padStart(2, '0')}/{String(month).padStart(2, '0')}/{year}
                          </span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-canvas text-muted">
                            {day.weekdayLabel}
                          </span>
                        </div>
                        <span className="text-xs font-semibold text-gold">{day.orders.length} đơn</span>
                      </button>
                      {openDays[day.day] && (
                        <div className="p-2 space-y-2 bg-surface">
                          {day.orders.map(o => <OrderRow key={o.orderId} o={o} payStatusColor={payStatusColor} />)}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </>
          ) : (
            <SalaryDetailTab salary={salary} days={dm?.days || []} month={month} year={year} />
          )}
        </div>
      </div>
    </div>
  );
}

/** Lịch tháng của tài xế: màu ô theo điểm danh + 2 badge (số đơn / tổng km). */
function MonthCalendar({ days, month, year }) {
  if (!days || days.length === 0) return null;

  // Bắt đầu tuần T2. weekday: 2..7 = T2..T7, 8 = CN → cột 1..7
  const colOf = (wd) => (wd === 8 ? 7 : Math.max(1, wd - 1));
  const first = days[0];
  const leading = colOf(first.weekday) - 1;

  const colorCls = (c) => c === 'GREEN'
    ? 'bg-emerald-500/15 border-emerald-500/40'
    : c === 'YELLOW'
      ? 'bg-amber-400/15 border-amber-400/40'
      : 'bg-canvas border-hairline';

  return (
    <div className="rounded-2xl border border-hairline bg-surface p-4">
      <div className="flex items-center justify-between mb-3 gap-2">
        <p className="text-sm font-bold text-ink">Điểm danh tháng {month}/{year}</p>
        <div className="flex items-center gap-2.5 text-[10px] text-muted">
          <span className="flex items-center gap-1"><span className="inline-block w-2.5 h-2.5 rounded bg-emerald-500/60" /> Đủ</span>
          <span className="flex items-center gap-1"><span className="inline-block w-2.5 h-2.5 rounded bg-amber-400/70" /> Thiếu 1</span>
          <span className="flex items-center gap-1"><span className="inline-block w-2.5 h-2.5 rounded bg-hairline-2" /> Không</span>
        </div>
      </div>

      {/* Nhãn thứ */}
      <div className="grid grid-cols-7 gap-1.5 mb-1.5">
        {['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'].map(w => (
          <div key={w} className="text-[11px] text-muted text-center font-semibold py-1">{w}</div>
        ))}
      </div>

      {/* Các ô ngày */}
      <div className="grid grid-cols-7 gap-1.5">
        {Array.from({ length: leading }).map((_, i) => <div key={`x${i}`} />)}
        {days.map(d => {
          const orders = d.orderCount || 0;
          const km = d.totalKm || 0;
          return (
            <div key={d.day}
              className={`aspect-square rounded-lg border p-1.5 flex flex-col ${colorCls(d.dayColor)}`}>
              <span className="text-xs font-bold text-ink leading-none">{d.day}</span>
              {(orders > 0 || km > 0) && (
                <div className="mt-auto flex flex-col items-end gap-0.5">
                  {orders > 0 && (
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-blue-500 text-white leading-none">
                      {orders} đơn
                    </span>
                  )}
                  {km > 0 && (
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-blue-600 text-white leading-none">
                      {Math.round(km)} km
                    </span>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function OrderRow({ o, payStatusColor }) {
  const fmtDT = (ts) => ts ? new Date(ts).toLocaleString('vi-VN', {
    day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit',
  }) : '—';
  return (
    <div className="rounded-lg bg-canvas p-3 space-y-1.5">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0 flex-1">
          <p className="text-sm font-bold text-gold font-mono">{o.orderCode}</p>
          {o.customerName && (
            <p className="text-[11px] text-muted flex items-center gap-1 mt-0.5">
              <UserIcon size={10} /> {o.customerName}
            </p>
          )}
        </div>
        <span className={`text-[10px] px-2 py-0.5 rounded font-bold whitespace-nowrap ${payStatusColor(o.paymentStatus)}`}>
          {o.paymentStatusLabel}
        </span>
      </div>
      <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[11px]">
        <span className="text-muted">Số tiền đơn</span>
        <span className="text-right text-ink font-semibold">{formatCurrency(o.finalAmount || 0)}</span>
        <span className="text-muted">Đã thanh toán</span>
        <span className="text-right text-emerald-600 dark:text-emerald-300 font-semibold">
          {formatCurrency(o.paidAmount || 0)}
        </span>
        <span className="text-muted">Đặt lúc</span>
        <span className="text-right text-ink">{fmtDT(o.placedAt)}</span>
        <span className="text-muted">Bắt đầu giao</span>
        <span className="text-right text-ink">{fmtDT(o.deliveredAt)}</span>
      </div>
      {o.deliveryAddress && (
        <p className="text-[11px] text-muted flex items-start gap-1 pt-1 border-t border-hairline">
          <MapPin size={11} className="mt-0.5 shrink-0" />
          <span className="line-clamp-2">{o.deliveryAddress}</span>
        </p>
      )}
      {(o.tripsMotorbike > 0 || o.tripsTruck > 0) && (
        <div className="flex items-center gap-2 text-[10px] pt-1">
          {o.tripsMotorbike > 0 && (
            <span className="px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-600 dark:text-amber-300 font-semibold">
              Xe máy × {o.tripsMotorbike}
            </span>
          )}
          {o.tripsTruck > 0 && (
            <span className="px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-600 dark:text-blue-300 font-semibold">
              Xe tải × {o.tripsTruck}
            </span>
          )}
        </div>
      )}
    </div>
  );
}

function SalaryDetailTab({ salary, days, month, year }) {
  if (!salary) return <EmptyState title="Chưa có" description="Không có dữ liệu lương." />;
  return (
    // Mobile (mặc định flex-col): calendar TRƯỚC, khối lương ở dưới.
    // Desktop (md+): 2 cột — lương 7/12, calendar 5/12; gap rộng hơn cho thoáng.
    <div className="flex flex-col md:grid md:grid-cols-12 md:gap-5 gap-3">
      <div className="order-2 md:order-1 md:col-span-7 space-y-3">
        <DriverEmployeeCard salary={salary} />
        <DriverEmployerCard salary={salary} />
      </div>
      <div className="order-1 md:order-2 md:col-span-5">
        <div className="md:sticky md:top-2">
          <MonthCalendar days={days} month={month} year={year} />
        </div>
      </div>
    </div>
  );
}

/** Card "Của doanh nghiệp phải trả" — copy nguyên từ SalaryBreakdownCards
    (bản mới), giữ đúng layout với các bộ phận khác. Tách ra vì phải bỏ Card 1
    NLĐ (đã có DriverEmployeeCard riêng). */
function DriverEmployerCard({ salary: row }) {
  const fmt = (n) => formatCurrency(n || 0);
  const noIns = row.insuranceExempt != null ? !!row.insuranceExempt : !(row.insuranceSalary > 0);
  const employerIns = row.employerInsuranceTotal || 0;
  const employeeIns = row.employeeInsuranceTotal || 0;
  const pit = row.personalIncomeTax || 0;
  const insuranceBothSides = employerIns + employeeIns;

  const Row = ({ label, val, sub, bold, green }) => (
    <div className={`flex items-center justify-between ${sub ? 'pl-4 py-0.5' : 'py-1'}`}>
      <span className={`text-sm ${sub ? 'text-muted italic' : bold ? 'font-bold text-ink' : 'text-ink'}`}>{label}</span>
      <span className={`text-sm whitespace-nowrap ${bold ? 'font-bold' : 'font-medium'} ${green ? 'text-emerald-700 dark:text-emerald-300' : 'text-ink'}`}>{val}</span>
    </div>
  );
  const Divider = () => <div className="h-px bg-surface-2 my-1" />;

  return (
    <div className="bg-canvas rounded-xl p-4 space-y-2">
      <p className="text-xs font-bold text-muted uppercase tracking-wider mb-2">
        Của doanh nghiệp phải trả (VNĐ)
      </p>
      <Row label="Lương thực nhận trả cho nhân viên" val={fmt(row.netSalary)} />
      {noIns ? (
        <>
          <Divider />
          <Row label="Bảo hiểm bắt buộc" val="Không tham gia" />
          {pit > 0 && (<><Divider /><Row label="Thuế TNCN doanh nghiệp nộp thay" val={`+ ${fmt(pit)}`} /></>)}
        </>
      ) : (
        <>
          <Divider />
          <Row label="Bảo hiểm doanh nghiệp đóng (21,5%)" val={`+ ${fmt(employerIns)}`} bold />
          <Row sub label="Bảo hiểm xã hội (17%)" val={`+ ${fmt(row.employerSocialInsurance)}`} />
          <Row sub label="BH Tai nạn LĐ - Bệnh nghề nghiệp (0,5%)" val={`+ ${fmt(row.employerAccidentInsurance)}`} />
          <Row sub label="Bảo hiểm y tế (3%)" val={`+ ${fmt(row.employerHealthInsurance)}`} />
          <Row sub label="Bảo hiểm thất nghiệp (1%)" val={`+ ${fmt(row.employerUnemploymentInsurance)}`} />
          <Divider />
          <Row label="Bảo hiểm cá nhân đóng (10,5%) — DN trả thay" val={`+ ${fmt(employeeIns)}`} bold />
          <Row sub label="Bảo hiểm xã hội (8%)" val={`+ ${fmt(row.employeeSocialInsurance)}`} />
          <Row sub label="Bảo hiểm y tế (1,5%)" val={`+ ${fmt(row.employeeHealthInsurance)}`} />
          <Row sub label="Bảo hiểm thất nghiệp (1%)" val={`+ ${fmt(row.employeeUnemploymentInsurance)}`} />
          <Row label="Thuế TNCN — DN nộp thay" val={`+ ${fmt(pit)}`} bold />
          {(row.pitBrackets || []).map((b, i) => (
            <Row key={i} sub label={`Bậc ${b.ratePercent}% trên ${fmt(b.incomeInBracket)}`}
              val={`+ ${fmt(b.taxInBracket)}`} />
          ))}
          <Divider />
          <Row label="TỔNG TIỀN BẢO HIỂM (cả 2 phần — 32%)" val={fmt(insuranceBothSides)} bold />
        </>
      )}
      <Divider />
      <Row label="TỔNG DOANH NGHIỆP PHẢI CHI TRẢ" val={fmt(row.totalCost)} bold green />
    </div>
  );
}

/** Card "Của người lao động" riêng cho TÀI XẾ — chỉ hiện các dòng theo yêu cầu:
    Lương cơ bản → phụ cấp (cơm, xăng, …) → Tổng phụ cấp → Thưởng đơn hàng →
    Thưởng KPI → LƯƠNG THỰC NHẬN. */
function DriverEmployeeCard({ salary }) {
  const fmt = (n) => formatCurrency(n || 0);
  const allowances = salary.allowances || [];
  const totalAllowance = allowances.reduce((s, a) => s + (a.amount || 0), 0);
  const kpi = salary.kpiPercent != null ? salary.kpiPercent : 100;
  const kpiStr = Number.isInteger(kpi) ? `${kpi}%` : `${kpi.toFixed(2)}%`;
  // Tách rõ: KPI thuần vs bonus items import (Chuyên cần, Tháng 13…). Field
  // effectiveBonus cũ gộp cả 2 → sẽ hiện Chuyên cần thành "Thưởng KPI".
  const bonusItems = salary.bonusItems || [];
  const bonusItemsTotal = salary.bonusItemsTotal
    || bonusItems.reduce((s, b) => s + (b.amount || 0), 0);
  const effBonusKpi = salary.effectiveBonusKpiOnly != null
    ? salary.effectiveBonusKpiOnly
    : ((salary.effectiveBonus || 0) - bonusItemsTotal);
  const orderBonus = salary.driverOrderBonus || 0;
  const totalBonus = orderBonus + (salary.effectiveBonus || 0);
  const bonusSourceCount = (orderBonus > 0 ? 1 : 0)
    + bonusItems.length + (effBonusKpi > 0 ? 1 : 0);

  const Row = ({ label, val, sub, bold, green }) => (
    <div className={`flex items-center justify-between ${sub ? 'pl-4 py-0.5' : 'py-1'}`}>
      <span className={`text-sm ${sub ? 'text-muted italic' : bold ? 'font-bold text-ink' : 'text-ink'}`}>
        {label}
      </span>
      <span className={`text-sm whitespace-nowrap ${bold ? 'font-bold' : 'font-medium'} ${green ? 'text-emerald-700 dark:text-emerald-300' : 'text-ink'}`}>{val}</span>
    </div>
  );
  const Divider = () => <div className="h-px bg-surface-2 my-1" />;

  return (
    <div className="bg-canvas rounded-xl p-4 space-y-2">
      <p className="text-xs font-bold text-muted uppercase tracking-wider mb-2">
        Của người lao động (VNĐ)
      </p>
      <Row label="Lương cơ bản" val={fmt(salary.baseSalary)} />

      {allowances.length > 0 && (
        <>
          <Divider />
          {allowances.map((a, i) => (
            <Row key={i} label={a.label || 'Phụ cấp'} val={`+ ${fmt(a.amount)}`} />
          ))}
          {allowances.length > 1 && (
            <Row sub label="Tổng phụ cấp" val={`+ ${fmt(totalAllowance)}`} />
          )}
        </>
      )}

      <Divider />
      {/* Thưởng đơn hàng — nếu có DETAIL thì hiện 3 dòng (xe máy / xe tải / tổng) */}
      {salary.driverOrderBonusDetail ? (
        <>
          {(salary.driverOrderBonusDetail.motorbikeAmount || 0) > 0 && (
            <Row label={`Thưởng đơn hàng (xe máy × ${salary.driverOrderBonusDetail.motorbikeTrips || 0} lượt)`}
              val={`+ ${fmt(salary.driverOrderBonusDetail.motorbikeAmount)}`} />
          )}
          {(salary.driverOrderBonusDetail.truckAmount || 0) > 0 && (
            <Row label={`Thưởng đơn hàng (xe tải × ${salary.driverOrderBonusDetail.truckTrips || 0} lượt)`}
              val={`+ ${fmt(salary.driverOrderBonusDetail.truckAmount)}`} />
          )}
          {(salary.driverOrderBonusDetail.motorbikeAmount || 0) > 0
            && (salary.driverOrderBonusDetail.truckAmount || 0) > 0 && (
              <Row sub label="Tổng thưởng đơn hàng"
                val={`+ ${fmt(salary.driverOrderBonusDetail.totalAmount)}`} />
            )}
        </>
      ) : orderBonus > 0 && (
        <Row label="Thưởng đơn hàng" val={`+ ${fmt(orderBonus)}`} />
      )}
      {bonusItems.map((b, i) => (
        <Row key={i} label={b.label || 'Thưởng khác'} val={`+ ${fmt(b.amount)}`} />
      ))}
      <Row label={`Thưởng KPI — đạt ${kpiStr}`} val={`+ ${fmt(effBonusKpi)}`} />
      {bonusSourceCount > 1 && (
        <Row sub label="Tổng thưởng" val={`+ ${fmt(totalBonus)}`} />
      )}

      <Divider />
      <Row label="LƯƠNG THỰC NHẬN" val={fmt(salary.netSalary)} bold green />
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// TASK 2 (11/2026) — BẢNG CHI TIẾT HOA HỒNG cho SALES / ACCOUNTING
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Hiển thị preview Thưởng/Hoa hồng cho tab Kế toán hoặc Kinh doanh.
 *
 * Flow:
 *  1. Load /office-bonus-preview — trả về 3 stat phòng + items[] mỗi nhân viên.
 *     Chạy được CẢ khi chưa tính (items[*].bonusAmount = null → cột hiển thị "—")
 *     và SAU khi đã tính.
 *  2. Ô input "Đơn giá hoa hồng" với placeholder = đơn giá tháng gần nhất
 *     (data.lastCommissionUnitPrice). Mỗi tháng OWNER tự nhập số mới — không
 *     kế thừa tự động.
 *  3. Bấm "Tính hoa hồng" → gọi finalizeBonus(month, year, dept, unitPrice).
 *     BE tính theo công thức trong OfficeBonusCommissionUtil.
 *
 * Props:
 *   department:       'SALES' | 'ACCOUNTING'
 *   departmentLabel:  tiêu đề card
 *   month, year:      kỳ đang chọn
 *   bonusFinalized:   trạng thái lock — khi true, disable input + nút
 *   canCompute:       true nếu attendance đã finalized
 *   onComputed:       callback để parent reload trạng thái
 */
function OfficeBonusDetailTable({
  department, departmentLabel, month, year,
  bonusFinalized, bonusCalcStatus, onComputed, onReopen, onPublish, onUnpublish,
  publishingBonus,
}) {
  // (10/2026) 3-state cho Thưởng KT/KD:
  //   NONE       = chưa tính           → nút "Tính hoa hồng"
  //   CALCULATED = đã tính, chưa Public → "Tính lại hoa hồng" + "Hoàn tất"
  //   PUBLISHED  = đã tính, đã Public   → "Mở lại" (= Unpublic, GIỮ data)
  // Fallback: bonusCalcStatus null thì suy từ bonusFinalized để tương thích
  // phiên bản BE cũ chưa trả bonusCalcStatus.
  const bonusState = bonusCalcStatus
    || (bonusFinalized ? 'PUBLISHED' : 'NONE');
  const isNone      = bonusState === 'NONE';
  const isCalc      = bonusState === 'CALCULATED';
  const isPublished = bonusState === 'PUBLISHED';
  const [preview, setPreview] = useState(null);
  const [loading, setLoading] = useState(true);
  const [unitPriceInput, setUnitPriceInput] = useState('');
  const [computing, setComputing] = useState(false);
  // Modal cấu hình (SALES: tiers / ACCOUNTING: %+ratios). TASK 2 (10/2026).
  const [configModalOpen, setConfigModalOpen] = useState(false);
  // (10/2026) SALES v2: review-modal state sau khi preview
  const [salesV2Preview, setSalesV2Preview] = useState(null);
  const [salesV2Publishing, setSalesV2Publishing] = useState(false);
  const [salesV2ConfirmPublish, setSalesV2ConfirmPublish] = useState(false);
  // (10/2026) Config v2 hiện tại (hiển thị target + multiplier trên card)
  const [salesV2Config, setSalesV2Config] = useState(null);
  const toast = useToast();

  // ── Load preview ────────────────────────────────────────────────────────
  //
  // Giữ nguyên `preview` cũ trong khi fetch (chỉ bật flag `loading` để báo
  // visual) → KHÔNG unmount SectionCard khi làm mới → không flicker UI.
  // Chỉ show full LoadingSpinner ở lần load ĐẦU TIÊN khi chưa có preview nào.
  const load = useCallback(async () => {
    if (!month || !year) return;
    setLoading(true);
    try {
      const data = await factoryPayrollApi.officeBonusPreview(month, year, department);
      setPreview(data);
      setUnitPriceInput(data?.commissionUnitPrice != null
        ? Number(data.commissionUnitPrice).toLocaleString('vi-VN')
        : '');
      // (10/2026) Nếu là SALES → load luôn config v2 để hiện target/multiplier
      if (department === 'SALES') {
        try {
          const cur = await factoryPayrollApi.getCurrentSalesBonusV2(month, year);
          setSalesV2Config(cur || null);
        } catch { setSalesV2Config(null); }
      } else {
        setSalesV2Config(null);
      }
    } catch (e) {
      toast(e?.response?.data?.message || 'Không tải được preview hoa hồng', 'error');
    } finally {
      setLoading(false);
    }
  }, [month, year, department, toast]);

  useEffect(() => { load(); }, [load]);

  // ── Parse ô input giá VN ("1.234.567" → 1234567) ────────────────────────
  const parseVn = (s) => {
    const d = String(s ?? '').replace(/[^\d]/g, '');
    return d ? Number(d) : null;
  };
  const handlePriceChange = (e) => {
    const digits = String(e.target.value).replace(/[^\d]/g, '');
    setUnitPriceInput(digits ? Number(digits).toLocaleString('vi-VN') : '');
  };

  const handleCompute = async () => {
    const price = parseVn(unitPriceInput);
    if (!price || price <= 0) {
      toast('Vui lòng nhập đơn giá hoa hồng (> 0)', 'error');
      return;
    }
    setComputing(true);
    try {
      await factoryPayrollApi.finalizeBonus(month, year, department, price);
      toast(`Đã tính hoa hồng ${departmentLabel} tháng ${month}/${year}`, 'success');
      await load();
      onComputed?.();
    } catch (e) {
      toast(e?.response?.data?.message || 'Lỗi tính hoa hồng', 'error');
    } finally {
      setComputing(false);
    }
  };

  // Flow MỚI 2026: nhận cấu hình từ modal, gửi body JSON.
  //   SALES:      { salesTiers: [{threshold, unitPrice}] }
  //   ACCOUNTING: { accountingPercent, accountingRatios: [{userId, ratio}] }
  const handleComputeWithConfig = async (configBody) => {
    setComputing(true);
    try {
      await factoryPayrollApi.finalizeBonus(month, year, department, configBody);
      toast(`Đã tính hoa hồng ${departmentLabel} tháng ${month}/${year}`, 'success');
      setConfigModalOpen(false);
      await load();
      onComputed?.();
    } catch (e) {
      toast(e?.response?.data?.message || 'Lỗi tính hoa hồng', 'error');
    } finally {
      setComputing(false);
    }
  };

  const fmtMoney = (v) => v == null ? '—'
    : Number(v).toLocaleString('vi-VN', { maximumFractionDigits: 0 }) + 'đ';

  const monthLabel = `${String(month).padStart(2, '0')}/${year}`;

  const placeholderPrice = preview?.lastCommissionUnitPrice != null
    ? Number(preview.lastCommissionUnitPrice).toLocaleString('vi-VN')
    : 'VD: 400.000';

  const isSales = department === 'SALES';
  const items = preview?.items || [];
  const anyComputed = preview?.commissionCalculated;
  const isRefreshing = loading && !!preview;  // refresh (có preview cũ) vs first-load

  return (
    <SectionCard>
      {/* ── HEADER (luôn visible, kể cả khi refresh) ───────────────────── */}
      <div className="px-5 pt-5 pb-3 flex items-start justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3 min-w-0">
          <span className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-500/10
            flex items-center justify-center shrink-0">
            <Gift size={17} className="text-purple-500 dark:text-purple-300" />
          </span>
          <div className="min-w-0">
            <h3 className="text-sm font-bold text-ink">
              Bonus của {departmentLabel} · Tháng {monthLabel}
            </h3>
            <p className="text-[11px] text-muted mt-0.5">
              {isSales
                ? 'Mỗi seller tính riêng theo doanh thu thực thu EX-VAT của mình, theo nhiều mốc. Làm tròn LÊN 5.000đ.'
                : 'Pool phòng = doanh thu thực thu EX-VAT × % phòng, chia cho từng người theo tỉ lệ. Phần dư không chia cho ai (bỏ).'}
            </p>
          </div>
        </div>
        <SecondaryButton onClick={load} disabled={loading} size="sm">
          <RefreshCw size={13} className={loading ? 'animate-spin' : ''} /> Làm mới
        </SecondaryButton>
      </div>

      {!preview && loading ? (
        // Lần load ĐẦU TIÊN — chưa có dữ liệu, show spinner cả body
        <div className="px-5 pb-5"><LoadingSpinner /></div>
      ) : !preview ? (
        // Lỗi ngay lần load đầu (preview vẫn null sau khi load xong)
        <div className="px-5 pb-5 text-center text-sm text-muted">Không có dữ liệu</div>
      ) : (
        // Có preview (có thể đang refresh) — dim nhẹ khi refreshing để báo visual.
        <div className={`transition-opacity ${isRefreshing ? 'opacity-60' : 'opacity-100'}`}>
          {/* ── 3 STAT PHÒNG — THỨ TỰ MỚI: Tháng → Hold → Thực thu ───── */}
          <div className="px-5 pb-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <BonusStatBox
              label={`Tổng doanh thu tháng ${monthLabel}`}
              hint="Σ (finalAmount − vatAmount) các đơn tạo trong tháng — EX-VAT (loại HỦY)"
              value={fmtMoney(preview.totalMonthOrderRevenue)}
              // footer={
              //   preview.totalWaivedRevenue != null && Number(preview.totalWaivedRevenue) > 0
              //     ? <>Bỏ qua không thu (COMPLETED còn chênh): <strong className="tabular-nums">{fmtMoney(preview.totalWaivedRevenue)}</strong></>
              //     : null
              // }
              footer={''}
            />
            <BonusStatBox
              label={`Doanh thu đang hold tháng ${monthLabel}`}
              hint="Σ (final − paid) × netRatio — EX-VAT, status ≠ COMPLETED/CANCELLED"
              value={fmtMoney(preview.totalHoldRevenue)}
              tone="amber"
            />
            <BonusStatBox
              label="Doanh thu được chia hoa hồng"
              hint="= Σ thực thu EX-VAT + Σ waived EX-VAT (COMPLETED còn chênh). Chính là số pool được tính trên đó."
              value={fmtMoney(preview.totalCollectedRevenue)}
              tone="emerald"
            />
          </div>

          {/* ── NÚT MỞ MODAL CẤU HÌNH + HIỂN THỊ CẤU HÌNH ĐÃ DÙNG (TASK 2 10/2026) ── */}
          <div className="px-5 pb-4">
            <div className="rounded-xl border border-hairline-2 bg-canvas p-4
              flex items-center justify-between gap-4 flex-wrap">
              <div className="flex-1 min-w-[260px]">
                <label className="text-[11px] font-bold text-muted uppercase tracking-wider
                  flex items-center gap-1">
                  <Settings size={11} />
                  Cấu hình {isSales ? 'mốc thưởng' : 'tỉ lệ chia hoa hồng'}
                </label>
                <div className="mt-1.5 text-sm">
                  {isSales ? (
                    // (10/2026) SALES v2: hiển thị target + step + unit + multiplier
                    salesV2Config ? (
                      <div className="text-[12px] text-ink-2 space-y-0.5">
                        {(() => {
                          const target = Number(salesV2Config.target || 0);
                          const dept = Number(salesV2Config.deptRevenue || 0);
                          const pct = target > 0 ? Math.floor(dept / target * 10000) / 100 : 0;
                          // (10/2026) % mốc đạt được = multiplier × 100
                          const matchedPct = Math.round((salesV2Config.multiplier ?? 1) * 100);
                          const achievedColor = pct >= 90
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : pct >= 50 ? 'text-sky-600 dark:text-sky-400'
                            : 'text-amber-600 dark:text-amber-400';
                          return (
                            <>
                              <div>
                                <span className="text-muted">Target doanh thu:</span>{' '}
                                <strong className="text-ink tabular-nums">
                                  {target.toLocaleString('vi-VN')}đ
                                </strong>
                                {target > 0 && (
                                  <> · <span className="text-ink-2">Đạt{' '}
                                    <strong className={achievedColor}>{pct.toFixed(2)}%</strong>
                                  </span></>
                                )}
                              </div>
                              <div>
                                <span className="text-muted">Mỗi</span>{' '}
                                <strong className="text-ink tabular-nums">
                                  {Number(salesV2Config.stepAmount || 0).toLocaleString('vi-VN')}đ
                                </strong>{' '}
                                <span className="text-muted">=</span>{' '}
                                <strong className="text-ink tabular-nums">
                                  {Number(salesV2Config.stepUnitPrice || 0).toLocaleString('vi-VN')}đ
                                </strong>{' '}
                                <span className="text-muted">/ bước</span>
                                {' · '}
                                <span className="text-muted">áp dụng</span>{' '}
                                <strong className={achievedColor}>{matchedPct}%</strong>
                              </div>
                            </>
                          );
                        })()}
                      </div>
                    ) : (
                      <span className="text-muted">Chưa cấu hình — bấm "Tính hoa hồng" để nhập các mốc.</span>
                    )
                  ) : (
                    preview.accountingPercent != null && preview.accountingRatios?.length > 0
                      ? <>Phòng: <strong className="text-ink">{Number(preview.accountingPercent)}%</strong> doanh thu — chia theo tỉ lệ từng người (xem bảng dưới).</>
                      : <span className="text-muted">Chưa cấu hình — bấm "Tính hoa hồng" để nhập % phòng và tỉ lệ từng người.</span>
                  )}
                </div>
              </div>

              {/* (10/2026) 3-state buttons — thay thế flow 2-button cũ.
                * NONE       → "Tính hoa hồng"
                * CALCULATED → "Tính lại hoa hồng" + "Hoàn tất" (bật Public)
                * PUBLISHED  → "Mở lại" (= Unpublic, GIỮ data đã tính)
                */}
              <div className="flex items-center gap-2 flex-wrap shrink-0">
                {isNone && (
                  <PrimaryButton
                    onClick={() => setConfigModalOpen(true)}
                    disabled={computing}
                    loading={computing}>
                    <Calculator size={14} />
                    Tính hoa hồng
                  </PrimaryButton>
                )}
                {isCalc && isSales && (
                  <>
                    {/* (10/2026) SALES v2 — CALCULATED state:
                        "Tính hoa hồng" (reopen config để tính lại từ đầu) + "Hoàn tất" (publish) */}
                    <SecondaryButton
                      onClick={() => setConfigModalOpen(true)}
                      disabled={computing || publishingBonus}>
                      <Calculator size={14} />
                      Tính hoa hồng
                    </SecondaryButton>
                    <PrimaryButton
                      onClick={() => setSalesV2ConfirmPublish(true)}
                      disabled={publishingBonus || computing}>
                      <Gift size={14} />
                      Hoàn tất
                    </PrimaryButton>
                  </>
                )}
                {isCalc && !isSales && (
                  <>
                    <SecondaryButton
                      onClick={() => setConfigModalOpen(true)}
                      disabled={computing || publishingBonus}>
                      <Calculator size={14} />
                      Tính lại hoa hồng
                    </SecondaryButton>
                    <PrimaryButton
                      onClick={onPublish}
                      disabled={!onPublish || publishingBonus || computing}>
                      <Gift size={14} />
                      {publishingBonus ? 'Đang hoàn tất...' : 'Hoàn tất'}
                    </PrimaryButton>
                  </>
                )}
                {isPublished && (
                  <SecondaryButton
                    onClick={onUnpublish}
                    disabled={!onUnpublish || publishingBonus}
                    title="Nhân viên sẽ không còn thấy phiếu thưởng. Data đã tính vẫn giữ.">
                    <Unlock size={13} />
                    {publishingBonus ? 'Đang mở lại...' : (isSales ? 'Mở tính lại' : 'Mở lại')}
                  </SecondaryButton>
                )}
              </div>
            </div>
          </div>

          {/* Modal cấu hình: SALES v2 → target+step+unit, ACCOUNTING → %+ratios */}
          {configModalOpen && isSales && (
            <SalesBonusV2ConfigModal
              month={month} year={year}
              initialTarget={salesV2Preview?.target ?? salesV2Config?.target ?? 0}
              initialStepAmount={salesV2Preview?.stepAmount ?? salesV2Config?.stepAmount ?? 100_000_000}
              initialStepUnitPrice={salesV2Preview?.stepUnitPrice ?? salesV2Config?.stepUnitPrice ?? 400_000}
              computing={computing}
              onCancel={() => setConfigModalOpen(false)}
              initialTiers={salesV2Preview?.tiers ?? salesV2Config?.tiers}
              onConfirm={async ({ target, stepAmount, stepUnitPrice, tiers }) => {
                setComputing(true);
                try {
                  const res = await factoryPayrollApi.previewSalesBonusV2(month, year,
                    { target, stepAmount, stepUnitPrice, tiers });
                  setSalesV2Preview(res);
                  setConfigModalOpen(false);
                } catch (e) {
                  toast(e?.response?.data?.message || 'Không tính được thưởng Sales', 'error');
                } finally {
                  setComputing(false);
                }
              }}
            />
          )}
          {salesV2ConfirmPublish && isSales && (
            <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
              <div className="absolute inset-0 bg-black/60 backdrop-blur-sm"
                   onClick={() => !salesV2Publishing && setSalesV2ConfirmPublish(false)} />
              <div className="relative bg-surface w-full max-w-md rounded-2xl shadow-2xl p-5">
                <div className="flex items-center gap-2 mb-2">
                  <Gift size={20} className="text-emerald-500" />
                  <h4 className="text-base font-bold text-ink">Public thưởng Sales?</h4>
                </div>
                <p className="text-sm text-ink-2 mb-4">
                  Sau khi Public, nhân viên sẽ thấy phiếu thưởng tháng {month}/{year}.
                  Vẫn có thể "Mở tính lại" để điều chỉnh sau nếu cần.
                </p>
                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setSalesV2ConfirmPublish(false)}
                    disabled={salesV2Publishing}
                    className="px-4 py-2 rounded-lg text-sm font-semibold border border-hairline-2 hover:bg-canvas">
                    Hủy
                  </button>
                  <button
                    onClick={async () => {
                      setSalesV2Publishing(true);
                      try {
                        await factoryPayrollApi.publishSalesBonusV2(month, year);
                        toast('Đã Public thưởng Sales', 'success');
                        setSalesV2ConfirmPublish(false);
                        await load();
                        onComputed?.();  // parent reload status → nút đổi sang "Mở tính lại"
                      } catch (e) {
                        toast(e?.response?.data?.message || 'Không Public được', 'error');
                      } finally {
                        setSalesV2Publishing(false);
                      }
                    }}
                    disabled={salesV2Publishing}
                    className="px-4 py-2 rounded-lg text-sm font-semibold bg-emerald-500 text-white hover:bg-emerald-600 disabled:opacity-50 inline-flex items-center gap-1.5">
                    <Gift size={14} />
                    {salesV2Publishing ? 'Đang Public...' : 'Xác nhận'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {salesV2Preview && isSales && (
            <SalesBonusV2ReviewModal
              preview={salesV2Preview}
              publishing={salesV2Publishing}
              onCancel={() => setSalesV2Preview(null)}
              onBack={() => {
                // Quay lại ConfigModal (giữ nguyên salesV2Preview để prefill)
                setSalesV2Preview(null);
                setConfigModalOpen(true);
              }}
              onPublish={async (overrides) => {
                setSalesV2Publishing(true);
                try {
                  await factoryPayrollApi.saveSalesBonusV2(month, year, overrides);
                  toast('Đã lưu thưởng Sales (chưa Public). Bấm "Hoàn tất" để Public cho NV.', 'success');
                  setSalesV2Preview(null);
                  await load();
                  onComputed?.();  // báo parent reload status (bonusCalcStatus → CALCULATED)
                } catch (e) {
                  toast(e?.response?.data?.message || 'Không lưu được', 'error');
                } finally {
                  setSalesV2Publishing(false);
                }
              }}
            />
          )}
          {configModalOpen && !isSales && (
            <AccountingRatioModal
              month={month} year={year}
              items={items}
              initialPercent={preview.accountingPercent}
              initialRatios={preview.accountingRatios}
              collectedRevenue={preview.totalCollectedRevenue}
              waivedRevenue={preview.totalWaivedRevenue}
              computing={computing}
              onCancel={() => setConfigModalOpen(false)}
              onConfirm={(percent, ratios) =>
                handleComputeWithConfig({ accountingPercent: percent, accountingRatios: ratios })
              }
            />
          )}

          {/* ── BẢNG NHÂN VIÊN ─────────────────────────────────────────── */}
          <div className="px-5 pb-5">
            {items.length === 0 ? (
              <p className="text-center text-sm text-muted py-8">
                Bộ phận chưa có nhân viên được tính hoa hồng
              </p>
            ) : (
              <div className="rounded-xl border border-hairline overflow-hidden">
                <Table>
                  <Thead>
                    <Tr className="bg-canvas text-muted">
                      <Th>Nhân viên</Th>
                      {/* (10/2026) SALES: bỏ Chức vụ, thêm Tỷ lệ KPI + Tỷ lệ doanh thu */}
                      {!isSales && <Th>Chức vụ</Th>}
                      {isSales && <Th>Tỷ lệ KPI</Th>}
                      {isSales && <Th>Tỷ lệ doanh thu</Th>}
                      {/* (10/2026) Gộp 2 cột DT thường + Hold thành 1 cột, 2 dòng per row */}
                      {isSales && (
                        <Th right>
                          <div>Doanh thu cá nhân</div>
                          <div className="font-normal opacity-80">tháng {monthLabel}</div>
                        </Th>
                      )}
                      {isSales && <Th right>Doanh thu tính HH</Th>}
                      <Th right>Thưởng doanh thu</Th>
                    </Tr>
                  </Thead>
                  <tbody>
                    {(() => {
                      // Tính tổng doanh thu tháng của phòng để làm mẫu số cho "Tỷ lệ doanh thu"
                      const deptTotal = isSales
                        ? items.reduce((s, it) => s + Number(it.totalMonthOrderRevenue || 0), 0)
                        : 0;
                      const colCount = isSales ? 6 : 3;

                      // (10/2026) Chia nhân viên chính (phòng) vs hỗ trợ (phòng khác)
                      //   • SALES: NV phòng Kinh doanh = main, các NV ngoài phòng có đơn = support
                      //   • ACCOUNTING: 1 nhóm duy nhất (không có hỗ trợ)
                      const mains    = items.filter(it => !isSupportForDept(department, it.roleLabel));
                      const supports = items.filter(it =>  isSupportForDept(department, it.roleLabel));

                      const sumBonus = (list) => list.reduce(
                        (s, it) => s + Number(it.bonusAmount || 0), 0);

                      const renderRow = (it) => {
                        const v2row = (salesV2Config?.rows || []).find(r => r.userId === it.userId);
                        const revRatio = deptTotal > 0
                          ? Math.min(100, Math.max(0, Number(it.totalMonthOrderRevenue || 0) / deptTotal * 100))
                          : 0;
                        return (
                          <Tr
                            key={it.userId}
                            className="hover:!bg-gold/12 hover:[&_*]:font-bold transition-colors">
                            <Td>
                              <div className="font-medium text-ink">{it.userFullName}</div>
                              <div className="text-[10px] text-muted">{it.roleLabel || '—'}</div>
                              {!isSales && it.ratioPercent != null && (
                                <div className="text-[10px] text-muted">
                                  Tỉ lệ: {Number(it.ratioPercent)}%
                                </div>
                              )}
                            </Td>
                            {!isSales && (
                              <Td className="text-muted">
                                {it.roleLabel || '—'}
                              </Td>
                            )}
                            {isSales && (
                              <Td>
                                <KpiProgress row={v2row} />
                              </Td>
                            )}
                            {isSales && (
                              <Td>
                                <RevenueRatioProgress pct={revRatio} />
                              </Td>
                            )}
                            {isSales && (
                              <Td right className="tabular-nums">
                                <div className="text-ink">{fmtMoney(it.totalMonthOrderRevenue)}</div>
                                <div className={Number(it.totalHoldRevenue || 0) > 0
                                  ? 'text-amber-700 dark:text-amber-300 font-semibold text-[11px] mt-0.5'
                                  : 'text-muted text-[11px] mt-0.5'}>
                                  Hold: {fmtMoney(it.totalHoldRevenue)}
                                </div>
                              </Td>
                            )}
                            {isSales && (
                              <Td right className="text-ink tabular-nums">
                                {fmtMoney(it.totalCollectedRevenue)}
                                {it.transactionCount > 0 && (
                                  <div className="text-[10px] text-muted">
                                    ({it.transactionCount} phiếu)
                                  </div>
                                )}
                              </Td>
                            )}
                            <Td right className="tabular-nums">
                              {it.bonusAmount == null ? (
                                <span className="text-faint">—</span>
                              ) : (
                                <>
                                  <div className="font-bold text-emerald-700 dark:text-emerald-300">
                                    {fmtMoney(it.bonusAmount)}
                                  </div>
                                  {isSales && v2row && (
                                    <div className="text-[10px] text-muted mt-0.5">
                                      {Number(v2row.stepUnitPrice || 0).toLocaleString('vi-VN')}
                                      <span className="opacity-50">/</span>
                                      {Number(v2row.remainderBonus || 0).toLocaleString('vi-VN')}
                                    </div>
                                  )}
                                </>
                              )}
                            </Td>
                          </Tr>
                        );
                      };

                      // Dòng tổng cho 1 nhóm (main hoặc support). Dùng cùng class
                      // bg-emerald để nhất quán với màu Thưởng doanh thu.
                      const sectionDivider = (label) => (
                        <tr className="bg-canvas/60 border-t-2 border-hairline-2">
                          <td colSpan={colCount}
                              className="px-4 py-1.5 text-[10px] font-bold uppercase
                                         tracking-wider text-muted">
                            {label}
                          </td>
                        </tr>
                      );
                      const subtotalRow = (key, label, list) => (
                        <tr key={key} className="bg-emerald-50/40 dark:bg-emerald-500/5">
                          <td colSpan={colCount - 1}
                              className="px-4 py-2 text-right text-[11px] font-bold
                                         uppercase tracking-wider text-emerald-700
                                         dark:text-emerald-300">
                            {label} ({list.length} người):
                          </td>
                          <td className="px-4 py-2 text-right tabular-nums
                                         font-bold text-emerald-700 dark:text-emerald-300">
                            {fmtMoney(sumBonus(list))}
                          </td>
                        </tr>
                      );

                      if (!isSales) {
                        // ACCOUNTING: 1 bảng, 1 footer tổng (bỏ card "Tổng pool đã chia" ngoài)
                        return (
                          <>
                            {mains.map(renderRow)}
                            {subtotalRow('acct-total', 'Tổng tiền thưởng', mains)}
                          </>
                        );
                      }

                      // SALES: Nhân viên phòng → divider → Nhân viên hỗ trợ → tổng
                      return (
                        <>
                          {mains.length > 0 && sectionDivider(
                            `Nhân viên phòng Kinh doanh (${mains.length})`,
                          )}
                          {mains.map(renderRow)}
                          {mains.length > 0 && subtotalRow(
                            'main-total', 'Tổng thưởng NV Kinh doanh', mains,
                          )}

                          {supports.length > 0 && (
                            <>
                              {sectionDivider(
                                `Nhân viên hỗ trợ bán hàng (${supports.length})`,
                              )}
                              {supports.map(renderRow)}
                              {subtotalRow(
                                'support-total', 'Tổng thưởng NV hỗ trợ', supports,
                              )}
                            </>
                          )}
                        </>
                      );
                    })()}
                  </tbody>
                </Table>
              </div>
            )}

            {/* (10/2026) ACCOUNTING: bỏ card "Tổng pool" bên ngoài — đã có
                dòng tổng ngay trong footer bảng. SALES: giữ card nhưng đổi
                label thành "Tổng thưởng:" (số này gồm cả NV phòng + NV hỗ trợ). */}
            {anyComputed && preview.totalBonusPool != null && isSales && (
              <div className="mt-3 space-y-2">
                <div className="flex items-center justify-between gap-3 flex-wrap
                  px-4 py-2.5 rounded-xl bg-emerald-50/60 dark:bg-emerald-500/5
                  border border-emerald-200 dark:border-emerald-500/20">
                  <div className="flex items-center gap-2 text-xs text-emerald-800 dark:text-emerald-200">
                    <Gift size={13} />
                    <span>Tổng thưởng:</span>
                    <strong className="tabular-nums">{fmtMoney(preview.totalBonusPool)}</strong>
                  </div>
                  {preview.computedAt && (
                    <span className="text-[11px] text-emerald-700 dark:text-emerald-300">
                      Tính lúc {formatDateTime(preview.computedAt)}
                      {preview.computedByName ? ` · ${preview.computedByName}` : ''}
                    </span>
                  )}
                </div>
                {Number(preview.undistributedAmount || 0) > 0 && (
                  <div className="flex items-center gap-2 text-xs text-amber-800 dark:text-amber-200
                    px-4 py-2 rounded-xl bg-amber-50/60 dark:bg-amber-500/5
                    border border-amber-200 dark:border-amber-500/20">
                    <AlertCircle size={13} />
                    <span>
                      {isSales
                        ? 'Doanh thu không đủ mốc nào (bỏ):'
                        : 'Pool còn dư (không chia cho ai):'}
                    </span>
                    <strong className="tabular-nums">{fmtMoney(preview.undistributedAmount)}</strong>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </SectionCard>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// TASK 2 (10/2026) — MODAL CẤU HÌNH HOA HỒNG
// ══════════════════════════════════════════════════════════════════════════════

/** Hiển thị compact các mốc đã dùng (SALES). */
function SalesTiersPreview({ tiers }) {
  const sorted = [...tiers].sort((a,b) => Number(b.threshold) - Number(a.threshold));
  return (
    <div className="flex flex-wrap gap-1.5">
      {sorted.map((t,i) => (
        <span key={i} className="inline-flex items-center gap-1 text-[11px] font-semibold
          px-2 py-0.5 rounded-md bg-purple-50 dark:bg-purple-500/10
          text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-500/20
          tabular-nums">
          Mốc {Number(t.threshold).toLocaleString('vi-VN')}đ → {Number(t.unitPrice).toLocaleString('vi-VN')}đ
        </span>
      ))}
    </div>
  );
}

/** Debounced numeric input (400ms format). */
function NumericInput({ value, onChange, placeholder, disabled, className = '', suffix }) {
  const [disp, setDisp] = useState(
    value == null || value === '' ? '' : Number(value).toLocaleString('vi-VN'));

  // Khi value từ parent đổi (vd reset) đồng bộ lại disp.
  useEffect(() => {
    const next = value == null || value === '' ? '' : Number(value).toLocaleString('vi-VN');
    setDisp(next);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  // Debounce format 400ms sau khi gõ xong (chỉ khi disp khác format(value))
  useEffect(() => {
    const t = setTimeout(() => {
      if (!disp) return;
      const digits = disp.replace(/[^\d]/g, '');
      const formatted = digits ? Number(digits).toLocaleString('vi-VN') : '';
      if (formatted !== disp) setDisp(formatted);
    }, 400);
    return () => clearTimeout(t);
  }, [disp]);

  const handle = (e) => {
    const digits = String(e.target.value).replace(/[^\d]/g, '');
    setDisp(digits);                          // show raw ngay
    onChange?.(digits ? Number(digits) : null);
  };

  return (
    <div className="relative">
      <input
        type="text" inputMode="numeric"
        value={disp} onChange={handle}
        placeholder={placeholder} disabled={disabled}
        className={`w-full px-3 py-2 rounded-lg border border-hairline-2 bg-surface
          text-ink text-sm focus:outline-none focus:border-gold disabled:opacity-50
          tabular-nums ${suffix ? 'pr-8' : ''} ${className}`}
      />
      {suffix && (
        <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[11px] text-muted pointer-events-none">
          {suffix}
        </span>
      )}
    </div>
  );
}

/** Debounced % input (0..100, hỗ trợ số thập phân). */
function PercentInput({ value, onChange, disabled, placeholder = '0', className = '' }) {
  const [disp, setDisp] = useState(value == null || value === '' ? '' : String(value));
  useEffect(() => {
    setDisp(value == null || value === '' ? '' : String(value));
  }, [value]);
  const handle = (e) => {
    // Chấp nhận "15" / "15.5" / "15,5" — bỏ ký tự khác số và dấu .
    let s = String(e.target.value).replace(/,/g, '.').replace(/[^\d.]/g, '');
    // Chỉ giữ 1 dấu .
    const parts = s.split('.');
    if (parts.length > 2) s = parts[0] + '.' + parts.slice(1).join('');
    setDisp(s);
    const n = s === '' || s === '.' ? null : Number(s);
    onChange?.(Number.isFinite(n) ? n : null);
  };
  return (
    <div className="relative">
      <input
        type="text" inputMode="decimal"
        value={disp} onChange={handle}
        placeholder={placeholder} disabled={disabled}
        className={`w-full px-3 py-2 pr-7 rounded-lg border border-hairline-2 bg-surface
          text-ink text-sm focus:outline-none focus:border-gold disabled:opacity-50
          tabular-nums ${className}`}
      />
      <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[11px] text-muted pointer-events-none">%</span>
    </div>
  );
}

/**
 * Modal nhập các MỐC THƯỞNG cho KINH DOANH.
 *
 * Flow:
 *   - Preload tiers lần tính gần nhất (nếu có) hoặc 1 dòng trống.
 *   - User thêm/xoá/sửa mốc (threshold + unitPrice).
 *   - Preview: nếu nhập đủ cả 2 → hiển thị bên dưới cách tính 1 ví dụ bằng
 *     tổng doanh thu thực thu + waived (để OWNER đối chiếu).
 *   - Submit: gửi list cho BE (BE tự sort DESC).
 */
function SalesTierModal({
  month, year, initialTiers, collectedRevenue, waivedRevenue,
  computing, onCancel, onConfirm,
}) {
  const monthLabel = `${String(month).padStart(2,'0')}/${year}`;
  const [tiers, setTiers] = useState(() => {
    if (initialTiers && initialTiers.length > 0) {
      return initialTiers.map(t => ({ threshold: Number(t.threshold), unitPrice: Number(t.unitPrice) }));
    }
    return [{ threshold: null, unitPrice: null }];
  });

  const addTier    = () => setTiers(t => [...t, { threshold: null, unitPrice: null }]);
  const removeTier = (i) => setTiers(t => t.filter((_, idx) => idx !== i));
  const updateTier = (i, k, v) => setTiers(t => t.map((row, idx) =>
    idx === i ? { ...row, [k]: v } : row));

  const validTiers = tiers.filter(t => Number(t.threshold) > 0 && Number(t.unitPrice) > 0);
  const invalidCount = tiers.length - validTiers.length;

  // Tính preview trên 1 seller với tổng doanh thu phòng (chỉ để minh hoạ công thức)
  const previewRevenue = Number(collectedRevenue || 0) + Number(waivedRevenue || 0);
  const previewCalc = (() => {
    if (previewRevenue <= 0 || validTiers.length === 0) return null;
    const sorted = [...validTiers].sort((a,b) => Number(b.threshold) - Number(a.threshold));
    let remaining = previewRevenue;
    let raw = 0;
    const breakdown = [];
    for (const t of sorted) {
      const k = Math.floor(remaining / Number(t.threshold));
      if (k > 0) {
        const sub = k * Number(t.unitPrice);
        raw += sub;
        remaining -= k * Number(t.threshold);
        breakdown.push({ ...t, count: k, subtotal: sub });
      }
    }
    const rounded = raw === 0 ? 0 : Math.ceil(raw / 5000) * 5000;
    return { raw, rounded, remaining, breakdown };
  })();

  const canSubmit = validTiers.length > 0 && !computing;

  return (
    <ModalShell onCancel={onCancel} widthClass="max-w-2xl">
      <div className="p-5 space-y-4">
        <div className="flex items-center gap-3">
          <span className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-500/10
            flex items-center justify-center">
            <TrendingUp size={18} className="text-purple-500" />
          </span>
          <div>
            <h3 className="text-base font-bold text-ink">
              Cấu hình mốc thưởng Kinh doanh — {monthLabel}
            </h3>
            <p className="text-[11px] text-muted">
              Mỗi seller: mốc cao tính trước, phần dư xuống mốc thấp hơn.
              Phần không đủ mốc nào → bỏ. Số cuối cùng làm tròn LÊN 5.000đ.
              Doanh thu dùng để tính là <strong>EX-VAT</strong> (đã trừ VAT theo tỷ trọng).
            </p>
          </div>
        </div>

        <div className="rounded-xl border border-hairline-2 bg-canvas p-4 space-y-2.5">
          <div className="grid grid-cols-12 gap-2 text-[10px] font-bold text-muted uppercase tracking-wider">
            <div className="col-span-6">Mốc doanh thu (≥)</div>
            <div className="col-span-5">Đơn giá thưởng mỗi mốc</div>
            <div className="col-span-1"></div>
          </div>
          {tiers.map((t, i) => (
            <div key={i} className="grid grid-cols-12 gap-2 items-center">
              <div className="col-span-6">
                <NumericInput value={t.threshold}
                  onChange={(v) => updateTier(i, 'threshold', v)}
                  placeholder="VD: 200.000.000"
                  disabled={computing}
                  suffix="đ" />
              </div>
              <div className="col-span-5">
                <NumericInput value={t.unitPrice}
                  onChange={(v) => updateTier(i, 'unitPrice', v)}
                  placeholder="VD: 400.000"
                  disabled={computing}
                  suffix="đ" />
              </div>
              <div className="col-span-1 flex justify-end">
                <button onClick={() => removeTier(i)} disabled={computing || tiers.length === 1}
                  className="w-8 h-8 rounded-lg hover:bg-red-50 dark:hover:bg-red-500/10
                    text-red-500 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center">
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
          <SecondaryButton onClick={addTier} disabled={computing} size="sm" className="w-full">
            <Plus size={13} /> Thêm mốc
          </SecondaryButton>
          {invalidCount > 0 && (
            <p className="text-[11px] text-amber-600 dark:text-amber-400">
              Có {invalidCount} mốc chưa đủ dữ liệu — sẽ bỏ qua khi tính.
            </p>
          )}
        </div>

        {/* Preview tính 1 ví dụ với tổng doanh thu phòng */}
        {previewCalc && (
          <div className="rounded-xl bg-emerald-50/60 dark:bg-emerald-500/5
            border border-emerald-200 dark:border-emerald-500/20 p-3 text-[12px] space-y-1">
            <div className="font-semibold text-emerald-800 dark:text-emerald-200">
              Preview áp lên tổng doanh thu tháng ({Number(previewRevenue).toLocaleString('vi-VN')}đ):
            </div>
            {previewCalc.breakdown.map((b, i) => (
              <div key={i} className="text-emerald-700 dark:text-emerald-300 tabular-nums pl-3">
                • {b.count} × mốc {Number(b.threshold).toLocaleString('vi-VN')}đ
                  × {Number(b.unitPrice).toLocaleString('vi-VN')}đ
                  = {b.subtotal.toLocaleString('vi-VN')}đ
              </div>
            ))}
            <div className="pl-3 text-emerald-700 dark:text-emerald-300 tabular-nums">
              → Raw: <strong>{previewCalc.raw.toLocaleString('vi-VN')}đ</strong>
              {' '}· Làm tròn LÊN 5.000: <strong>{previewCalc.rounded.toLocaleString('vi-VN')}đ</strong>
              {previewCalc.remaining > 0 && (
                <> · Còn dư (bỏ): <strong className="text-amber-700 dark:text-amber-300">{previewCalc.remaining.toLocaleString('vi-VN')}đ</strong></>
              )}
            </div>
            <p className="text-[10px] text-emerald-700/70 dark:text-emerald-300/70 italic pt-1">
              * Chỉ là ví dụ áp lên tổng doanh thu phòng. Khi tính thật, mỗi seller
              được áp riêng theo doanh thu của chính họ.
            </p>
          </div>
        )}
      </div>

      <div className="flex gap-2 px-5 pb-5 pt-3 border-t border-hairline">
        <SecondaryButton onClick={onCancel} disabled={computing} className="flex-1">
          Hủy
        </SecondaryButton>
        <PrimaryButton
          disabled={!canSubmit}
          loading={computing}
          onClick={() => onConfirm(validTiers)}
          className="flex-1">
          <Calculator size={14} /> Xác nhận tính
        </PrimaryButton>
      </div>
    </ModalShell>
  );
}

/**
 * Modal nhập % phòng + tỉ lệ từng nhân viên kế toán.
 *
 * Chốt:
 *   - Pool = (collected + waived) × accountingPercent / 100
 *   - Mỗi NV: pool × ratio_i / 100 → ceil 5.000
 *   - Σ ratio = 100 → confirm bình thường.
 *   - Σ ratio < 100 → warning (phần dư bỏ) nhưng vẫn cho confirm.
 *   - Σ ratio > 100 → chặn confirm.
 */
function AccountingRatioModal({
  month, year, items, initialPercent, initialRatios,
  collectedRevenue, waivedRevenue,
  computing, onCancel, onConfirm,
}) {
  const monthLabel = `${String(month).padStart(2,'0')}/${year}`;
  const [percent, setPercent] = useState(
    initialPercent != null ? Number(initialPercent) : null);
  const [ratios, setRatios] = useState(() => {
    const byUser = {};
    (initialRatios || []).forEach(r => { byUser[r.userId] = Number(r.ratio); });
    return items.map(it => ({
      userId: it.userId,
      userFullName: it.userFullName,
      roleLabel: it.roleLabel,
      ratio: byUser[it.userId] != null ? byUser[it.userId] : null,
    }));
  });

  const updateRatio = (userId, v) =>
    setRatios(rs => rs.map(r => r.userId === userId ? { ...r, ratio: v } : r));

  const totalRatio = ratios.reduce((s, r) => s + (Number(r.ratio) || 0), 0);
  const totalRatioRounded = Math.round(totalRatio * 100) / 100;
  const over100 = totalRatioRounded > 100 + 1e-9;
  const under100 = totalRatioRounded < 100 - 1e-9;
  const [confirmWarn, setConfirmWarn] = useState(false);

  const previewRevenue = Number(collectedRevenue || 0) + Number(waivedRevenue || 0);
  const poolRaw = (previewRevenue > 0 && Number(percent) > 0)
    ? previewRevenue * Number(percent) / 100
    : 0;
  const undistributed = poolRaw * Math.max(0, 100 - totalRatioRounded) / 100;

  const canSubmit = !computing && Number(percent) > 0 && !over100
    && ratios.some(r => Number(r.ratio) > 0);

  const handleConfirm = () => {
    if (over100) return;
    if (under100 && !confirmWarn) {
      setConfirmWarn(true);
      return;
    }
    const payload = ratios
      .filter(r => Number(r.ratio) > 0)
      .map(r => ({ userId: r.userId, ratio: Number(r.ratio) }));
    onConfirm(Number(percent), payload);
  };

  return (
    <ModalShell onCancel={onCancel} widthClass="max-w-2xl">
      <div className="p-5 space-y-4">
        <div className="flex items-center gap-3">
          <span className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-500/10
            flex items-center justify-center">
            <Percent size={18} className="text-purple-500" />
          </span>
          <div>
            <h3 className="text-base font-bold text-ink">
              Cấu hình hoa hồng Kế toán — {monthLabel}
            </h3>
            <p className="text-[11px] text-muted">
              Pool = doanh thu thực thu <strong>EX-VAT</strong> × % phòng. Mỗi người nhận:
              pool × tỉ lệ ÷ 100, làm tròn LÊN 5.000đ. Σ tỉ lệ phải ≤ 100%; phần dư không chia cho ai.
            </p>
          </div>
        </div>

        {/* % phòng */}
        <div className="rounded-xl border border-hairline-2 bg-canvas p-4">
          <label className="text-[11px] font-bold text-muted uppercase tracking-wider
            flex items-center gap-1 mb-1.5">
            <Percent size={11} /> % hoa hồng của cả phòng (tính trên doanh thu thực thu)
          </label>
          <div className="w-40">
            <PercentInput value={percent} onChange={setPercent} disabled={computing}
              placeholder="VD: 15" />
          </div>
          {previewRevenue > 0 && Number(percent) > 0 && (
            <p className="text-[11px] text-muted mt-2 tabular-nums">
              Pool phòng = {Number(previewRevenue).toLocaleString('vi-VN')}đ × {Number(percent)}% ={' '}
              <strong className="text-ink">{Math.round(poolRaw).toLocaleString('vi-VN')}đ</strong>
            </p>
          )}
        </div>

        {/* Ratios per employee */}
        <div className="rounded-xl border border-hairline-2 bg-canvas overflow-hidden">
          <div className="px-4 py-2.5 bg-canvas border-b border-hairline flex items-center justify-between">
            <span className="text-[11px] font-bold text-muted uppercase tracking-wider">
              Tỉ lệ chia cho từng kế toán viên
            </span>
            <span className={`text-xs font-bold tabular-nums ${
              over100 ? 'text-red-600 dark:text-red-400'
                : under100 ? 'text-amber-600 dark:text-amber-400'
                : 'text-emerald-600 dark:text-emerald-400'
            }`}>
              Σ = {totalRatioRounded}%
            </span>
          </div>
          <div className="divide-y divide-hairline">
            {ratios.map(r => {
              const share = poolRaw * (Number(r.ratio) || 0) / 100;
              const shareRounded = share === 0 ? 0 : Math.ceil(share / 5000) * 5000;
              return (
                <div key={r.userId} className="px-4 py-2.5 grid grid-cols-12 gap-2 items-center">
                  <div className="col-span-6 min-w-0">
                    <div className="font-medium text-ink text-sm truncate">{r.userFullName}</div>
                    <div className="text-[11px] text-muted truncate">{r.roleLabel || '—'}</div>
                  </div>
                  <div className="col-span-3">
                    <PercentInput value={r.ratio}
                      onChange={(v) => updateRatio(r.userId, v)}
                      disabled={computing} />
                  </div>
                  <div className="col-span-3 text-right tabular-nums text-xs">
                    {share > 0 ? (
                      <>
                        <div className="text-emerald-700 dark:text-emerald-300 font-semibold">
                          {shareRounded.toLocaleString('vi-VN')}đ
                        </div>
                        <div className="text-[10px] text-muted">
                          raw {Math.round(share).toLocaleString('vi-VN')}đ
                        </div>
                      </>
                    ) : (
                      <span className="text-faint">—</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {over100 && (
          <div className="flex items-center gap-2 text-xs text-red-700 dark:text-red-300
            px-3 py-2 rounded-lg bg-red-50/60 dark:bg-red-500/5
            border border-red-200 dark:border-red-500/20">
            <AlertCircle size={13} />
            Tổng tỉ lệ vượt 100% — vui lòng chỉnh lại trước khi tính.
          </div>
        )}
        {!over100 && under100 && (
          <div className={`flex items-center gap-2 text-xs px-3 py-2 rounded-lg ${
            confirmWarn
              ? 'text-red-700 dark:text-red-300 bg-red-50/60 dark:bg-red-500/5 border border-red-200 dark:border-red-500/20'
              : 'text-amber-700 dark:text-amber-300 bg-amber-50/60 dark:bg-amber-500/5 border border-amber-200 dark:border-amber-500/20'
          }`}>
            <AlertCircle size={13} />
            {confirmWarn
              ? <>Số dư <strong className="tabular-nums">{Math.round(undistributed).toLocaleString('vi-VN')}đ</strong> sẽ KHÔNG chia cho ai. Bấm "Xác nhận tính" lần nữa để tiếp tục.</>
              : <>Tổng tỉ lệ chỉ {totalRatioRounded}% — phần dư ({Math.round(undistributed).toLocaleString('vi-VN')}đ) sẽ bỏ. Bấm "Xác nhận tính" để tiếp tục.</>}
          </div>
        )}
      </div>

      <div className="flex gap-2 px-5 pb-5 pt-3 border-t border-hairline">
        <SecondaryButton onClick={onCancel} disabled={computing} className="flex-1">
          Hủy
        </SecondaryButton>
        <PrimaryButton
          disabled={!canSubmit}
          loading={computing}
          onClick={handleConfirm}
          className="flex-1">
          <Calculator size={14} /> Xác nhận tính
        </PrimaryButton>
      </div>
    </ModalShell>
  );
}

/**
 * Overlay shell dùng chung cho SalesTierModal / AccountingRatioModal.
 * Lý do viết riêng (thay vì component Modal có sẵn trong /ui): 2 modal này
 * đã có header + footer custom bên trong children → component Modal với props
 * title + footer sẽ chồng chéo.
 */
/**
 * (10/2026) Progress bar % đạt target cá nhân cho cột Tỷ lệ KPI (admin SALES).
 *   • SELLER / SUPER_SELLER có personalTarget > 0 → progress bar + %
 *       ≥ 90% xanh lá · 50-90% xanh dương · < 50% vàng cam
 *       Width tối đa 100% (ngay cả khi >100%). Số % lấy phần nguyên.
 *   • Khác → label "Không tính Target cá nhân"
 */
function KpiProgress({ row }) {
  if (!row) {
    return <span className="text-[11px] text-muted italic">—</span>;
  }
  if (!row.personalTarget || row.personalTarget <= 0) {
    return <span className="text-[11px] text-amber-600 dark:text-amber-400">Chưa set target</span>;
  }
  const raw = Math.max(0, row.achievedPercent ?? 0);
  // Truncate 2 decimals (không làm tròn lên)
  const pct = Math.floor(raw * 100) / 100;
  const widthPct = Math.min(100, pct);
  const color = pct >= 90
    ? 'bg-lime-500'
    : pct >= 50 ? 'bg-sky-500' : 'bg-orange-400';
  const textColor = pct >= 90
    ? 'text-lime-700 dark:text-lime-200'
    : pct >= 50 ? 'text-sky-700 dark:text-sky-200' : 'text-orange-700 dark:text-orange-200';
  return (
    <div className="min-w-[130px]">
      <div className="w-full h-4 rounded-full bg-canvas border border-hairline overflow-hidden relative">
        <div className={`h-full ${color} transition-all`} style={{ width: `${widthPct}%` }} />
        <span className={`absolute inset-0 flex items-center justify-center text-[10px] font-bold ${textColor}`}>
          {pct.toFixed(2)}%
        </span>
      </div>
      <div className="text-[10px] text-muted mt-0.5 tabular-nums">
        Target: {Number(row.personalTarget).toLocaleString('vi-VN')}đ
      </div>
    </div>
  );
}

/**
 * (10/2026) Tỷ lệ doanh thu cá nhân / tổng doanh thu phòng (0-100, 2 chữ số sau dấu phẩy).
 *   0-20% cam · 20-40% vàng · 40-60% xanh dương · >60% xanh lá
 */
function RevenueRatioProgress({ pct }) {
  const raw = Math.max(0, Math.min(100, Number(pct ?? 0)));
  // Truncate 2 decimals (không làm tròn lên)
  const p = Math.floor(raw * 100) / 100;
  const color = p > 60
    ? 'bg-lime-500'
    : p >= 40 ? 'bg-sky-500'
    : p >= 20 ? 'bg-yellow-400'
    : 'bg-orange-400';
  const textColor = p > 60
    ? 'text-lime-700 dark:text-lime-200'
    : p >= 40 ? 'text-sky-700 dark:text-sky-200'
    : p >= 20 ? 'text-yellow-700 dark:text-yellow-200'
    : 'text-orange-700 dark:text-orange-200';
  return (
    <div className="min-w-[110px]">
      <div className="w-full h-4 rounded-full bg-canvas border border-hairline overflow-hidden relative">
        <div className={`h-full ${color} transition-all`} style={{ width: `${p}%` }} />
        <span className={`absolute inset-0 flex items-center justify-center text-[10px] font-bold ${textColor}`}>
          {p.toFixed(2)}%
        </span>
      </div>
    </div>
  );
}

function ModalShell({ onCancel, widthClass = 'max-w-2xl', children }) {
  useEffect(() => {
    const fn = (e) => { if (e.key === 'Escape') onCancel?.(); };
    document.addEventListener('keydown', fn);
    return () => document.removeEventListener('keydown', fn);
  }, [onCancel]);

  return (
    <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onCancel} />
      <div className={`relative bg-surface w-full ${widthClass}
        rounded-t-3xl sm:rounded-2xl shadow-2xl max-h-[92vh] sm:max-h-[88vh]
        flex flex-col overflow-y-auto animate-[slideUp_.18s_ease-out]`}>
        {children}
      </div>
    </div>
  );
}

function BonusStatBox({ label, hint, value, footer, tone = 'default' }) {
  const toneCls = {
    default: 'bg-canvas border-hairline-2 text-ink',
    emerald: 'bg-emerald-50/60 dark:bg-emerald-500/5 border-emerald-200 dark:border-emerald-500/20 text-emerald-800 dark:text-emerald-200',
    amber: 'bg-amber-50/60 dark:bg-amber-500/5 border-amber-200 dark:border-amber-500/20 text-amber-800 dark:text-amber-200',
  }[tone];
  return (
    <div className={`rounded-xl border p-3 ${toneCls}`}>
      <p className="text-[10px] font-bold uppercase tracking-wider opacity-80">{label}</p>
      <p className="text-base font-bold mt-1 tabular-nums">{value}</p>
      {hint && <p className="text-[10px] opacity-70 mt-0.5">{hint}</p>}
      {footer && (
        <p className="text-[11px] mt-2 pt-2 border-t border-current/15 opacity-85">
          {footer}
        </p>
      )}
    </div>
  );
}

export default function AttendanceSheetsPage() {
  const navigate = useNavigate();
  const [periods, setPeriods] = useState([]);
  const [selected, setSelected] = useState(null);
  const [department, setDepartment] = useState('FACTORY');
  const [statuses, setStatuses] = useState([]);           // trạng thái CẢ 5 bộ phận
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(null);                 // 'attendance' | 'exception' | 'leave'
  const [deleting, setDeleting] = useState(null);
  const [finalizing, setFinalizing] = useState(false);
  const [finalizingKpi, setFinalizingKpi] = useState(false);
  const [result, setResult] = useState(null);
  const [resultTitle, setResultTitle] = useState('');
  const [recomputing, setRecomputing] = useState(false);
  const [payroll, setPayroll] = useState(null);
  const [loadingPayroll, setLoadingPayroll] = useState(false);
  // Cờ nút "Tính lương" đang chạy — dùng chung cho Xưởng và Tài xế.
  const [computingPreview, setComputingPreview] = useState(false);
  const [adjustments, setAdjustments] = useState(null);   // { bonus, allowance }
  // Mỗi khoản thưởng là một nhãn riêng, tải lên từ một file riêng.
  const [bonusBatches, setBonusBatches] = useState([]);   // [{ label, employeeCount, totalAmount }]
  const [deletingLabel, setDeletingLabel] = useState(null);
  // Preview modal state — hiển thị nội dung 1 khoản đã import cho OWNER xem lại.
  const [preview, setPreview] = useState(null);       // PreviewResult
  const [previewLoading, setPreviewLoading] = useState(false);
  // Mức thưởng cố định cho MỘT bảo vệ xưởng, nhập lúc bấm tính KPI.
  // Chuỗi rỗng = chưa nhập → gửi null để backend giữ nguyên mức cũ của tháng.
  const [securityRate, setSecurityRate] = useState('');
  const [membersOpen, setMembersOpen] = useState(false);
  const [adjResult, setAdjResult] = useState(null);
  const [adjResultTitle, setAdjResultTitle] = useState('');
  const [kpi, setKpi] = useState(null);
  // ── Export file lương tổng hợp ──────────────────────────────────────────────
  const [exportModalOpen, setExportModalOpen] = useState(false);
  // Phase 3: MANAGEMENT đã gỡ khỏi hệ thống lương.
  const [exportDepts, setExportDepts] = useState({
    ACCOUNTING: true, FACTORY: true, SALES: true, WAREHOUSE: true, DRIVER: true,
  });
  const [exportType, setExportType] = useState('SALARY_ONLY');
  const [exporting, setExporting] = useState(false);
  // Xuất file chi lương theo mẫu ngân hàng — riêng loading vì có thể chạy độc lập.
  const [exportingBank, setExportingBank] = useState(false);
  const toast = useToast();

  const status = statuses.find(s => s.department === department) || null;

  // ── Nạp danh sách tháng ───────────────────────────────────────────────────
  //
  // FIX (10/2026): mặc định chọn tháng gần nhất ĐÃ TÍNH LƯƠNG (CALCULATED
  // hoặc PUBLISHED), KHÔNG phải tháng hiện tại. Tháng hiện tại thường chưa
  // tính lương nên khi OWNER mở trang vào ngày 3/10 sẽ thấy bảng rỗng, phải
  // tự click về T9 — tốn thêm 1 bước.
  //
  // Chiến lược:
  //   1. Load danh sách periods (arr[0] = tháng hiện tại, giảm dần).
  //   2. Gọi parallel companyPayrollApi.status cho MỖI period (≤12 call,
  //      load được nhanh).
  //   3. Pick period đầu tiên theo thứ tự arr có calcStatus = CALCULATED
  //      hoặc PUBLISHED.
  //   4. Nếu không có period nào tính rồi (công ty mới) → fallback arr[0].
  useEffect(() => {
    (async () => {
      try {
        const list = await factoryPayrollApi.uploadablePeriods('FACTORY');
        const arr = Array.isArray(list) ? list : [];
        setPeriods(arr);
        if (!arr.length) return;

        // Fallback = tháng mới nhất, dùng nếu không có tháng nào tính xong.
        let defaultP = arr[0];
        try {
          const statuses = await Promise.all(
            arr.map(p => companyPayrollApi.status(p.month, p.year)
              .then(s => s?.data || s)
              .catch(() => null))
          );
          const idx = statuses.findIndex(
            s => s && (s.calcStatus === 'CALCULATED' || s.calcStatus === 'PUBLISHED'));
          if (idx >= 0) defaultP = arr[idx];
        } catch (_) {
          // giữ fallback arr[0] — không chặn mở trang vì không chọn được default
        }
        setSelected(defaultP);
      } catch (e) {
        toast(e?.response?.data?.message || 'Không tải được danh sách tháng', 'error');
      } finally {
        setLoading(false);
      }
    })();
  }, []); // eslint-disable-line

  // ── Nạp trạng thái CẢ 5 bộ phận khi đổi tháng ─────────────────────────────
  const loadStatus = useCallback(async (p) => {
    if (!p) return;
    try {
      const list = await factoryPayrollApi.monthStatusAll(p.month, p.year);
      setStatuses(Array.isArray(list) ? list : []);
    } catch (e) {
      toast(e?.response?.data?.message || 'Không tải được trạng thái tháng', 'error');
    }
  }, []); // eslint-disable-line

  useEffect(() => { loadStatus(selected); }, [selected, loadStatus]);

  // ── Helper: đọc message lỗi từ response blob của các endpoint export ──────
  //
  // Cả 2 endpoint xuất file đều dùng responseType: 'blob' nên khi BE trả về
  // HTTP 4xx/5xx (VD: "chưa tính lương" → 400), body error là 1 Blob JSON.
  // Cần .text() rồi JSON.parse mới lấy được `message`. Trả thêm `isWarning` để
  // chỗ gọi hiển thị toast 'warning' khi tháng chưa tính lương (không phải
  // lỗi hệ thống mà là nhắc user thao tác thiếu).
  const parseExportError = async (e, fallbackMsg) => {
    let msg = fallbackMsg;
    const blob = e?.response?.data;
    if (blob instanceof Blob) {
      try {
        const text = await blob.text();
        const json = JSON.parse(text);
        if (json?.message) msg = json.message;
      } catch { /* giữ fallback */ }
    } else if (e?.response?.data?.message) {
      msg = e.response.data.message;
    }
    // "chưa tính lương" (thiếu batch) + "chưa hỗ trợ xuất thưởng riêng" (phòng
    // không có quỹ thưởng cố định, VD Kho) đều là nhắc thao tác, không phải lỗi
    // hệ thống → toast warning (vàng) thay vì error (đỏ).
    const isWarning = /chưa tính lương|chưa hỗ trợ xuất thưởng/i.test(msg);
    return { msg, isWarning };
  };

  // ── Xuất file lương tổng hợp ────────────────────────────────────────────────
  const handleExportSalary = async () => {
    if (!selected) return;
    setExporting(true);
    try {
      // Lương: xuất TẤT CẢ phòng ban trong 1 file
      // Thưởng: chỉ xuất phòng ban đang chọn
      // Phase 3: MANAGEMENT đã gỡ.
      const depts = exportType === 'SALARY_ONLY'
        ? ['ACCOUNTING', 'SALES', 'FACTORY', 'WAREHOUSE', 'DRIVER']
        : [department];
      await factoryPayrollApi.exportSalaryReport(selected.month, selected.year, depts, exportType);
      toast('Đã xuất file lương thành công', 'success');
      setExportModalOpen(false);
    } catch (e) {
      // BE chặn sớm khi tháng chưa tính lương → HTTP 400, message dạng
      // "Tháng MM/YYYY chưa tính lương…". Toast warning + KHÔNG đóng modal
      // để user thấy rõ vì sao không xuất được.
      const { msg, isWarning } = await parseExportError(e, 'Không xuất được file lương');
      toast(msg, isWarning ? 'warning' : 'error');
    } finally {
      setExporting(false);
    }
  };

  // ── Xuất file chi lương theo mẫu NGÂN HÀNG ───────────────────────────────
  //
  // Khác với "Xuất file lương" (bảng chi tiết nhiều cột, dùng nội bộ), file
  // ngân hàng chỉ có 5 cột và dùng để chuyển khoản hàng loạt. BE tự chọn nhân
  // viên theo quy tắc (xem BankPaymentExportService) nên FE chỉ cần tháng/năm.
  const handleExportBankPayment = async () => {
    if (!selected) return;
    setExportingBank(true);
    try {
      await factoryPayrollApi.exportBankPayment(selected.month, selected.year);
      toast('Đã xuất file chi lương ngân hàng', 'success');
    } catch (e) {
      // Cùng cơ chế như handleExportSalary — nếu tháng chưa tính lương thì
      // BE trả HTTP 400 và FE toast warning.
      const { msg, isWarning } = await parseExportError(e, 'Không xuất được file chi lương ngân hàng');
      toast(msg, isWarning ? 'warning' : 'error');
    } finally {
      setExportingBank(false);
    }
  };

  // ── Số dòng thưởng/phụ cấp đã import + quỹ KPI của kỳ ─────────────────────
  const loadAdjustments = useCallback(async (p, dept) => {
    if (!p) { setAdjustments(null); setBonusBatches([]); return; }
    try {
      setAdjustments(await factoryPayrollApi.adjustmentStatus(p.month, p.year, dept));
    } catch {
      setAdjustments(null);
    }
    try {
      const b = await factoryPayrollApi.bonusBatches(p.month, p.year, dept);
      setBonusBatches(Array.isArray(b) ? b : []);
    } catch {
      setBonusBatches([]);
    }
  }, []);

  const loadKpi = useCallback(async (p, dept) => {
    // Chỉ Xưởng sản xuất mới có quỹ thưởng KPI
    if (!p || dept !== 'FACTORY') { setKpi(null); return; }
    try {
      setKpi(await factoryPayrollApi.kpi(p.month, p.year));
    } catch {
      setKpi(null);
    }
  }, []);

  useEffect(() => { loadAdjustments(selected, department); }, [selected, department, loadAdjustments]);
  useEffect(() => { loadKpi(selected, department); }, [selected, department, loadKpi]);
  // useEffect cho loadBonusSummary nằm bên dưới, sau khi useCallback định nghĩa xong

  // ── Nạp 2 bảng lương — BAO GỒM CẢ CHẾ ĐỘ XEM TRƯỚC ────────────────────────
  //
  // Trước đây chỉ nạp khi đã Hoàn tất. Nay OWNER cần xem trước lương ngay sau
  // khi upload chấm công (Xưởng) hoặc cấu hình giá xăng (Tài xế) để cân đối
  // trước khi công bố. Endpoint `departmentPayroll` vốn không kiểm tra cờ
  // finalized — chỉ đọc dữ liệu hiện có trong DB — nên chạy được cho cả hai
  // trạng thái. Cờ preview ở dưới quyết định hiện banner "Xem trước".
  const loadPayroll = useCallback(async (p, dept) => {
    // Reset ngay khi đổi tháng/tab để không hiển thị nhãn bộ phận CŨ trong lúc
    // chờ fetch (bug: đổi tab Xưởng vẫn thấy "Phiếu lương — Tài xế").
    setPayroll(null);
    if (!p || !dept) return;
    setLoadingPayroll(true);
    try {
      const res = await factoryPayrollApi.departmentPayroll(p.month, p.year, dept);
      // Chỉ nhận kết quả nếu vẫn khớp với bộ phận đang chọn (tránh race khi bấm
      // nhanh giữa các tab).
      if (res?.department === dept || res?.departmentCode === dept) {
        setPayroll(res);
      } else {
        setPayroll(res);   // BE không trả cờ dept: chấp nhận (đã reset đúng thời điểm gọi)
      }
    } catch (e) {
      toast(e?.response?.data?.message || 'Không tải được bảng lương', 'error');
      setPayroll(null);
    } finally {
      setLoadingPayroll(false);
    }
  }, []); // eslint-disable-line

  useEffect(() => {
    // Chỉ auto-nạp bảng lương khi có thể tính được (đã có file với Xưởng /
    // Quản lý cấp cao, hoặc bộ phận không cần file) HOẶC đã Hoàn tất. Xưởng
    // chưa upload thì bảng preview toàn công 0 / lương không có nghĩa —
    // nạp cũng chỉ gây hiểu lầm.
    if (status?.canFinalize || status?.finalized) {
      loadPayroll(selected, department);
    } else {
      setPayroll(null);
    }
  }, [selected, department, status?.finalized, status?.kpiFinalized, status?.canFinalize, loadPayroll]);

  // Nút "Tính lương" trên Xưởng / Tài xế: bấm tay để refresh sau khi thêm
  // thưởng, phụ cấp, cập nhật đơn giá thưởng, v.v. — không phải chờ đổi tab.
  const computePreview = async () => {
    if (!selected) return;
    setComputingPreview(true);
    try {
      await loadPayroll(selected, department);
      toast('Đã tính lại lương xem trước', 'success');
    } finally {
      setComputingPreview(false);
    }
  };

  // ── Hành động ─────────────────────────────────────────────────────────────
  const upload = async (kind, file) => {
    if (!selected) return;
    setBusy(kind);
    try {
      const fn = { attendance: 'uploadSheet', exception: 'uploadExceptions', leave: 'uploadLeaves' }[kind];
      const res = await factoryPayrollApi[fn](file, selected.month, selected.year, department);
      setResult(res);
      setResultTitle({
        attendance: 'Kết quả import bảng chấm công',
        exception: 'Kết quả import lịch nghỉ',
        leave: 'Kết quả import đơn xin nghỉ',
      }[kind]);
      toast(`${status?.departmentLabel} · tháng ${selected.month}/${selected.year}: đã xử lý ${res?.matched ?? 0} dòng`, 'success');
      await loadStatus(selected);
    } catch (e) {
      toast(e?.response?.data?.message || e?.message || 'Lỗi tải file', 'error');
    } finally {
      setBusy(null);
    }
  };

  const remove = async (kind) => {
    if (!selected) return;
    setDeleting(kind);
    try {
      await factoryPayrollApi.deleteFile(kind, selected.month, selected.year, department);
      toast('Đã xoá file. Tải file mới rồi bấm "Hoàn tất" lại để tính theo file mới nhất.', 'success');
      await loadStatus(selected);
    } catch (e) {
      toast(e?.response?.data?.message || 'Lỗi xoá file', 'error');
    } finally {
      setDeleting(null);
    }
  };

  const template = async (kind) => {
    if (!selected) return;
    try {
      await factoryPayrollApi.downloadTemplate(kind, selected.month, selected.year, department);
    } catch {
      toast('Không tải được file mẫu', 'error');
    }
  };

  const uploadAdjustment = async (kind, file) => {
    if (!selected) return;
    setBusy(kind);
    try {
      const fn = kind === 'bonus'
        ? factoryPayrollApi.uploadBonus
        : factoryPayrollApi.uploadAllowance;
      const res = await fn(file, selected.month, selected.year, department);

      const errs = res?.errors || [];
      const warns = res?.warnings || [];

      // Với thưởng, con số đáng chú ý là "bỏ qua vì đã có" — đó là bằng chứng
      // rằng tải lại file cũ không ghi đè tiền của người cũ.
      const skipped = res?.skippedExisting ?? 0;
      toast(
        `Đã thêm ${res?.saved ?? 0} khoản`
        + (skipped ? ` · bỏ qua ${skipped} người đã có` : '')
        + (errs.length ? ` · ${errs.length} dòng lỗi` : ''),
        errs.length ? 'warning' : 'success'
      );
      // LUÔN mở modal kết quả để owner thấy chi tiết đã xử lý ai/không tìm thấy ai.
      setAdjResultTitle(kind === 'bonus' ? 'Kết quả import thưởng' : 'Kết quả import phụ cấp');
      setAdjResult(res);
      await loadAdjustments(selected, department);
    } catch (e) {
      toast(e?.response?.data?.message || 'Không import được file', 'error');
    } finally {
      setBusy(null);
    }
  };

  const clearBonusLabel = async (label) => {
    if (!selected) return;
    setDeletingLabel(label);
    try {
      await factoryPayrollApi.clearBonusLabel(selected.month, selected.year, label, department);
      toast(`Đã xoá khoản "${label}"`, 'success');
      await loadAdjustments(selected, department);
    } catch (e) {
      toast(e?.response?.data?.message || 'Không xoá được khoản thưởng', 'error');
    } finally {
      setDeletingLabel(null);
    }
  };

  const openPreview = async (type, label) => {
    if (!selected) return;
    setPreviewLoading(true);
    setPreview({ type, label, department, rows: [], rowCount: 0, totalAmount: 0 });
    try {
      const res = await factoryPayrollApi.adjustmentPreview(
        selected.month, selected.year, type, { label, department });
      setPreview(res || null);
    } catch (e) {
      toast(e?.response?.data?.message || 'Không tải được xem trước', 'error');
      setPreview(null);
    } finally {
      setPreviewLoading(false);
    }
  };

  const clearAdjustment = async (type) => {
    if (!selected) return;
    setDeleting(type.toLowerCase());
    try {
      await factoryPayrollApi.clearAdjustments(type, selected.month, selected.year, department);
      toast('Đã xoá dữ liệu đã import', 'success');
      await loadAdjustments(selected, department);
    } catch (e) {
      toast(e?.response?.data?.message || 'Không xoá được', 'error');
    } finally {
      setDeleting(null);
    }
  };

  const doFinalize = async () => {
    if (!selected) return;
    setFinalizing(true);
    try {
      await factoryPayrollApi.finalize(selected.month, selected.year, department);
      toast(`Đã hoàn tất lương ${status?.departmentLabel} tháng ${selected.month}/${selected.year}`, 'success');
      await loadStatus(selected);
    } catch (e) {
      toast(e?.response?.data?.message || 'Lỗi hoàn tất', 'error');
    } finally {
      setFinalizing(false);
    }
  };

  const doReopen = async () => {
    if (!selected) return;
    setFinalizing(true);
    try {
      await factoryPayrollApi.reopen(selected.month, selected.year, department);
      toast('Đã mở lại tháng — nhân viên sẽ thấy "Đang xử lý lương"', 'success');
      await loadStatus(selected);
    } catch (e) {
      toast(e?.response?.data?.message || 'Lỗi mở lại', 'error');
    } finally {
      setFinalizing(false);
    }
  };

  const [finalizingBonus, setFinalizingBonus] = useState(false);
  // (10/2026) State riêng cho Public/Unpublic Thưởng — tránh share spinner với
  // "Tính thưởng" vì OWNER có thể bấm Tính lại trong khi đang Public từ trước.
  const [publishingBonus, setPublishingBonus] = useState(false);
  const [bonusSummary, setBonusSummary] = useState(null);

  // Tải kết quả thưởng doanh thu (nếu đã tính)
  const loadBonusSummary = useCallback(async (p, dept) => {
    const isSalesOrAccounting = dept === 'SALES' || dept === 'ACCOUNTING';
    if (!p || !isSalesOrAccounting) { setBonusSummary(null); return; }
    try {
      const res = await factoryPayrollApi.officeBonus(p.month, p.year, dept);
      setBonusSummary(res || null);
    } catch { setBonusSummary(null); }
  }, []);

  useEffect(() => { loadBonusSummary(selected, department); }, [selected, department, status?.bonusFinalized, loadBonusSummary]);

  const doFinalizeBonus = async () => {
    if (!selected) return;
    setFinalizingBonus(true);
    try {
      const res = await factoryPayrollApi.finalizeBonus(selected.month, selected.year, department);
      toast(`Đã hoàn tất Thưởng ${status?.departmentLabel} tháng ${selected.month}/${selected.year}: ${res?.totalBonusPool?.toLocaleString('vi-VN')}đ`, 'success');
      setBonusSummary(res);
      await loadStatus(selected);
    } catch (e) {
      toast(e?.response?.data?.message || 'Lỗi hoàn tất Thưởng', 'error');
    } finally { setFinalizingBonus(false); }
  };

  // (10/2026) "Mở lại" từ state PUBLISHED → gọi unpublish (GIỮ data đã tính,
  // chỉ ẩn khỏi NV). KHÔNG xoá, KHÔNG popup xác nhận — user bấm là làm luôn.
  // (Phiên bản cũ gọi reopenBonus endpoint xoá sạch về NONE, đã bỏ.)
  const doReopenBonus = async () => {
    if (!selected) return;
    setPublishingBonus(true);
    try {
      await factoryPayrollApi.unpublishBonus(selected.month, selected.year, department);
      toast('Đã mở lại — nhân viên không còn thấy phiếu thưởng', 'success');
      await loadStatus(selected);
    } catch (e) {
      toast(e?.response?.data?.message || 'Lỗi mở lại Thưởng', 'error');
    } finally { setPublishingBonus(false); }
  };

  // (10/2026) Public thưởng — chuyển state CALCULATED → PUBLISHED, nhân viên
  // bắt đầu thấy phiếu thưởng trên app.
  const doPublishBonus = async () => {
    if (!selected) return;
    setPublishingBonus(true);
    try {
      await factoryPayrollApi.publishBonus(selected.month, selected.year, department);
      toast('Đã Public Thưởng — nhân viên đã thấy phiếu thưởng', 'success');
      await loadStatus(selected);
    } catch (e) {
      toast(e?.response?.data?.message || 'Lỗi Public Thưởng', 'error');
    } finally { setPublishingBonus(false); }
  };

  // (10/2026) Unpublic thưởng — ẩn khỏi nhân viên, giữ kết quả đã tính.
  const doUnpublishBonus = async () => {
    if (!selected) return;
    setPublishingBonus(true);
    try {
      await factoryPayrollApi.unpublishBonus(selected.month, selected.year, department);
      toast('Đã Unpublic Thưởng — nhân viên không còn thấy phiếu nữa', 'success');
      await loadStatus(selected);
    } catch (e) {
      toast(e?.response?.data?.message || 'Lỗi Unpublic Thưởng', 'error');
    } finally { setPublishingBonus(false); }
  };

  const doFinalizeKpi = async () => {
    if (!selected) return;
    setFinalizingKpi(true);
    try {
      await factoryPayrollApi.finalizeKpi(selected.month, selected.year, department);
      toast(`Đã hoàn tất KPI/Thưởng ${status?.departmentLabel} tháng ${selected.month}/${selected.year}`, 'success');
      await loadStatus(selected);
      // Reload bảng lương để hiện cột KPI
      await loadPayroll(selected, department, true);
    } catch (e) {
      toast(e?.response?.data?.message || 'Lỗi hoàn tất KPI', 'error');
    } finally {
      setFinalizingKpi(false);
    }
  };

  const doReopenKpi = async () => {
    if (!selected) return;
    setFinalizingKpi(true);
    try {
      await factoryPayrollApi.reopenKpi(selected.month, selected.year, department);
      toast('Đã mở lại KPI — nhân viên sẽ thấy "Đang tính thưởng"', 'success');
      await loadStatus(selected);
    } catch (e) {
      toast(e?.response?.data?.message || 'Lỗi mở lại KPI', 'error');
    } finally {
      setFinalizingKpi(false);
    }
  };

  const recompute = async () => {
    if (!selected) return;
    const raw = String(securityRate).replace(/[^\d]/g, '');
    if (securityRate !== '' && raw === '')
      return toast('Mức thưởng bảo vệ không hợp lệ', 'error');

    setRecomputing(true);
    try {
      await factoryPayrollApi.recomputeKpi(
        selected.month, selected.year, raw === '' ? null : Number(raw));
      toast(`Đã tính lại thưởng KPI tháng ${selected.month}/${selected.year}`, 'success');
      await loadKpi(selected, department);
    } catch (e) {
      toast(e?.response?.data?.message || 'Lỗi tính lại KPI', 'error');
    } finally {
      setRecomputing(false);
    }
  };

  const period = selected ? `${String(selected.month).padStart(2, '0')}_${selected.year}` : '—';
  const attendanceBased = department !== 'DRIVER';

  return (
    <div className="p-4 sm:p-6 space-y-5">
      <BackButton fallback="/owner/users" />

      <div className="flex items-start justify-between gap-4 flex-wrap">
        <PageHeader icon={ClipboardCheck} title="Bảng chấm công"
          subtitle="Quản lý dữ liệu chấm công & chốt lương theo từng bộ phận — nhân viên xem phiếu lương sau khi bấm Hoàn tất" />
        <div className="flex items-center gap-2 flex-wrap">
          <MonthPicker periods={periods} value={selected} onChange={setSelected} disabled={loading} />
          <SecondaryButton onClick={() => loadStatus(selected)} disabled={loading}>
            <RefreshCw size={14} /> Làm mới
          </SecondaryButton>
          <SecondaryButton onClick={() => navigate('/owner/bonus-summary')}>
            <TrendingUp size={14} /> Biến động thưởng
          </SecondaryButton>
          <PrimaryButton onClick={() => setExportModalOpen(true)} disabled={loading || !selected}>
            <Download size={14} /> Xuất file lương
          </PrimaryButton>
          {/* File chi lương theo mẫu ngân hàng — 5 cột: STT / Họ tên / Số TK /
              Ngân hàng / Số tiền. Số TK & Ngân hàng để trống, quản lý tự điền
              trước khi gửi ngân hàng. Số tiền = lương cơ bản + phụ cấp, KHÔNG
              thưởng. Xem BankPaymentExportService để biết quy tắc lọc. */}
          <SecondaryButton
            onClick={handleExportBankPayment}
            disabled={exportingBank || loading || !selected}
            title="Xuất danh sách chi lương theo mẫu ngân hàng (VietinBank CN2) — dùng để chuyển khoản hàng loạt">
            <Landmark size={14} />
            {exportingBank ? 'Đang xuất...' : 'Xuất file NH'}
          </SecondaryButton>
        </div>
      </div>

      {loading ? (
        <SectionCard><LoadingSpinner label="Đang tải..." /></SectionCard>
      ) : !selected ? (
        <SectionCard>
          <p className="text-center text-sm text-muted py-10">Chưa chọn tháng</p>
        </SectionCard>
      ) : (
        <>
          {/* ─────────────────────────────────────────────────────────────────
              Phase 3 refactor — PANEL CHUNG CẢ CÔNG TY (ở đầu trang).
              Toàn bộ upload file chấm công + lịch nghỉ + đơn xin nghỉ dồn
              vào đây, không còn tách theo bộ phận. Lifecycle Tính lương /
              Public / Unpublic / Mở lại cũng chạy ở panel này.
              Tab bộ phận bên dưới chỉ còn để XEM kết quả KPI/thưởng/payroll.
              ───────────────────────────────────────────────────────────── */}
          <CompanyPayrollPanel
            month={selected.month}
            year={selected.year}
            onStatusChanged={() => loadStatus(selected)}
          />

          {/* Tab bộ phận */}
          <DepartmentTabs statuses={statuses} value={department} onChange={setDepartment} />

          {/*
            PHASE 7 (10/2026): GỠ TOÀN BỘ thanh trạng thái + nút
            "Tính lương / Hoàn tất / Mở lại" per-department. Lifecycle giờ
            CHUNG CHO CẢ CÔNG TY — xem CompanyPayrollPanel ở trên. Card
            "Chưa hoàn tất — nhân viên thấy 'Đang xử lý lương'" cũng bỏ.
            Chỉ còn giữ nút "Chi tiết bộ phận" dưới dạng floating để OWNER
            vẫn mở được danh sách thành viên của tab đang chọn.
          */}
          <div className="flex items-center justify-end gap-2 flex-wrap">
            <SecondaryButton onClick={() => setMembersOpen(true)}>
              <Users size={14} /> Chi tiết bộ phận
            </SecondaryButton>
          </div>

          {/* ── TRẠNG THÁI KPI / THƯỞNG ────────────────────────────────────── */}
          {status?.finalized && (
            <SectionCard>
              <div className="flex items-center justify-between gap-4 px-5 py-4 flex-wrap">
                <div className="flex items-center gap-3 min-w-0">
                  <span className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0
                    ${status?.kpiFinalized
                      ? 'bg-emerald-100 dark:bg-emerald-500/18'
                      : 'bg-amber-50 dark:bg-amber-500/10'}`}>
                    <Award size={17} className={status?.kpiFinalized
                      ? 'text-emerald-600 dark:text-emerald-300'
                      : 'text-amber-600 dark:text-amber-300'} />
                  </span>
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-ink">
                      {status?.kpiFinalized
                        ? 'Đã hoàn tất KPI / Thưởng — nhân viên thấy thưởng'
                        : 'KPI / Thưởng đang pending — nhân viên thấy "Đang tính thưởng"'}
                    </p>
                    <p className="text-[11px] text-muted mt-0.5">
                      {status?.kpiFinalized && status?.kpiFinalizedAt
                        ? `Chốt KPI lúc ${formatDateTime(status.kpiFinalizedAt)}`
                        : 'Bấm "Hoàn tất KPI" để nhân viên xem được thưởng'}
                      {status?.kpiFinalizedByName ? ` bởi ${status.kpiFinalizedByName}` : ''}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {status?.kpiFinalized ? (
                    <SecondaryButton onClick={doReopenKpi} disabled={finalizingKpi}>
                      <Unlock size={14} /> Mở lại KPI
                    </SecondaryButton>
                  ) : (
                    <>
                      {/* ── NÚT "TÍNH LẠI THƯỞNG KPI" ────────────────────────
                        * Chỉ hiển thị cho FACTORY và khi KPI đang pending (chưa
                        * Hoàn tất, hoặc đã mở lại). Dùng để recompute quỹ sau khi:
                        *   · work order mới chuyển sang COMPLETED trong tháng
                        *   · thêm/xoá quỹ dư khai báo tay
                        *   · cập nhật mức thưởng bảo vệ
                        * BE: POST /api/factory-payroll/kpi/recompute — xoá record cũ
                        * rồi tính lại từ dữ liệu live (sản lượng + seed + chấm công).
                        */}
                      {department === 'FACTORY' && (
                        <SecondaryButton onClick={recompute} disabled={recomputing || finalizingKpi}>
                          <RefreshCw size={14} />
                          {recomputing ? 'Đang tính...' : 'Tính lại thưởng KPI'}
                        </SecondaryButton>
                      )}
                      <PrimaryButton onClick={doFinalizeKpi} disabled={finalizingKpi || recomputing}>
                        <Gift size={14} />
                        {finalizingKpi ? 'Đang xử lý...' : 'Hoàn tất KPI / Thưởng'}
                      </PrimaryButton>
                    </>
                  )}
                </div>
              </div>
            </SectionCard>
          )}

          {/* ── THƯỞNG DOANH THU — chỉ SALES và ACCOUNTING (bước 3) ──────── */}
          {/* (10/2026) State card này đã BỎ — toàn bộ 3-state logic + action
             buttons giờ nằm trong OfficeBonusDetailTable ngay bên dưới. Giữ
             comment để nếu cần restore vẫn thấy context cũ. */}
          {false && status?.finalized && status?.hasSalesBonus && (() => {
            // (10/2026) 3-state flow cho Thưởng DT:
            //   NONE       = chưa tính           → nút "Tính thưởng"
            //   CALCULATED = đã tính, chưa Public → nút "Public" + "Tính lại" + "Mở lại"
            //   PUBLISHED  = đã tính, đã Public   → nút "Unpublic"
            // bonusFinalized giữ nguyên = true chỉ khi PUBLISHED (BE backward compat).
            const bonusState = status?.bonusCalcStatus || (status?.bonusFinalized ? 'PUBLISHED' : 'NONE');
            const isNone      = bonusState === 'NONE';
            const isCalc      = bonusState === 'CALCULATED';
            const isPublished = bonusState === 'PUBLISHED';
            // Mốc thời gian + người thực hiện ưu tiên theo state hiện tại
            const stateAt = isPublished ? status?.bonusPublishedAt
                           : isCalc     ? status?.bonusCalculatedAt
                           : null;
            const stateBy = isPublished ? status?.bonusPublishedByName
                           : isCalc     ? status?.bonusCalculatedByName
                           : null;
            return (
            <SectionCard>
              <div className="flex items-center justify-between gap-4 px-5 py-4 flex-wrap">
                <div className="flex items-center gap-3 min-w-0">
                  <span className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0
                    ${isPublished
                      ? 'bg-emerald-100 dark:bg-emerald-500/18'
                      : isCalc
                        ? 'bg-amber-50 dark:bg-amber-500/10'
                        : 'bg-purple-50 dark:bg-purple-500/10'}`}>
                    <Gift size={17} className={isPublished
                      ? 'text-emerald-600 dark:text-emerald-300'
                      : isCalc
                        ? 'text-amber-600 dark:text-amber-300'
                        : 'text-purple-500 dark:text-purple-300'} />
                  </span>
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-ink">
                      {isPublished && 'Thưởng doanh thu đã Public — nhân viên thấy thưởng'}
                      {isCalc      && 'Đã tính Thưởng — CHƯA Public (nhân viên chưa thấy)'}
                      {isNone      && 'Chưa tính Thưởng doanh thu — nhân viên thấy "Đang tính thưởng"'}
                    </p>
                    <p className="text-[11px] text-muted mt-0.5">
                      {stateAt ? (
                        <>
                          {isPublished ? 'Public lúc' : 'Tính lúc'} {formatDateTime(stateAt)}
                          {stateBy ? ` bởi ${stateBy}` : ''}
                        </>
                      ) : status?.kpiFinalized
                        ? 'Bấm "Tính thưởng" để tính thưởng từ doanh thu tháng này'
                        : 'Cần hoàn tất KPI trước'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  {isNone && (
                    <PrimaryButton
                      onClick={doFinalizeBonus}
                      disabled={finalizingBonus || !status?.kpiFinalized}
                      loading={finalizingBonus}>
                      <Gift size={14} />
                      {finalizingBonus ? 'Đang tính...' : 'Tính thưởng'}
                    </PrimaryButton>
                  )}
                  {isCalc && (
                    <>
                      {/* "Tính lại" chỉ ghi đè kết quả (service đã delete rồi
                          tính lại trong 1 transaction) — KHÔNG xoá sạch về
                          state NONE. Chỉ cần nếu OWNER muốn đổi config. */}
                      <SecondaryButton
                        onClick={doFinalizeBonus}
                        disabled={finalizingBonus}>
                        <RefreshCw size={14} />
                        {finalizingBonus ? 'Đang tính...' : 'Tính lại'}
                      </SecondaryButton>
                      <PrimaryButton onClick={doPublishBonus} disabled={publishingBonus}>
                        <Gift size={14} />
                        {publishingBonus ? 'Đang hoàn tất...' : 'Hoàn tất'}
                      </PrimaryButton>
                    </>
                  )}
                  {isPublished && (
                    <SecondaryButton onClick={doUnpublishBonus} disabled={publishingBonus}>
                      <Lock size={14} /> Unpublic
                    </SecondaryButton>
                  )}
                </div>
              </div>

              {/* Bảng kết quả thưởng — hiện ngay khi đã Tính (CALCULATED/PUBLISHED),
                 không chờ Public. OWNER cần thấy để quyết định Public hay Tính lại. */}
              {(isCalc || isPublished) && bonusSummary && (
                <div className="px-5 pb-5 space-y-3">
                  {/* Tổng quan */}
                  <div className="rounded-xl bg-canvas px-4 py-3 grid grid-cols-2 sm:grid-cols-3 gap-3">
                    <div>
                      <p className="text-[10px] text-muted uppercase tracking-wider">Doanh thu tháng</p>
                      <p className="text-sm font-bold text-ink mt-0.5">
                        {Number(bonusSummary.totalRevenue || 0).toLocaleString('vi-VN')}đ
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] text-muted uppercase tracking-wider">Tổng thưởng</p>
                      <p className="text-sm font-bold text-emerald-600 dark:text-emerald-300 mt-0.5">
                        {Number(bonusSummary.totalBonusPool || 0).toLocaleString('vi-VN')}đ
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] text-muted uppercase tracking-wider">Số phiếu TT</p>
                      <p className="text-sm font-bold text-ink mt-0.5">
                        {bonusSummary.transactionCount || 0}
                      </p>
                    </div>
                  </div>

                  {/* Chi tiết từng người */}
                  {bonusSummary.items?.length > 0 && (
                    <div className="rounded-xl border border-hairline overflow-hidden">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="bg-canvas">
                            <th className="text-left px-3 py-2 text-[10px] font-bold text-muted uppercase">Nhân viên</th>
                            {department === 'SALES' && (
                              <th className="text-right px-3 py-2 text-[10px] font-bold text-muted uppercase">Doanh thu</th>
                            )}
                            <th className="text-right px-3 py-2 text-[10px] font-bold text-muted uppercase">KPI</th>
                            <th className="text-right px-3 py-2 text-[10px] font-bold text-muted uppercase">Thưởng</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-hairline">
                          {bonusSummary.items.map(item => (
                            <tr key={item.userId} className="hover:bg-canvas/50">
                              <td className="px-3 py-2">
                                <p className="font-medium text-ink">{item.userFullName}</p>
                                <p className="text-[10px] text-muted">{item.roleLabel}</p>
                              </td>
                              {department === 'SALES' && (
                                <td className="px-3 py-2 text-right text-muted">
                                  {Number(item.revenue || 0).toLocaleString('vi-VN')}đ
                                  {item.transactionCount > 0 && (
                                    <span className="block text-[10px]">({item.transactionCount} phiếu)</span>
                                  )}
                                </td>
                              )}
                              <td className="px-3 py-2 text-right text-muted">{item.kpiPercent ?? 100}%</td>
                              <td className="px-3 py-2 text-right font-bold text-emerald-600 dark:text-emerald-300">
                                {Number(item.bonusAmount || 0).toLocaleString('vi-VN')}đ
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}

                  <p className="text-[10px] text-muted">
                    * Tính theo tiền thực thu ({department === 'SALES' ? 'theo từng seller' : 'tổng phòng'})
                    qua PaymentTransaction trong tháng. Chỉ đơn PENDING_PAYMENT / COMPLETED.
                  </p>
                </div>
              )}
            </SectionCard>
            );
          })()}

          {/* ── TASK 2 (11/2026): BẢNG HOA HỒNG chi tiết — SALES / ACCOUNTING ─
              Hoạt động cả khi CHƯA tính (bonusAmount = "—") và sau khi đã tính.
              OWNER nhập đơn giá rồi bấm "Tính hoa hồng" → BE tính theo công thức
              trong OfficeBonusCommissionUtil (SALES ceil 5k / ACCOUNTING chia
              theo weight floor 5k). */}
          {(department === 'SALES' || department === 'ACCOUNTING') && selected && (
            <OfficeBonusDetailTable
              department={department}
              departmentLabel={department === 'SALES' ? 'Kinh doanh' : 'Kế toán'}
              month={selected.month}
              year={selected.year}
              bonusFinalized={!!status?.bonusFinalized}
              bonusCalcStatus={status?.bonusCalcStatus}
              publishingBonus={publishingBonus}
              onComputed={() => loadStatus(selected)}
              onReopen={doReopenBonus}
              onPublish={doPublishBonus}
              onUnpublish={doUnpublishBonus}
            />
          )}

          {/* ── TÍNH THƯỞNG — KHO (placeholder, chưa triển khai backend) ─── */}
          {/* (10/2026) Thưởng CỨNG cho NV phòng Kho — nhập tay per-user. */}
          {department === 'WAREHOUSE' && selected && (
            <WarehouseBonusEditor
              month={selected.month}
              year={selected.year}
              toast={toast} />
          )}

          {/*
            PHASE 7 (10/2026): GỠ TOÀN BỘ 4 file slots per-department
            (Bảng chấm công, Lịch nghỉ, Thưởng, Phụ cấp). Mọi upload giờ ở
            CompanyPayrollPanel đầu trang. Driver cũng tương tự.
            Giữ ternary cũ dưới dạng NEVER để tiện revert; eslint sẽ cảnh báo
            nhánh unreachable nhưng không block build.
          */}
          {false && attendanceBased ? (
            <>
              <div className="flex items-center gap-2 text-[11px] text-muted bg-canvas
                rounded-xl px-3.5 py-2.5">
                <FileSpreadsheet size={13} className="shrink-0" />
                <span>Cả 3 file của bộ phận này được lưu trong thư mục
                  <strong className="text-ink"> attendance/{period}/{department}/</strong></span>
              </div>

              <div className="grid gap-4 lg:grid-cols-2">
                <FileSlot
                  icon={Clock}
                  title="Bảng chấm công"
                  description="File xuất từ máy chấm công, chứa giờ vào/ra từng ngày"
                  hint="Mỗi nhân viên là một block riêng có dòng Mã nhân viên / Tên nhân viên."
                  exists={status?.hasAttendanceFile}
                  fileName={status?.fileName}
                  uploadedAt={status?.uploadedAt}
                  rowCount={status?.parsedRows}
                  rowLabel="nhân viên"
                  uploading={busy === 'attendance'}
                  deleting={deleting === 'attendance'}
                  onUpload={f => upload('attendance', f)}
                  onDelete={() => remove('attendance')}
                />

                <FileSlot
                  icon={CalendarClock}
                  title="Lịch nghỉ / đi trễ / về sớm"
                  description="Áp dụng cho TOÀN BỘ nhân viên của bộ phận trong ngày được khai báo"
                  hint="Tải file mẫu, chọn Loại ở những ngày có ngoại lệ rồi tải lên."
                  exists={status?.hasExceptionFile}
                  fileName={status?.exceptionFileName}
                  uploadedAt={status?.exceptionUploadedAt}
                  rowCount={status?.exceptionRows}
                  rowLabel="ngày"
                  uploading={busy === 'exception'}
                  deleting={deleting === 'exception'}
                  onUpload={f => upload('exception', f)}
                  onDelete={() => remove('exception')}
                  onTemplate={() => template('exception')}
                />

                {/* Khối upload "Đơn xin đi trễ / nghỉ phép" đã được gỡ bỏ.
                    Đơn nay do nhân viên tự tạo trên app và OWNER duyệt ở tab
                    Nhân sự → Phiếu nghỉ → Đơn nhân viên; hệ thống tự khớp đơn
                    đã duyệt vào bảng chấm công khi tính công. Giữ lại ô upload
                    sẽ tạo ra nguồn sự thật thứ hai, và file tải lên sau sẽ ghi
                    đè kết quả duyệt trên app. */}
              </div>
            </>
          ) : (
            /* HOTFIX (10/2026): DriverPayrollPanel (bảng Lương tài xế theo km
               & lượt giao) CHỈ hiển thị khi đang xem tab Tài xế. Trước đây
               ternary {false && attendanceBased ?} luôn rơi vào else nên
               panel này xuất hiện ở MỌI tab (lỗi báo trong screenshot). */
            department === 'DRIVER' && selected && (
              <DriverPayrollPanel
                month={selected.month}
                year={selected.year}
                onSaved={() => loadStatus(selected)}
                onComputePreview={computePreview}
                computingPreview={computingPreview || loadingPayroll}
                finalizedPeriod={!!status?.finalized}
                bonusCalcStatus={status?.bonusCalcStatus}
                bonusFinalized={!!status?.bonusFinalized}
                publishingBonus={publishingBonus}
                onPublish={doPublishBonus}
                onUnpublish={doUnpublishBonus}
              />
            )
          )}

          {/* Tổng hợp quỹ thưởng KPI — chỉ Xưởng và chỉ khi đã tính */}
          {department === 'FACTORY' && <KpiSummary kpi={kpi} />}

          {/* Khai báo quỹ dư của tháng chia ngoài app */}
          {department === 'FACTORY' && selected && (
            <CarryOverSeedPanel
              month={selected.month}
              year={selected.year}
              periodLabel={selected.label}
              onChanged={() => loadKpi(selected, department)}
            />
          )}

          {status?.note && (
            <div className="flex items-start gap-2 bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/28 rounded-xl px-4 py-3">
              <AlertCircle size={15} className="text-amber-600 dark:text-amber-300 shrink-0 mt-0.5" />
              <p className="text-xs text-amber-800 dark:text-amber-300 leading-snug">{status.note}</p>
            </div>
          )}
        </>
      )}

      {result && (
        <ImportResultModal result={result} title={resultTitle} onClose={() => setResult(null)} />
      )}

      {adjResult && (
        <AdjustmentResultModal result={adjResult} title={adjResultTitle}
          onClose={() => setAdjResult(null)} />
      )}

      {/* Danh sách nhân sự của bộ phận đang chọn */}
      <DepartmentMembersModal
        open={membersOpen}
        department={department}
        departmentLabel={status?.departmentLabel}
        onClose={() => setMembersOpen(false)}
      />

      {/* Preview nội dung đã import — read-only */}
      {preview && (
        <AdjustmentPreviewModal
          preview={preview} loading={previewLoading}
          departmentLabel={status?.departmentLabel}
          onClose={() => setPreview(null)}
        />
      )}

      {/* ═══ MODAL XUẤT FILE LƯƠNG ═══ */}
      <Modal open={exportModalOpen} onClose={() => setExportModalOpen(false)}
        title="Xuất file lương tổng hợp" size="md">
        <div className="px-5 py-4 space-y-5">
          {/* Phòng ban đang chọn — tự động theo tab */}
          <div className="rounded-xl bg-canvas px-4 py-3 flex items-center gap-2.5">
            <Users size={16} className="text-gold shrink-0" />
            <div>
              <p className="text-xs font-semibold text-muted">Phòng ban</p>
              <p className="text-sm font-bold text-ink">
                {status?.departmentLabel || department}
              </p>
            </div>
          </div>

          {/* Loại xuất */}
          <div>
            <p className="text-sm font-bold text-ink mb-2.5">Nội dung xuất</p>
            <div className="space-y-2">
              {[
                { value: 'SALARY_ONLY', label: 'Lương (tất cả phòng ban)' },
                { value: 'BONUS_ONLY', label: 'Thưởng (phòng ban đang chọn)' },
              ].map(opt => (
                <label key={opt.value}
                  className="flex items-center gap-2.5 cursor-pointer select-none group">
                  <input type="radio" name="exportType"
                    checked={exportType === opt.value}
                    onChange={() => setExportType(opt.value)}
                    className="w-4 h-4 border-hairline-2 text-gold focus:ring-gold/30 cursor-pointer" />
                  <span className="text-sm text-ink group-hover:text-gold transition-colors">{opt.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Thông tin tháng */}
          {selected && (
            <div className="text-xs text-muted bg-canvas rounded-xl px-3 py-2.5 space-y-1">
              <p>
                <CalendarDays size={13} className="inline -mt-0.5 mr-1 text-gold" />
                Xuất file cho <span className="font-bold text-ink">Tháng {selected.month}/{selected.year}</span>
              </p>
              <p className="text-[10px]">
                {exportType === 'SALARY_ONLY'
                  ? '📋 File lương sẽ gồm tất cả phòng ban, sắp xếp theo thứ tự.'
                  : `📊 File thưởng chỉ xuất cho phòng ${status?.departmentLabel || department}.`}
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-5 py-4 border-t border-hairline">
          <SecondaryButton onClick={() => setExportModalOpen(false)} disabled={exporting}>
            Huỷ
          </SecondaryButton>
          <PrimaryButton onClick={handleExportSalary} disabled={exporting}>
            {exporting
              ? <><RefreshCw size={14} className="animate-spin" /> Đang xuất...</>
              : <><Download size={14} /> Xuất file</>}
          </PrimaryButton>
        </div>
      </Modal>
    </div>
  );
}

/** Modal xem lại nội dung đã import — CHỈ đọc, không sửa. */
function AdjustmentPreviewModal({ preview, loading, departmentLabel, onClose }) {
  const isBonus = preview?.type === 'BONUS';
  const title = isBonus
    ? `Xem lại file thưởng — ${preview?.label || '(không nhãn)'}`
    : 'Xem lại file phụ cấp';
  const headers = preview?.fileHeaders || [];
  const rows = preview?.fileRows || [];
  const hasFile = headers.length > 0 || rows.length > 0;

  // Với ALLOWANCE, pivot dạng "wide" (mỗi cặp Khoản/Số tiền là 1 cột) sang
  // "long" (mỗi khoản là 1 dòng riêng dưới nhân viên). Bỏ khoản trống.
  // Cấu trúc gốc: [ID, Họ tên, Khoản 1, Số tiền 1, Khoản 2, Số tiền 2, ...]
  const pivoted = !isBonus && hasFile
    ? rows.map(row => {
      const id = row[0] || '';
      const name = row[1] || '';
      const items = [];
      for (let c = 2; c + 1 < row.length; c += 2) {
        const label = (row[c] || '').trim();
        const amount = (row[c + 1] || '').trim();
        if (label || amount) items.push({ label, amount });
      }
      return { id, name, items };
    }).filter(r => r.id || r.name || r.items.length > 0)
    : null;

  return (
    <div className="fixed inset-0 z-[95] flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4">
      <div className="bg-surface rounded-t-2xl sm:rounded-2xl shadow-2xl w-full max-w-4xl max-h-[92vh] flex flex-col">
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-hairline">
          <div className="min-w-0">
            <p className="font-bold text-ink text-base sm:text-lg truncate">{title}</p>
            <p className="text-xs text-muted truncate">
              {departmentLabel || '—'}
              {preview?.fileName && <> · <span className="font-mono">{preview.fileName}</span></>}
              {' · '}Tổng {formatCurrency(preview?.totalAmount || 0)}
            </p>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-canvas text-muted shrink-0">
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-5">
          {loading ? <LoadingSpinner /> : !hasFile ? (
            <EmptyState title="Không có file gốc"
              description="Khoản này được import trước khi hệ thống bắt đầu lưu file gốc. Import lại để có preview." />
          ) : pivoted ? (
            // ── Bảng dọc cho PHỤ CẤP: mỗi khoản có data là 1 dòng riêng ─────
            <div className="overflow-auto rounded-xl border border-hairline">
              <table className="w-full text-xs border-collapse">
                <thead className="bg-canvas sticky top-0">
                  <tr>
                    <th className="px-2 py-1.5 text-[10px] font-bold text-muted border-b border-r border-hairline w-10">#</th>
                    <th className="px-3 py-1.5 text-left text-[11px] font-bold text-ink border-b border-hairline w-16">ID</th>
                    <th className="px-3 py-1.5 text-left text-[11px] font-bold text-ink border-b border-hairline">Họ tên</th>
                    <th className="px-3 py-1.5 text-left text-[11px] font-bold text-ink border-b border-hairline">Khoản phụ cấp</th>
                    <th className="px-3 py-1.5 text-right text-[11px] font-bold text-ink border-b border-hairline w-32">Số tiền</th>
                  </tr>
                </thead>
                <tbody>
                  {pivoted.map((p, r) => {
                    // Không có khoản nào → vẫn hiện 1 dòng với "—"
                    const items = p.items.length > 0 ? p.items : [{ label: '', amount: '' }];
                    return items.map((it, i) => (
                      <tr key={`${r}-${i}`} className="hover:bg-canvas/60">
                        {i === 0 && (
                          <>
                            <td rowSpan={items.length}
                              className="px-2 py-1.5 text-[10px] text-muted border-b border-r border-hairline text-center bg-canvas/40 align-top">
                              {r + 1}
                            </td>
                            <td rowSpan={items.length}
                              className="px-3 py-1.5 text-ink border-b border-hairline align-top font-medium">
                              {p.id || <span className="text-muted italic">—</span>}
                            </td>
                            <td rowSpan={items.length}
                              className="px-3 py-1.5 text-ink border-b border-hairline align-top">
                              {p.name || <span className="text-muted italic">—</span>}
                            </td>
                          </>
                        )}
                        <td className="px-3 py-1.5 text-ink border-b border-hairline whitespace-nowrap">
                          {it.label || <span className="text-muted italic">—</span>}
                        </td>
                        <td className="px-3 py-1.5 text-ink border-b border-hairline whitespace-nowrap text-right font-semibold">
                          {it.amount
                            ? <>{it.amount}<span className="text-muted">đ</span></>
                            : <span className="text-muted italic">—</span>}
                        </td>
                      </tr>
                    ));
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            // ── Bảng ngang cho THƯỞNG: giữ layout gốc (ID | Họ tên | Số tiền) ──
            <div className="overflow-auto rounded-xl border border-hairline">
              <table className="w-full text-xs border-collapse">
                <thead className="bg-canvas sticky top-0">
                  <tr>
                    <th className="px-2 py-1.5 text-[10px] font-bold text-muted border-b border-r border-hairline w-10">#</th>
                    {headers.map((h, i) => {
                      const isMoney = i === headers.length - 1;   // cột "Số tiền thưởng"
                      return (
                        <th key={i}
                          className={`px-3 py-1.5 text-[11px] font-bold text-ink border-b border-hairline whitespace-nowrap ${isMoney ? 'text-right' : 'text-left'}`}>
                          {h || <span className="text-muted italic">Cột {String.fromCharCode(65 + i)}</span>}
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row, r) => (
                    <tr key={r} className="hover:bg-canvas/60">
                      <td className="px-2 py-1.5 text-[10px] text-muted border-b border-r border-hairline text-center bg-canvas/40">
                        {r + 1}
                      </td>
                      {row.map((cell, c) => {
                        const isMoney = c === row.length - 1;
                        return (
                          <td key={c}
                            className={`px-3 py-1.5 text-ink border-b border-hairline whitespace-nowrap ${isMoney ? 'text-right font-semibold' : ''}`}>
                            {cell
                              ? (isMoney ? <>{cell}<span className="text-muted">đ</span></> : cell)
                              : <span className="text-muted italic">—</span>}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ╔══════════════════════════════════════════════════════════════════════╗
   ║ WAREHOUSE BONUS EDITOR (10/2026)                                     ║
   ║ Nhập thưởng cứng cho NV phòng Kho — Lưu (draft) + Hoàn tất (public). ║
   ╚══════════════════════════════════════════════════════════════════════╝ */

/** Placeholder cứng theo tên NV (nếu chưa có bản ghi). */
const WAREHOUSE_DEFAULT = {
  'Phạm Thị Thanh An': 1_200_000,
};
const defaultForWarehouse = (fullName) => {
  for (const [name, v] of Object.entries(WAREHOUSE_DEFAULT)) {
    if (fullName && fullName.includes(name)) return v;
  }
  return 0;
};

function WarehouseBonusEditor({ month, year, toast }) {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [bonusStatus, setBonusStatus] = useState(null);     // NONE | CALCULATED | PUBLISHED
  const [edits, setEdits] = useState({});                    // userId → string value
  // (10/2026) Thay window.confirm bằng ConfirmModal — thẩm mỹ nhất quán toàn app
  const [confirming, setConfirming] = useState(null);
  const monthKey = `${year}-${String(month).padStart(2, '0')}`;

  const load = () => {
    setLoading(true);
    Promise.all([
      factoryPayrollApi.getBonusTrend('WAREHOUSE'),
      factoryPayrollApi.monthStatus(month, year, 'WAREHOUSE').catch(() => null),
    ])
      .then(([trend, status]) => {
        const list = trend.users || [];
        setUsers(list);
        // Pre-fill: existing amount OR placeholder
        const e = {};
        list.forEach(u => {
          const existing = u.amountsByMonth?.[monthKey];
          const val = existing != null && existing > 0 ? existing : defaultForWarehouse(u.fullName);
          e[u.userId] = String(val || 0);
        });
        setEdits(e);
        setBonusStatus(status?.bonusCalcStatus || (status?.bonusFinalized ? 'PUBLISHED' : 'NONE'));
      })
      .catch(err => toast(err?.response?.data?.message || 'Lỗi load NV kho', 'error'))
      .finally(() => setLoading(false));
  };
  useEffect(load, [month, year]);  // eslint-disable-line

  const published = bonusStatus === 'PUBLISHED';
  const readOnly = published;

  const setVal = (userId, raw) => {
    setEdits(prev => ({ ...prev, [userId]: raw.replace(/[^\d]/g, '') }));
  };

  /** Lưu tất cả rows → sheet thành CALCULATED (chưa Public). */
  const saveDraft = async () => {
    setSaving(true);
    try {
      for (const u of users) {
        const amt = Number(edits[u.userId] || 0) || 0;
        await factoryPayrollApi.upsertWarehouseBonus({ userId: u.userId, month, year, amount: amt });
      }
      toast('Đã lưu nháp thưởng Kho. Bấm "Hoàn tất" để Public.', 'success');
      load();
    } catch (e) {
      toast(e?.response?.data?.message || 'Không lưu được', 'error');
    } finally {
      setSaving(false);
    }
  };

  /** Lưu + Public → NV thấy phiếu. (10/2026) Dùng ConfirmModal thay window.confirm. */
  const doPublish = async () => {
    setSaving(true);
    try {
      for (const u of users) {
        const amt = Number(edits[u.userId] || 0) || 0;
        await factoryPayrollApi.upsertWarehouseBonus({ userId: u.userId, month, year, amount: amt });
      }
      await factoryPayrollApi.publishWarehouseBonus(month, year);
      toast('Đã Public thưởng Kho', 'success');
      load();
    } catch (e) {
      toast(e?.response?.data?.message || 'Không Public được', 'error');
    } finally {
      setSaving(false);
    }
  };
  const publish = () => setConfirming({
    title: 'Hoàn tất thưởng Kho?',
    message: 'Sau khi hoàn tất, nhân viên Kho sẽ thấy phiếu thưởng tháng '
      + `${String(month).padStart(2, '0')}/${year}. Bạn vẫn có thể "Mở tính lại" để điều chỉnh sau.`,
    confirmLabel: 'Hoàn tất',
    variant: 'primary',
    onConfirm: doPublish,
  });

  const doUnpublish = async () => {
    setSaving(true);
    try {
      await factoryPayrollApi.unpublishWarehouseBonus(month, year);
      toast('Đã mở lại', 'success');
      load();
    } catch (e) {
      toast(e?.response?.data?.message || 'Không mở lại được', 'error');
    } finally {
      setSaving(false);
    }
  };
  const unpublish = () => setConfirming({
    title: 'Mở lại thưởng Kho?',
    message: 'Nhân viên sẽ không còn thấy phiếu thưởng cho đến khi bạn Hoàn tất lại. Dữ liệu đã nhập được giữ nguyên.',
    confirmLabel: 'Mở lại',
    variant: 'danger',
    onConfirm: doUnpublish,
  });

  return (
    <SectionCard>
      <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-hairline flex-wrap">
        <div className="flex items-center gap-3 min-w-0">
          <span className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-500/10
            flex items-center justify-center shrink-0">
            <Gift size={17} className="text-purple-500 dark:text-purple-300" />
          </span>
          <div className="min-w-0">
            <p className="text-sm font-bold text-ink">
              Thưởng Kho — Tháng {String(month).padStart(2, '0')}/{year}
              {published && (
                <span className="ml-2 text-[10px] px-2 py-0.5 bg-emerald-100 dark:bg-emerald-500/20
                                 text-emerald-700 dark:text-emerald-300 rounded font-bold">
                  ĐÃ PUBLIC
                </span>
              )}
              {bonusStatus === 'CALCULATED' && (
                <span className="ml-2 text-[10px] px-2 py-0.5 bg-amber-100 dark:bg-amber-500/20
                                 text-amber-700 dark:text-amber-300 rounded font-bold">
                  ĐANG LƯU NHÁP
                </span>
              )}
            </p>
            <p className="text-[11px] text-muted mt-0.5">
              {published
                ? 'NV đã thấy phiếu thưởng. Bấm "Mở tính lại" để điều chỉnh.'
                : 'Nhập số tiền thưởng. "Lưu" = lưu nháp. "Hoàn tất" = Public cho NV.'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {published ? (
            <SecondaryButton onClick={unpublish} disabled={saving}>
              <Unlock size={13} /> Mở tính lại
            </SecondaryButton>
          ) : (
            <>
              <SecondaryButton onClick={saveDraft} disabled={saving || loading}>
                <Check size={13} /> {saving ? 'Đang lưu...' : 'Lưu'}
              </SecondaryButton>
              <PrimaryButton onClick={publish} disabled={saving || loading}>
                <Gift size={13} /> Hoàn tất
              </PrimaryButton>
            </>
          )}
        </div>
      </div>

      {loading ? (
        <div className="p-10 flex justify-center"><LoadingSpinner /></div>
      ) : users.length === 0 ? (
        <div className="p-6 text-center text-muted italic">Không có NV phòng Kho.</div>
      ) : (
        <>
          <div className="divide-y divide-hairline">
            {users.map(u => {
              const curVal = Number(edits[u.userId] || 0) || 0;
              return (
                <div key={u.userId}
                     className={`flex items-center justify-between gap-3 px-5 py-3
                                 ${u.deleted ? 'opacity-50' : ''}`}>
                  <div className="min-w-0 flex-1">
                    <div className="font-semibold text-ink">{u.fullName}</div>
                    <div className="text-[11px] text-muted">{u.roleLabel}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="text" inputMode="numeric"
                      value={curVal.toLocaleString('vi-VN')}
                      onFocus={(e) => e.target.select()}
                      onChange={(e) => setVal(u.userId, e.target.value)}
                      disabled={readOnly}
                      placeholder="0"
                      className="w-40 text-right px-3 py-2 rounded-lg border border-hairline-2 bg-surface
                                 tabular-nums font-bold text-sm focus:border-gold outline-none
                                 disabled:bg-canvas disabled:text-muted" />
                    <span className="text-xs text-muted">đ</span>
                  </div>
                </div>
              );
            })}
          </div>
          {/* (10/2026) Dòng tổng — cộng theo đúng số đang hiển thị trên UI */}
          <div className="flex items-center justify-between gap-3 px-5 py-3
                          border-t border-hairline bg-emerald-50/40 dark:bg-emerald-500/5">
            <span className="text-xs font-bold uppercase tracking-wider
                             text-emerald-700 dark:text-emerald-300">
              Tổng thưởng Kho ({users.length} người)
            </span>
            <span className="text-sm font-bold text-emerald-700 dark:text-emerald-300 tabular-nums">
              {users.reduce((s, u) => s + (Number(edits[u.userId] || 0) || 0), 0)
                   .toLocaleString('vi-VN')}đ
            </span>
          </div>
        </>
      )}

      {confirming && (
        <ConfirmModal
          {...confirming}
          onClose={() => setConfirming(null)}
        />
      )}
    </SectionCard>
  );
}