// src/pages/super_accountant/SuperAccountantMaterialRequestPage.jsx
import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { Search, Package, ChevronDown, ChevronUp, Plus, X, Check, Camera, Loader2, Trash2, Info, CalendarClock, Eye } from 'lucide-react';
import useMinLoading from '../../hooks/useMinLoading.js';
import { Field, inputCls, PrimaryButton, SecondaryButton } from '../../components/ui';
import { CardSkeleton } from '../../components/ui/Skeleton.jsx';
import Modal from '../../components/ui/Modal.jsx';
import DateRangePicker from '../../components/ui/DateRangePicker.jsx';
import DatePicker from '../../components/ui/DatePicker.jsx';
import {
  accountantMaterialRequestApi, STATUS_CONFIG, fmtTs, fmtDateTime, countdownInfo, fmtVND, PAYMENT_METHODS,
} from '../../api/materialRequestApi.js';
import { factoryProdApi } from '../../api/productionModuleApi.js';
import { useToast } from '../../components/common/Toast.jsx';
import { useLang } from '../../context/LangContext';
import { useFmt } from '../../utils/useFmt';
import api from '../../api/axios.js';
import {
  allocateCost, unitPriceFromTotal,
  normalizeMoney, fmtMoney, fmtDong, MONEY_DECIMALS,
} from '../../utils/costCalc';

const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080';
const imgUrl = (p) => { if (!p) return ''; if (p.startsWith('http')) return p; return BASE_URL + "/api/auth" + p; };

// ── Định dạng số tiền kiểu Việt Nam khi gõ ────────────────────────────────────
// Quy ước: dấu CHẤM ngăn cách hàng nghìn, dấu PHẨY là dấu thập phân (tối đa 3 số).
//   "123123123"  → "123.123.123"
//   "123123,45"  → "123.123,45"
//   đã có phẩy + đủ 3 số lẻ → không nhận thêm ký tự thập phân nữa.
function formatMoneyTyping(raw) {
  if (raw == null) return '';
  let s = String(raw).replace(/[^\d,]/g, ''); // chỉ giữ chữ số và dấu phẩy
  const firstComma = s.indexOf(',');
  let intPart, decPart;
  if (firstComma === -1) {
    intPart = s;
    decPart = null;
  } else {
    intPart = s.slice(0, firstComma).replace(/,/g, '');
    decPart = s.slice(firstComma + 1).replace(/,/g, '').slice(0, MONEY_DECIMALS); // tối đa 3 số lẻ
  }
  intPart = intPart.replace(/^0+(?=\d)/, ''); // bỏ số 0 vô nghĩa ở đầu
  if (intPart === '') intPart = decPart === null ? '' : '0';
  const intFmt = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  if (decPart === null) return intFmt;
  return `${intFmt},${decPart}`;
}

// Chuỗi hiển thị VN ("1.234.567,89") → number (hoặc null nếu rỗng/không hợp lệ)
function parseMoneyVN(s) {
  if (s == null || s === '') return null;
  const cleaned = String(s).replace(/\./g, '').replace(',', '.');
  if (cleaned === '' || cleaned === '.') return null;
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : null;
}

// number → chuỗi hiển thị VN (tối đa 3 số lẻ, bỏ số 0 lẻ thừa)
function moneyToVN(n) {
  if (n == null || !Number.isFinite(n)) return '';
  const neg = n < 0;
  const [i, dRaw] = Math.abs(n).toFixed(MONEY_DECIMALS).split('.');
  const d = (dRaw || '').replace(/0+$/, '');
  const iFmt = i.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return (neg ? '-' : '') + (d ? `${iFmt},${d}` : iFmt);
}

// ── Countdown badge — đếm ngược giây ─────────────────────────────────────────
function CountdownBadge({ targetMs, label }) {
  const { t } = useLang();
  const { fmtCurrency, fmtDate, fmtDateTime } = useFmt();
  const [info, setInfo] = useState(() => countdownInfo(targetMs));
  useEffect(() => {
    if (!targetMs) return;
    // Cập nhật mỗi giây
    const t = setInterval(() => setInfo(countdownInfo(targetMs)), 1000);
    return () => clearInterval(t);
  }, [targetMs]);
  if (!info) return null;
  const cls = {
    red:    'bg-red-100 dark:bg-red-500/18 text-red-700 dark:text-red-300',
    yellow: 'bg-amber-100 dark:bg-amber-500/18 text-amber-700 dark:text-amber-300',
    normal: 'bg-blue-50 dark:bg-blue-500/10 text-blue-700 dark:text-blue-300',
  }[info.color];
  return <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${cls}`}>{label}: {info.label}</span>;
}

// Cập nhật hàm countdownInfo để hiện giây khi < 1 giờ
function liveCountdown(targetMs) {
  if (!targetMs) return null;
  const diff = targetMs - Date.now();
  if (diff <= 0) return { label: 'Overdue', color: 'red' };
  const totalSec = Math.floor(diff / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (h < 1) return { label: `${m}p ${s}s`, color: totalSec < 600 ? 'red' : 'yellow' };
  if (h < 24) return { label: `${h}g ${m}p`, color: h < 6 ? 'red' : 'yellow' };
  const d = Math.floor(h / 24);
  return { label: `${d}d ${h % 24}h`, color: 'normal' };
}

function LiveCountdownBadge({ targetMs, label }) {
  const { t } = useLang();
  const { fmtCurrency, fmtDate, fmtDateTime } = useFmt();
  const [info, setInfo] = useState(() => liveCountdown(targetMs));
  useEffect(() => {
    if (!targetMs) return;
    const t = setInterval(() => setInfo(liveCountdown(targetMs)), 1000);
    return () => clearInterval(t);
  }, [targetMs]);
  if (!info) return null;
  const cls = { red: 'bg-red-100 dark:bg-red-500/18 text-red-700 dark:text-red-300', yellow: 'bg-amber-100 dark:bg-amber-500/18 text-amber-700 dark:text-amber-300', normal: 'bg-blue-50 dark:bg-blue-500/10 text-blue-700 dark:text-blue-300' }[info.color];
  return (
    <span className={`text-xs px-2.5 py-1 rounded-full font-semibold tabular-nums ${cls}`}>
      ⏱ {label}: {info.label}
    </span>
  );
}

// ── Card bg ────────────────────────────────────────────────────────────────────
function cardBg(req) {
  if (req.status === 'RECEIVED') return 'bg-emerald-50 dark:bg-emerald-500/10 border-emerald-200 dark:border-emerald-500/28';
  if (req.status === 'COMPLETED') return 'bg-surface';
  if (!req.requiredBy) return 'bg-surface';
  const info = liveCountdown(req.requiredBy);
  if (!info) return 'bg-surface';
  if (info.color === 'red') return 'bg-red-50 dark:bg-red-500/10 border-red-200 dark:border-red-500/28';
  if (info.color === 'yellow') return 'bg-amber-50 dark:bg-amber-500/10 border-amber-200 dark:border-amber-500/28';
  return 'bg-surface';
}

// ── Upload hóa đơn / chứng từ thanh toán ──────────────────────────────────────
function InvoiceUploader({ requestId, value = [], onChange, label, required = true }) {
  // FIX: trước đây gọi t(...) TRƯỚC khi khai báo const { t } = useLang() → ReferenceError
  // (temporal dead zone) mỗi khi component render mà không truyền prop `label`.
  const { t } = useLang();
  if (!label) label = t('production','mr_invoice_label');
  const { fmtCurrency, fmtDate, fmtDateTime } = useFmt();
  const fileRef = useRef();
  const videoRef = useRef();
  const canvasRef = useRef();
  const [uploading, setUploading] = useState(false);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [stream, setStream] = useState(null);
  const [previews, setPreviews] = useState([]);
  const toast = useToast();

  const uploadFiles = async (files) => {
    if (!files.length) return;
    setUploading(true);
    try {
      const form = new FormData();
      files.forEach(f => form.append('files', f));
      if (requestId) form.append('requestId', requestId);
      const res = await api.post('/api/upload/production/material-request-invoice', form, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      onChange([...value, ...(res.data?.data || [])]);
    } catch (e) { toast(e?.response?.data?.message || t('production','mr_upload_failed'), 'error'); }
    finally { setUploading(false); }
  };

  const handleFiles = async (files) => {
    const arr = Array.from(files);
    const lp = arr.map(f => URL.createObjectURL(f));
    setPreviews(p => [...p, ...lp]);
    await uploadFiles(arr);
    setPreviews(p => p.filter(x => !lp.includes(x)));
  };

  const openCamera = async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
      setStream(s); setCameraOpen(true);
      setTimeout(() => { if (videoRef.current) videoRef.current.srcObject = s; }, 50);
    } catch { toast(t('production','mr_camera_error'), 'error'); }
  };

  const closeCamera = () => { stream?.getTracks().forEach(t => t.stop()); setStream(null); setCameraOpen(false); };

  const capturePhoto = () => {
    const v = videoRef.current, c = canvasRef.current;
    if (!v || !c) return;
    c.width = v.videoWidth; c.height = v.videoHeight;
    c.getContext('2d').drawImage(v, 0, 0);
    c.toBlob(blob => {
      if (!blob) return;
      closeCamera();
      handleFiles([new File([blob], `invoice-${Date.now()}.jpg`, { type: 'image/jpeg' })]);
    }, 'image/jpeg', 0.85);
  };

  return (
    <div>
      <p className="text-xs font-semibold text-muted uppercase tracking-wider mb-2">
        {label} {required && <span className="text-red-500">*</span>}
      </p>
      <div className="flex gap-2 flex-wrap">
        {value.map((url, i) => (
          <div key={i} className="relative w-20 h-20 rounded-xl overflow-hidden border border-hairline-2 group">
            <img src={imgUrl(url)} alt="" className="w-full h-full object-cover"/>
            <button onClick={() => onChange(value.filter((_, j) => j !== i))}
              className="absolute top-1 right-1 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <X size={10}/>
            </button>
          </div>
        ))}
        {previews.map((p, i) => (
          <div key={i} className="relative w-20 h-20 rounded-xl overflow-hidden border border-hairline-2">
            <img src={`${import.meta.env.VITE_API_BASE_URL}/api/auth/${p}`} alt="" className="w-full h-full object-cover"/>
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center"><Loader2 size={16} className="text-white animate-spin"/></div>
          </div>
        ))}
        <button type="button" onClick={openCamera}
          className="w-20 h-20 rounded-xl border-2 border-dashed border-gold/40 flex flex-col items-center justify-center hover:border-gold hover:bg-gold/5 gap-1">
          <Camera size={20} className="text-gold"/>
          <span className="text-[10px] text-gold font-medium">{t('production','mr_capture')}</span>
        </button>
        <button type="button" onClick={() => fileRef.current?.click()}
          className="w-20 h-20 rounded-xl border-2 border-dashed border-line flex flex-col items-center justify-center hover:border-gold hover:bg-gold/5 gap-1">
          <Plus size={20} className="text-muted"/>
          <span className="text-[10px] text-muted">{t('production','mr_choose_file')}</span>
        </button>
        <input ref={fileRef} type="file" multiple accept="image/*,application/pdf" className="hidden" onChange={e => handleFiles(e.target.files)}/>
      </div>
      {cameraOpen && (
        <div className="fixed inset-0 z-[90] bg-black flex flex-col items-center justify-center">
          <button onClick={closeCamera} className="absolute top-4 right-4 text-white p-2"><X size={24}/></button>
          <video ref={videoRef} autoPlay playsInline muted className="max-w-full max-h-[70vh] rounded-xl"/>
          <canvas ref={canvasRef} className="hidden"/>
          <button onClick={capturePhoto}
            className="mt-6 w-16 h-16 rounded-full bg-surface border-4 border-gold flex items-center justify-center hover:scale-105 transition-transform">
            <Camera size={24} className="text-gold"/>
          </button>
        </div>
      )}
    </div>
  );
}

// ── Vendor select — bắt buộc chọn từ danh mục NCC có sẵn (không nhập tự do) ──
// Dùng portal để render danh sách ra <body> — tránh bị modal (overflow-y-auto)
// cắt mất phần dropdown khi ô chọn nằm gần đáy modal.
function VendorSelectDropdown({ value, onChange, vendors: vendorsProp, loading: loadingProp }) {
  const { t } = useLang();
  const { fmtCurrency, fmtDate, fmtDateTime } = useFmt();
  const [vendors, setVendors] = useState(vendorsProp || []);
  const [loading, setLoading] = useState(!vendorsProp && loadingProp !== false);
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [pos, setPos] = useState({ top: 0, left: 0, width: 0, dropUp: false });
  const triggerRef = useRef(null);
  const popRef = useRef(null);

  // Nếu danh sách NCC được truyền từ ngoài vào (vd: danh sách NCC vừa thêm
  // trong cùng phiếu), dùng luôn — không tự fetch lại.
  useEffect(() => {
    if (vendorsProp) { setVendors(vendorsProp); setLoading(false); return; }
    (async () => {
      setLoading(true);
      try {
        const res = await factoryProdApi.listVendors('', 'MATERIAL');
        setVendors(res || []);
      } catch { setVendors([]); }
      finally { setLoading(false); }
    })();
  }, [vendorsProp]);

  useEffect(() => {
    if (!open) return;
    const handler = (e) => {
      if (triggerRef.current && !triggerRef.current.contains(e.target) &&
          popRef.current && !popRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const calcPos = useCallback(() => {
    if (!triggerRef.current) return;
    const r = triggerRef.current.getBoundingClientRect();
    const estListHeight = 260; // search bar + max-h danh sách
    const spaceBelow = window.innerHeight - r.bottom;
    const dropUp = spaceBelow < estListHeight && r.top > spaceBelow;
    setPos({
      top: dropUp ? r.top + window.scrollY : r.bottom + window.scrollY + 4,
      left: r.left + window.scrollX,
      width: r.width,
      dropUp,
    });
  }, []);

  const toggleOpen = () => {
    if (!open) calcPos();
    setOpen(o => !o);
  };

  useEffect(() => {
    if (!open) return;
    calcPos();
    const onScrollOrResize = () => calcPos();
    window.addEventListener('resize', onScrollOrResize);
    window.addEventListener('scroll', onScrollOrResize, true);
    return () => {
      window.removeEventListener('resize', onScrollOrResize);
      window.removeEventListener('scroll', onScrollOrResize, true);
    };
  }, [open, calcPos]);

  const filtered = vendors.filter(v => v.name.toLowerCase().includes(search.toLowerCase()));

  const select = (v) => {
    setOpen(false); setSearch('');
    onChange({ vendorId: v.id, vendorName: v.name, contactPerson: v.contactPerson || '', contactPhone: v.contactPhone || '' });
  };

  const dropdown = open ? createPortal(
    <div
      ref={popRef}
      style={{
        position: 'absolute',
        top: pos.dropUp ? undefined : pos.top,
        bottom: pos.dropUp ? (window.innerHeight - pos.top + window.scrollY + 4) : undefined,
        left: pos.left,
        width: pos.width,
        zIndex: 9999,
      }}
      className="bg-surface border border-line rounded-xl shadow-2xl overflow-hidden"
    >
      <div className="p-2 border-b border-hairline relative">
        <Search size={12} className="absolute left-5 top-1/2 -translate-y-1/2 text-muted"/>
        <input autoFocus value={search} onChange={e => setSearch(e.target.value)}
          placeholder={t('production','mr_search_vendor')}
          className="w-full pl-7 pr-2 py-1.5 text-sm rounded-lg border border-hairline-2 focus:outline-none focus:ring-2 focus:ring-gold/40"/>
      </div>
      <div className="max-h-44 overflow-auto">
        {filtered.length === 0 && (
          <p className="text-center py-4 text-xs text-muted">
            {loading ? 'Đang tải...' : 'Không có nhà cung cấp — hãy tạo trong trang Công nợ NCC'}
          </p>
        )}
        {filtered.map(v => (
          <button key={v.id} className="w-full text-left px-3 py-2 text-sm hover:bg-canvas border-b border-hairline last:border-0" onClick={() => select(v)}>
            <p className="font-medium text-ink">{v.name}</p>
            {(v.contactPerson || v.contactPhone) && (
              <p className="text-xs text-muted">{v.contactPerson}{v.contactPerson && v.contactPhone ? ' · ' : ''}{v.contactPhone}</p>
            )}
          </button>
        ))}
      </div>
    </div>,
    document.body
  ) : null;

  return (
    <div className="relative" ref={triggerRef}>
      <div
        onClick={toggleOpen}
        className={`flex items-center justify-between px-3 py-2.5 rounded-xl border cursor-pointer transition text-sm ${value?.vendorId ? 'border-gold bg-surface' : 'border-line bg-canvas'}`}
      >
        {value?.vendorId ? (
          <div className="min-w-0">
            <p className="font-medium text-ink truncate">{value.vendorName}</p>
            {(value.contactPerson || value.contactPhone) && (
              <p className="text-xs text-muted truncate">
                {value.contactPerson}{value.contactPerson && value.contactPhone ? ' · ' : ''}{value.contactPhone}
              </p>
            )}
          </div>
        ) : (
          <span className="text-muted">{loading ? 'Đang tải...' : 'Chọn nhà cung cấp...'}</span>
        )}
        <ChevronDown size={14} className={`text-muted flex-shrink-0 ml-2 transition-transform ${open ? 'rotate-180' : ''}`}/>
      </div>
      {dropdown}
    </div>
  );
}

// ── Confirm Order Modal — datetime picker (ngày + giờ phút) ──────────────────
function ConfirmOrderModal({ req, onClose, onDone }) {
  const { t } = useLang();
  const { fmtCurrency, fmtDate, fmtDateTime } = useFmt();
  const toast = useToast();
  // Date + time riêng để dễ nhập
  const [deliveryDate, setDeliveryDate] = useState(null);    // timestamp ms (chỉ ngày)
  const [deliveryTime, setDeliveryTime] = useState('08:00'); // "HH:mm"
  const [vendors, setVendors] = useState([{ vendorId: null, vendorName: '', contactPerson: '', contactPhone: '' }]);
  // itemId -> vendorId (NCC nào cung cấp nguyên liệu này)
  const [itemVendorId, setItemVendorId] = useState({});
  const [saving, setSaving] = useState(false);

  const items = req.items || [];

  // Combine date + time thành timestamp
  const getEstDeliveryMs = () => {
    if (!deliveryDate) return null;
    const d = new Date(deliveryDate);
    const [h, m] = (deliveryTime || '08:00').split(':').map(Number);
    d.setHours(h || 0, m || 0, 0, 0);
    return d.getTime();
  };

  // Chỉ những NCC đã thật sự chọn (có vendorId) mới tính là hợp lệ để gán cho nguyên liệu
  const validVendors = vendors.filter(v => v.vendorId);

  const addVendor = () => setVendors(p => [...p, { vendorId: null, vendorName: '', contactPerson: '', contactPhone: '' }]);
  const removeVendor = (i) => setVendors(p => p.filter((_, idx) => idx !== i));
  const setVendor = (i, data) => setVendors(p => p.map((v, idx) => idx === i ? { ...v, ...data } : v));

  // Nếu chỉ có đúng 1 NCC hợp lệ, tự gán mặc định NCC đó cho tất cả nguyên liệu
  // chưa được gán (giúp đỡ phải chọn lại thủ công cho trường hợp phổ biến nhất).
  // Lưu ý: gán theo vendorId (ổn định) thay vì vị trí trong mảng — vì vị trí có
  // thể đổi khi thêm/xoá NCC, còn vendorId thì không.
  useEffect(() => {
    if (validVendors.length !== 1) return;
    const onlyVendorId = validVendors[0].vendorId;
    setItemVendorId(prev => {
      const next = { ...prev };
      let changed = false;
      items.forEach(it => {
        if (next[it.id] == null) { next[it.id] = onlyVendorId; changed = true; }
      });
      return changed ? next : prev;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [validVendors.length, validVendors[0]?.vendorId, items.length]);

  // Nếu NCC nào bị xoá khỏi danh sách, bỏ gán của các nguyên liệu đang gán cho NCC đó
  useEffect(() => {
    const validIds = new Set(validVendors.map(v => v.vendorId));
    setItemVendorId(prev => {
      const next = {};
      let changed = false;
      Object.entries(prev).forEach(([itemId, vendorId]) => {
        if (vendorId != null && validIds.has(vendorId)) next[itemId] = vendorId;
        else changed = true;
      });
      return changed ? next : prev;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [validVendors.map(v => v.vendorId).join(',')]);

  const setItemVendor = (itemId, vendorId) => setItemVendorId(p => ({ ...p, [itemId]: vendorId }));

  const allItemsAssigned = items.length > 0 && items.every(it => itemVendorId[it.id] != null);

  const handleSubmit = async () => {
    const estDelivery = getEstDeliveryMs();
    if (!estDelivery) { toast(t('production','mr_err_delivery_time'), 'error'); return; }
    if (validVendors.length === 0) { toast(t('production','mr_err_select_vendor'), 'error'); return; }
    if (!allItemsAssigned) { toast(t('production','mr_err_assign_vendor'), 'error'); return; }
    setSaving(true);
    try {
      const vendorIndexById = new Map(validVendors.map((v, i) => [v.vendorId, i]));
      await accountantMaterialRequestApi.confirmOrder(req.id, {
        estimatedDelivery: estDelivery,
        vendors: validVendors.map((v, i) => ({ ...v, sortOrder: i })),
        items: items.map(it => ({ itemId: it.id, vendorIndex: vendorIndexById.get(itemVendorId[it.id]) })),
      });
      toast(t('production','mr_toast_confirmed'), 'success');
      onDone();
    } catch (e) {
      toast(e?.response?.data?.message || t('error','generic'), 'error');
    } finally { setSaving(false); }
  };

  return (
    <Modal open onClose={onClose} title={`Xác nhận đặt hàng — ${req.requestCode}`} size="lg">
      <div className="space-y-4">
        {/* Thời gian giao hàng — ngày + giờ phút */}
        <div>
          <p className="text-xs font-semibold text-muted uppercase tracking-wider mb-2">
            Thời gian giao hàng dự kiến <span className="text-red-500">*</span>
          </p>
          <div className="flex gap-3 items-center">
            <div className="flex-1">
              <DatePicker
                value={deliveryDate}
                onChange={setDeliveryDate}
                placeholder={t('production','mr_ph_delivery_date')}
                minDate={new Date()}
              />
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <input
                type="time"
                className={`${inputCls} w-32`}
                value={deliveryTime}
                onChange={e => setDeliveryTime(e.target.value)}
              />
              <span className="text-xs text-muted">{t('production','mr_delivery_hour')}</span>
            </div>
          </div>
          {deliveryDate && (
            <p className="text-xs text-gold mt-1.5">
              → Dự kiến: {new Date(getEstDeliveryMs()).toLocaleString('vi-VN', { day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit' })}
            </p>
          )}
        </div>

        {/* Nhà cung cấp */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm font-medium text-ink">{t('production','metrics_vendor')}</p>
            <button onClick={addVendor} className="text-xs text-gold font-semibold flex items-center gap-1">
              <Plus size={11}/> Thêm NCC
            </button>
          </div>
          <div className="space-y-3">
            {vendors.map((v, i) => (
              <div key={i} className="bg-canvas rounded-xl p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-medium text-muted">NCC {i + 1}</p>
                  {vendors.length > 1 && (
                    <button onClick={() => removeVendor(i)} className="text-red-400 hover:text-red-600 dark:text-red-300"><X size={14}/></button>
                  )}
                </div>
                <VendorSelectDropdown value={v} onChange={data => setVendor(i, data)}/>
              </div>
            ))}
          </div>
        </div>

        {/* Gán nguyên liệu cho từng NCC — bắt buộc ──────────────────────────── */}
        <div>
          <p className="text-xs font-semibold text-muted uppercase tracking-wider mb-2">
            Gán nguyên liệu cho nhà cung cấp <span className="text-red-500">*</span>
          </p>
          {validVendors.length === 0 ? (
            <p className="text-sm text-muted bg-canvas rounded-xl p-3">
              Chọn nhà cung cấp ở trên trước, sau đó gán từng nguyên liệu cho NCC tương ứng.
            </p>
          ) : (
            <div className="space-y-2">
              {items.map((it, i) => {
                const assignedVendorId = itemVendorId[it.id];
                const unassigned = assignedVendorId == null;
                return (
                  <div key={it.id} className={`rounded-xl p-3 ${unassigned ? 'bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/28' : 'bg-canvas'}`}>
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-ink truncate">{it.materialName}</p>
                        <p className="text-xs text-muted">{it.qtyRequested} {it.unit}</p>
                      </div>
                      {validVendors.length === 1 ? (
                        <div className="text-xs font-semibold text-ink bg-surface px-3 py-2 rounded-lg border border-line whitespace-nowrap max-w-[40%] truncate flex-shrink-0">
                          {validVendors[0].vendorName}
                        </div>
                      ) : (
                        <select
                          className={`${inputCls} w-28 sm:w-32 flex-shrink-0 text-xs`}
                          value={assignedVendorId ?? ''}
                          onChange={e => setItemVendor(it.id, e.target.value === '' ? null : Number(e.target.value))}
                        >
                          <option value="">{t('production','mr_select_vendor_option')}</option>
                          {validVendors.map(v => (
                            <option key={v.vendorId} value={v.vendorId}>{v.vendorName}</option>
                          ))}
                        </select>
                      )}
                    </div>
                    {unassigned && (
                      <p className="text-xs text-red-500 mt-1.5">{t('production','mr_vendor_not_assigned')}</p>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="flex gap-2 pt-2">
          <SecondaryButton className="flex-1" onClick={onClose}>Huỷ</SecondaryButton>
          <PrimaryButton className="flex-1" onClick={handleSubmit} disabled={saving}>
            {saving ? 'Đang xử lý...' : 'Xác nhận đặt hàng'}
          </PrimaryButton>
        </div>
      </div>
    </Modal>
  );
}

// ── Complete Modal — nhập đơn giá từng NL, chọn NCC, Thanh toán/Công nợ theo NCC ──
function CompleteModal({ req, onClose, onDone }) {
  const { t } = useLang();
  const toast = useToast();
  const [saving, setSaving] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  const vendors = req.vendors || [];
  const singleVendor = vendors.length === 1 ? vendors[0] : null;

  const receivedItems = (req.items || []).filter(it => it.qtyReceived != null && Number(it.qtyReceived) > 0);

  // itemId -> requestVendorId
  const [itemVendors, setItemVendors] = useState(() => {
    const init = {};
    receivedItems.forEach(it => {
      init[it.id] = it.requestVendorId || (singleVendor ? singleVendor.id : null);
    });
    return init;
  });

  // ── LOẠI GIÁ NHẬP ─────────────────────────────────────────────────────────
  // 'UNIT'  : nhập ĐƠN GIÁ của 1 đơn vị tính  (MẶC ĐỊNH)
  // 'TOTAL' : nhập TỔNG TIỀN của 1 nguyên liệu → tự chia SL ra đơn giá (3 số lẻ)
  const [priceMode, setPriceMode] = useState('UNIT');

  // itemId -> chuỗi người dùng gõ (đã format kiểu VN, ý nghĩa tuỳ priceMode).
  const [priceInputs, setPriceInputs] = useState(() => {
    const init = {};
    receivedItems.forEach(it => { init[it.id] = ''; });
    return init;
  });

  const setPriceInput = (itemId, raw) => {
    // Format ngay theo chuẩn VN mỗi lần gõ/xoá 1 ký tự.
    setPriceInputs(p => ({ ...p, [itemId]: formatMoneyTyping(raw) }));
    setShowPreview(false);
  };

  const switchMode = (mode) => {
    if (mode === priceMode) return;
    setPriceInputs(prev => {
      const next = {};
      receivedItems.forEach(it => {
        const v = parseMoneyVN(prev[it.id]);
        const qty = Number(it.qtyReceived) || 0;
        if (v === null || !qty) { next[it.id] = ''; return; }
        next[it.id] = mode === 'TOTAL'
          ? moneyToVN(v * qty)                      // đơn giá → tổng tiền
          : moneyToVN(unitPriceFromTotal(v, qty));  // tổng tiền → đơn giá (3 số lẻ)
      });
      return next;
    });
    setPriceMode(mode);
    setShowPreview(false);
  };

  // Đơn giá thực tế đã quy đổi theo chế độ nhập
  const unitPrices = useMemo(() => {
    const m = {};
    receivedItems.forEach(it => {
      const v = parseMoneyVN(priceInputs[it.id]);
      const qty = Number(it.qtyReceived) || 0;
      m[it.id] = v === null ? 0 : (priceMode === 'TOTAL' ? unitPriceFromTotal(v, qty) : v);
    });
    return m;
  }, [priceInputs, priceMode, req.id]);

  // ── Thuế/phí tuỳ chỉnh: [{ id, label, amount, itemIds }] ───────────────────
  const [customEntries, setCustomEntries] = useState([]);

  const setItemVendor = (itemId, vendorId) => setItemVendors(p => ({ ...p, [itemId]: vendorId }));

  const addCustomEntry = () => { setShowPreview(false); setCustomEntries(p => [
    ...p,
    { id: Date.now() + Math.random(), label: '', amount: '', itemIds: receivedItems.map(it => it.id) },
  ]); };
  const removeCustomEntry = (id) => { setShowPreview(false); setCustomEntries(p => p.filter(e => e.id !== id)); };
  const updateCustomEntry = (id, patch) => { setShowPreview(false); setCustomEntries(p => p.map(e => e.id === id ? { ...e, ...patch } : e)); };
  const toggleCustomEntryItem = (entryId, itemId) => { setShowPreview(false); setCustomEntries(p => p.map(e => {
    if (e.id !== entryId) return e;
    const has = e.itemIds.includes(itemId);
    return { ...e, itemIds: has ? e.itemIds.filter(x => x !== itemId) : [...e.itemIds, itemId] };
  })); };

  // ── PHÂN BỔ THUẾ/PHÍ → GIÁ VỐN (cùng công thức với backend) ────────────────
  const alloc = useMemo(() => allocateCost(
    receivedItems.map(it => ({
      id: it.id,
      quantity: Number(it.qtyReceived) || 0,
      unitPrice: unitPrices[it.id] || 0,
    })),
    customEntries
      .filter(ce => ce.label.trim() && parseMoneyVN(ce.amount) > 0)
      .map(ce => ({ label: ce.label.trim(), amount: parseMoneyVN(ce.amount), itemIds: ce.itemIds })),
  ), [unitPrices, customEntries, req.id]);

  // Tiền THẬT phải trả NCC của mỗi dòng = giá trị hàng + thuế/phí phân bổ (chưa làm tròn về đồng)
  const itemPayables = {};
  receivedItems.forEach(it => {
    const r = alloc.get(it.id);
    itemPayables[it.id] = r ? r.lineValue + r.feeShare : 0;
  });

  const totalsByVendor = {};
  for (const it of receivedItems) {
    const vendorId = itemVendors[it.id];
    if (!vendorId) continue;
    const amount = itemPayables[it.id] || 0;
    if (!amount) continue;
    totalsByVendor[vendorId] = (totalsByVendor[vendorId] || 0) + amount;
  }
  const vendorsWithAmount = vendors.filter(v => totalsByVendor[v.id] > 0);
  const grandTotal = Object.values(totalsByVendor).reduce((s, v) => s + v, 0);
  const grandMaterialTotal = receivedItems.reduce((s, it) => s + (alloc.get(it.id)?.lineValue || 0), 0);
  const grandFeeTotal = customEntries.reduce((s, ce) => s + (parseMoneyVN(ce.amount) || 0), 0);

  // requestVendorId -> { action, paymentMethod, paymentInfo, proofImages }
  const [vendorDecisions, setVendorDecisions] = useState(() => {
    const init = {};
    vendors.forEach(v => {
      init[v.id] = { action: null, paymentMethod: 'BANK', paymentInfo: '', proofImages: [], importReceiptInfo: '', serialImei: '' };
    });
    return init;
  });
  const setVendorDecision = (vendorId, patch) =>
    setVendorDecisions(p => ({ ...p, [vendorId]: { ...p[vendorId], ...patch } }));

  const allVendorsAssigned = receivedItems.every(it => !!itemVendors[it.id]);
  const allMaterialEntered = receivedItems.every(it => (unitPrices[it.id] || 0) > 0);
  const allCustomValid = customEntries.every(ce => ce.label.trim() && parseMoneyVN(ce.amount) > 0 && ce.itemIds.length > 0);

  const allDecisionsValid = vendorsWithAmount.every(v => {
    const d = vendorDecisions[v.id];
    if (!d || !d.action) return false;
    // Mục 7: 2 field bắt buộc cho mọi NCC
    if (!d.importReceiptInfo?.trim() || !d.serialImei?.trim()) return false;
    if (d.action === 'PAID') return d.proofImages.length > 0 && d.paymentMethod;
    return true;
  });
  const vendorsWithoutCatalogLink = vendorsWithAmount.filter(v =>
    vendorDecisions[v.id]?.action === 'DEBT' && !v.vendorId);

  const pricesReady = receivedItems.length > 0 && allMaterialEntered && allCustomValid;
  const canSubmit = pricesReady && allVendorsAssigned
    && vendorsWithAmount.length > 0 && allDecisionsValid && vendorsWithoutCatalogLink.length === 0;

  const handlePreview = () => {
    if (!pricesReady) {
      toast('Vui lòng nhập đủ giá cho tất cả nguyên liệu và hoàn thiện các dòng thuế/phí', 'error');
      return;
    }
    setShowPreview(true);
  };

  const handleSubmit = async () => {
    if (!canSubmit) { toast('Vui lòng nhập đầy đủ giá nguyên liệu, phí/thuế và xử lý thanh toán cho tất cả NCC', 'error'); return; }
    setSaving(true);
    try {
      const itemVendorsPayload = receivedItems.map(it => ({
        itemId: it.id,
        requestVendorId: itemVendors[it.id],
      }));
      const costEntriesPayload = [
        // MATERIAL: luôn gửi ĐƠN GIÁ — server tự nhân với qtyReceived để ra tổng tiền.
        ...receivedItems.map(it => ({
          type: 'MATERIAL',
          label: 'Giá nguyên liệu',
          unitPrice: unitPrices[it.id],
          amount: normalizeMoney((unitPrices[it.id] || 0) * Number(it.qtyReceived || 0)),
          itemIds: [it.id],
        })),
        ...customEntries.map(ce => ({
          type: 'CUSTOM',
          label: ce.label.trim(),
          amount: parseMoneyVN(ce.amount),
          itemIds: ce.itemIds,
        })),
      ];
      const vendorPayments = vendorsWithAmount.map(v => {
        const d = vendorDecisions[v.id];
        return {
          requestVendorId: v.id,
          action: d.action,
          paymentMethod: d.action === 'PAID' ? d.paymentMethod : null,
          paymentInfo: d.action === 'PAID' ? d.paymentInfo : null,
          proofImages: d.action === 'PAID' ? d.proofImages : [],
          importReceiptInfo: d.importReceiptInfo?.trim() || null,
          serialImei: d.serialImei?.trim() || null,
        };
      });
      await accountantMaterialRequestApi.complete(req.id, {
        itemVendors: itemVendorsPayload,
        costEntries: costEntriesPayload,
        vendorPayments,
      });
      toast(t('production','mr_toast_completed'), 'success');
      onDone();
    } catch (e) { toast(e?.response?.data?.message || t('error','generic'), 'error'); }
    finally { setSaving(false); }
  };

  return (
    <Modal open onClose={onClose} title={`Hoàn thành phiếu — ${req.requestCode}`} size="lg">
      <div className="space-y-5">
        <div className="bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/28 rounded-xl p-3">
          <p className="text-sm font-medium text-emerald-700 dark:text-emerald-300">{t('production','mr_received')}</p>
          <p className="text-xs text-emerald-600 dark:text-emerald-300 mt-0.5">
            Nhập giá cho từng nguyên liệu, thêm các loại thuế/phí (nếu có). Thuế/phí được phân bổ
            theo tỷ trọng giá trị từng nguyên liệu; giá vốn chỉ làm tròn tới hàng đồng ở bước cuối.
          </p>
        </div>

        {/* ── Chọn loại giá nhập ── */}
        <div>
          <p className="text-xs font-semibold text-muted uppercase tracking-wider mb-2">Loại giá nhập</p>
          <div className="flex gap-2">
            <button onClick={() => switchMode('UNIT')}
              className={`flex-1 py-2 rounded-lg text-xs font-semibold border transition ${priceMode === 'UNIT'
                ? 'bg-gold text-white border-gold' : 'bg-surface text-muted border-line'}`}>
              Đơn giá / 1 đơn vị tính
            </button>
            <button onClick={() => switchMode('TOTAL')}
              className={`flex-1 py-2 rounded-lg text-xs font-semibold border transition ${priceMode === 'TOTAL'
                ? 'bg-gold text-white border-gold' : 'bg-surface text-muted border-line'}`}>
              Tổng tiền của 1 nguyên liệu
            </button>
          </div>
          <p className="text-[11px] text-muted mt-1.5">
            Nhập tối đa {MONEY_DECIMALS} số sau dấu thập phân (dùng dấu phẩy).
            {priceMode === 'TOTAL' && ' Hệ thống tự chia cho số lượng thực nhận để ra đơn giá.'}
          </p>
        </div>

        {/* ── Giá từng dòng nguyên liệu ── */}
        <div>
          <p className="text-xs font-semibold text-muted uppercase tracking-wider mb-2">
            Giá nguyên liệu (theo số lượng thực nhận)
          </p>
          {vendors.length === 0 && (
            <p className="text-sm text-red-500 mb-2">
              Phiếu này chưa có nhà cung cấp nào. Vui lòng quay lại bước "Xác nhận đặt hàng" để thêm NCC trước khi hoàn thành.
            </p>
          )}
          <div className="space-y-2">
            {receivedItems.map(it => {
              const r = alloc.get(it.id);
              const up = unitPrices[it.id] || 0;
              return (
                <div key={it.id} className="bg-canvas rounded-xl p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-ink">{it.materialName}</span>
                    <span className="text-xs text-muted">{it.qtyReceived} {it.unit}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {vendors.length > 1 ? (
                      <select className={inputCls} value={itemVendors[it.id] || ''}
                        onChange={e => setItemVendor(it.id, Number(e.target.value) || null)}>
                        <option value="">{t('production','mr_select_vendor_option')}</option>
                        {vendors.map(v => <option key={v.id} value={v.id}>{v.vendorName}</option>)}
                      </select>
                    ) : (
                      <div className="flex items-center px-3 py-2 text-sm text-muted bg-surface rounded-lg border border-line">
                        {singleVendor ? singleVendor.vendorName : '— Chưa có NCC —'}
                      </div>
                    )}
                    <input
                      type="text" inputMode="decimal"
                      className={`${inputCls} text-right tabular-nums`}
                      placeholder={priceMode === 'UNIT'
                        ? `Đơn giá / ${it.unit || 'đv'} (đ)`
                        : 'Tổng tiền nguyên liệu (đ)'}
                      value={priceInputs[it.id] ?? ''}
                      onChange={e => setPriceInput(it.id, e.target.value)}
                    />
                  </div>
                  {up > 0 && (
                    <p className="text-right text-xs text-ink">
                      {priceMode === 'TOTAL'
                        ? <>Đơn giá: <span className="font-semibold text-gold">{fmtMoney(up)} đ/{it.unit}</span></>
                        : <>Thành tiền: <span className="font-semibold text-gold">{fmtMoney(r?.lineValue)} đ</span></>}
                    </p>
                  )}
                </div>
              );
            })}
            {receivedItems.length === 0 && (
              <p className="text-sm text-red-500">{t('production','mr_no_received_qty')}</p>
            )}
          </div>
          {grandMaterialTotal > 0 && (
            <p className="text-right text-xs text-muted mt-1.5">
              Tổng tiền nguyên liệu: <span className="font-semibold text-ink">{fmtMoney(grandMaterialTotal)} đ</span>
            </p>
          )}
        </div>

        {/* ── Thuế/phí tuỳ chỉnh ── */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs font-semibold text-muted uppercase tracking-wider">
              Thuế / phí khác (mỗi dòng 1 loại)
            </p>
            <button onClick={addCustomEntry}
              className="flex items-center gap-1 text-xs font-semibold text-gold hover:underline">
              <Plus size={13} /> Thêm thuế/phí
            </button>
          </div>

          {customEntries.length === 0 ? (
            <p className="text-xs text-muted flex items-center gap-1.5">
              <Info size={12} /> Không có thuế/phí → giá vốn = đơn giá nhập.
            </p>
          ) : (
            <div className="space-y-3">
              {customEntries.map(ce => (
                <div key={ce.id} className="bg-surface border border-line rounded-xl p-3 space-y-2">
                  <div className="flex gap-2">
                    <input className={inputCls} placeholder={t('production','mr_ph_cost_name')}
                      value={ce.label} onChange={e => updateCustomEntry(ce.id, { label: e.target.value })} />
                    <input type="text" inputMode="decimal" className={`${inputCls} w-40 text-right tabular-nums`} placeholder="Số tiền (đ)"
                      value={ce.amount}
                      onChange={e => updateCustomEntry(ce.id, { amount: formatMoneyTyping(e.target.value) })} />
                    <button onClick={() => removeCustomEntry(ce.id)}
                      className="p-2 rounded-lg hover:bg-red-50 dark:bg-red-500/10 text-red-400 transition flex-shrink-0">
                      <Trash2 size={14} />
                    </button>
                  </div>
                  <div>
                    <p className="text-[10px] text-muted mb-1">{t('production','mr_apply_to')}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {receivedItems.map(it => {
                        const checked = ce.itemIds.includes(it.id);
                        return (
                          <button key={it.id} onClick={() => toggleCustomEntryItem(ce.id, it.id)}
                            className={`text-xs px-2 py-1 rounded-full border transition ${checked
                              ? 'bg-gold/10 border-gold text-gold font-semibold'
                              : 'bg-surface border-line text-muted'}`}>
                            {checked ? '✓ ' : ''}{it.materialName}
                          </button>
                        );
                      })}
                    </div>
                    {ce.itemIds.length === 0 && (
                      <p className="text-xs text-red-500 mt-1">{t('production','mr_no_material_selected')}</p>
                    )}
                  </div>
                </div>
              ))}
              <p className="text-right text-xs text-muted">
                Tổng thuế/phí: <span className="font-semibold text-ink">{fmtMoney(grandFeeTotal)} đ</span>
              </p>
            </div>
          )}
        </div>

        {/* ── PREVIEW giá vốn tạm tính ── */}
        <div>
          <button onClick={handlePreview} disabled={!pricesReady}
            className="w-full py-2.5 rounded-xl border border-gold text-gold font-semibold hover:bg-gold/10 transition disabled:opacity-40 flex items-center justify-center gap-2">
            <Eye size={16} /> Xem trước giá vốn tạm tính
          </button>

          {showPreview && (
            <div className="mt-3 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/28 rounded-xl p-3 space-y-2">
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-ink-2 border-b border-emerald-200 dark:border-emerald-500/28">
                      <th className="text-left py-1.5 font-semibold">Nguyên liệu</th>
                      <th className="text-right py-1.5 font-semibold">SL</th>
                      <th className="text-right py-1.5 font-semibold">Đơn giá</th>
                      <th className="text-right py-1.5 font-semibold">Thuế/phí gánh</th>
                      <th className="text-right py-1.5 font-semibold">Giá vốn / đv</th>
                    </tr>
                  </thead>
                  <tbody>
                    {receivedItems.map(it => {
                      const r = alloc.get(it.id);
                      if (!r) return null;
                      return (
                        <tr key={it.id} className="border-b border-emerald-100 dark:border-emerald-500/18 last:border-0">
                          <td className="py-1.5 text-ink">{it.materialName}</td>
                          <td className="py-1.5 text-right tabular-nums">{it.qtyReceived} {it.unit}</td>
                          <td className="py-1.5 text-right tabular-nums">{fmtMoney(r.unitPrice)}</td>
                          <td className="py-1.5 text-right tabular-nums text-amber-700 dark:text-amber-300">
                            {r.feeShare > 0 ? fmtMoney(r.feeShare) : '—'}
                          </td>
                          <td className="py-1.5 text-right tabular-nums font-bold text-emerald-800 dark:text-emerald-300">
                            {fmtDong(r.unitCost)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <p className="text-[10px] text-emerald-700 dark:text-emerald-300">
                Giá vốn làm tròn tới hàng đơn vị đồng ở bước cuối; các bước trung gian giữ nguyên phần thập phân.
              </p>
            </div>
          )}
        </div>

        {/* ── Thanh toán / Công nợ theo từng NCC ── */}
        {vendorsWithAmount.length > 0 && (
          <div>
            <p className="text-xs font-semibold text-muted uppercase tracking-wider mb-2">
              Thanh toán cho từng nhà cung cấp
            </p>
            <div className="space-y-3">
              {vendorsWithAmount.map(v => {
                const total = totalsByVendor[v.id] || 0;
                const d = vendorDecisions[v.id];
                const missingCatalogLink = d.action === 'DEBT' && !v.vendorId;
                return (
                  <div key={v.id} className="bg-surface border border-line rounded-xl p-3 space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-semibold text-ink">{v.vendorName}</p>
                      <p className="text-sm font-bold text-gold">{fmtMoney(total)} đ</p>
                    </div>

                    {/* Mục 7: 2 field bắt buộc theo từng NCC */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[11px] font-medium text-muted mb-1">Thông tin phiếu nhập *</label>
                        <input className={inputCls}
                          placeholder="Mã phiếu nhập, mã batch NCC..."
                          value={d.importReceiptInfo}
                          onChange={e => setVendorDecision(v.id, { importReceiptInfo: e.target.value })}/>
                      </div>
                      <div>
                        <label className="block text-[11px] font-medium text-muted mb-1">Serial / IMEI *</label>
                        <input className={inputCls}
                          placeholder="Dãy số / text từ NCC"
                          value={d.serialImei}
                          onChange={e => setVendorDecision(v.id, { serialImei: e.target.value })}/>
                      </div>
                    </div>
                    {(!d.importReceiptInfo?.trim() || !d.serialImei?.trim()) && (
                      <p className="text-xs text-red-500">Vui lòng nhập thông tin phiếu nhập và Serial/IMEI</p>
                    )}

                    <div className="flex gap-2">
                      <button
                        className={`flex-1 py-2 rounded-lg text-xs font-semibold border transition-all ${d.action === 'PAID' ? 'bg-forest-deep text-white border-forest-deep' : 'bg-surface text-muted border-line'}`}
                        onClick={() => setVendorDecision(v.id, { action: 'PAID' })}>
                        Thanh toán luôn
                      </button>
                      <button
                        className={`flex-1 py-2 rounded-lg text-xs font-semibold border transition-all ${d.action === 'DEBT' ? 'bg-amber-600 text-white border-amber-600 dark:border-amber-500/40' : 'bg-surface text-muted border-line'}`}
                        onClick={() => setVendorDecision(v.id, { action: 'DEBT' })}>
                        Công nợ
                      </button>
                    </div>

                    {d.action === 'PAID' && (
                      <div className="space-y-2 pt-1">
                        <div className="grid grid-cols-2 gap-2">
                          <select className={inputCls} value={d.paymentMethod}
                            onChange={e => setVendorDecision(v.id, { paymentMethod: e.target.value })}>
                            {PAYMENT_METHODS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
                          </select>
                          <input className={inputCls}
                            placeholder={d.paymentMethod === 'CASH' ? 'Ghi chú tiền mặt' : 'Số TK / nội dung CK'}
                            value={d.paymentInfo}
                            onChange={e => setVendorDecision(v.id, { paymentInfo: e.target.value })}/>
                        </div>
                        <InvoiceUploader
                          requestId={req.id}
                          value={d.proofImages}
                          onChange={imgs => setVendorDecision(v.id, { proofImages: imgs })}
                          label="Chứng từ thanh toán"
                        />
                        {d.proofImages.length === 0 && (
                          <p className="text-xs text-red-500">{t('production','mr_need_receipt')}</p>
                        )}
                      </div>
                    )}

                    {d.action === 'DEBT' && missingCatalogLink && (
                      <p className="text-xs text-red-500">
                        NCC này chưa liên kết với danh mục Nhà cung cấp nên không thể ghi công nợ.
                        Vui lòng quay lại bước "Xác nhận đặt hàng" và chọn NCC có sẵn trong danh mục.
                      </p>
                    )}
                    {d.action === 'DEBT' && !missingCatalogLink && (
                      <p className="text-xs text-amber-700 dark:text-amber-300">
                        Sẽ cộng {fmtMoney(total)} đ vào công nợ của {v.vendorName}.
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {grandTotal > 0 && (
          <div className="pt-2 border-t border-hairline flex items-center justify-between">
            <span className="text-sm font-semibold text-ink">{t('production','mr_total_amount')}</span>
            <span className="text-lg font-bold text-gold">{fmtMoney(grandTotal)} đ</span>
          </div>
        )}

        <div className="flex gap-2 pt-2">
          <SecondaryButton className="flex-1" onClick={onClose}>Huỷ</SecondaryButton>
          <PrimaryButton className="flex-1" onClick={handleSubmit}
            disabled={saving || !canSubmit || !showPreview}
            title={!showPreview ? 'Bấm "Xem trước giá vốn" để kiểm tra trước khi lưu' : ''}>
            {saving ? 'Đang xử lý...' : 'Hoàn thành phiếu'}
          </PrimaryButton>
        </div>
      </div>
    </Modal>
  );
}

// ── Request Card ──────────────────────────────────────────────────────────────
// ── Modal gia hạn ngày giao hàng ───────────────────────────────────────────────
function ExtendDeliveryModal({ req, onClose, onDone }) {
  const { t } = useLang();
  const toast = useToast();
  const [newDate, setNewDate] = useState(null);
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    if (!newDate) { toast(t('production','mr_err_new_date'), 'error'); return; }
    setSaving(true);
    try {
      await accountantMaterialRequestApi.extendDelivery(req.id, {
        newDeliveryDate: newDate,
        reason: reason.trim() || null,
      });
      toast(t('production','mr_toast_extended'), 'success');
      onDone();
    } catch (e) {
      toast(e?.response?.data?.message || t('error','generic'), 'error');
    } finally { setSaving(false); }
  };

  return (
    <Modal open onClose={onClose} title={`Gia hạn giao hàng — ${req.requestCode}`} size="sm">
      <div className="space-y-4">
        <div>
          <p className="text-xs text-muted mb-1">
            Ngày giao hiện tại: <span className="font-semibold text-ink">{req.estimatedDelivery ? fmtDateTime(req.estimatedDelivery) : '—'}</span>
          </p>
          {req.deliveryExtendedTo && (
            <p className="text-xs text-amber-700 dark:text-amber-300 mb-1">
              Đã gia hạn trước đó: {fmtDateTime(req.deliveryExtendedTo)}
              {req.deliveryExtendReason ? ` — ${req.deliveryExtendReason}` : ''}
            </p>
          )}
        </div>
        <Field label="Ngày giao hàng mới" required>
          <DatePicker value={newDate} onChange={setNewDate} placeholder={t('production','mr_ph_new_date')} minDate={new Date()} />
        </Field>
        <Field label="Lý do gia hạn">
          <textarea className={inputCls} rows={2} value={reason} onChange={e => setReason(e.target.value)}
            placeholder={t('production','mr_ph_extend_reason')} />
        </Field>
        <div className="flex gap-2">
          <SecondaryButton className="flex-1" onClick={onClose}>Huỷ</SecondaryButton>
          <PrimaryButton className="flex-1" onClick={handleSubmit} disabled={saving}>
            {saving ? 'Đang lưu...' : 'Gia hạn'}
          </PrimaryButton>
        </div>
      </div>
    </Modal>
  );
}

function RequestCard({ req, onConfirmOrder, onComplete, onExtendDelivery }) {
  const { t } = useLang();
  const [expanded, setExpanded] = useState(false);
  const cfg = STATUS_CONFIG[req.status] || STATUS_CONFIG.NEW;
  const bg = cardBg(req);

  return (
    <div className={`rounded-2xl border ${bg} border-hairline shadow-sm overflow-hidden`}>
      <button className="w-full text-left px-5 py-4" onClick={() => setExpanded(e => !e)}>
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-mono text-sm font-bold text-ink">{req.requestCode}</span>
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${cfg.cls}`}>{cfg.label}</span>
              {req.status === 'RECEIVED' && (
                <span className="text-xs bg-emerald-100 dark:bg-emerald-500/18 text-emerald-700 dark:text-emerald-300 px-2 py-0.5 rounded-full font-medium">{t('production','mr_status_pending')}</span>
              )}
            </div>
            <p className="text-xs text-muted mt-1">
              {req.createdByName} · {req.itemCount} nguyên liệu · {fmtTs(req.createdAt)}
            </p>
            {/* Countdown badges — hiển thị trên card */}
            <div className="mt-2 flex flex-wrap gap-2">
              {req.requiredBy && req.status === 'NEW' && (
                <LiveCountdownBadge targetMs={req.requiredBy} label="Cần xử lý trong"/>
              )}
              {req.estimatedDelivery && req.status === 'ORDERED' && (
                <LiveCountdownBadge targetMs={req.estimatedDelivery} label="Giao hàng trong"/>
              )}
            </div>
          </div>
          {expanded
            ? <ChevronUp size={16} className="text-muted flex-shrink-0 mt-1"/>
            : <ChevronDown size={16} className="text-muted flex-shrink-0 mt-1"/>}
        </div>
      </button>

      {expanded && (
        <div className="px-5 pb-4 border-t border-hairline">
          {/* Danh sách nguyên liệu */}
          <div className="mt-3">
            <p className="text-xs font-semibold text-muted uppercase tracking-wider mb-2">{t('production','pcalc_ingredients')}</p>
            <div className="space-y-2">
              {(req.items || []).map((it, i) => (
                <div key={i} className="flex items-center justify-between bg-canvas rounded-xl px-3 py-2">
                  <div>
                    <span className="text-sm text-ink font-medium">{it.materialName}</span>
                    {it.suppliedByVendorName && (
                      <p className="text-xs text-muted">{it.suppliedByVendorName}</p>
                    )}
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-semibold text-ink">{it.qtyRequested}</span>
                    <span className="text-xs text-muted ml-1">{it.unit}</span>
                    {it.qtyReceived != null && (
                      <span className="ml-2 text-xs text-emerald-600 dark:text-emerald-300">(nhận: {it.qtyReceived})</span>
                    )}
                    {it.lineAmount != null && (
                      <p className="text-xs text-gold font-semibold">{fmtVND(it.lineAmount)}</p>
                    )}
                    {it.costBreakdown?.length > 1 && (
                      <p className="text-[10px] text-muted mt-0.5">
                        {it.costBreakdown.map((b, bi) => `${b.label}: ${fmtVND(b.amount)}`).join(' · ')}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Nhà cung cấp (nếu đã có) */}
          {req.vendors?.length > 0 && (
            <div className="mt-3 pt-3 border-t border-hairline">
              <p className="text-xs font-semibold text-muted uppercase tracking-wider mb-1">{t('production','metrics_vendor')}</p>
              {req.vendors.map((v, i) => (
                <div key={i} className="py-0.5">
                  <div className="flex items-center justify-between text-xs text-ink">
                    <span>
                      {v.vendorName}{v.contactPerson ? ` · ${v.contactPerson}` : ''}{v.contactPhone ? ` · ${v.contactPhone}` : ''}
                    </span>
                    {v.paymentStatus === 'PAID' && (
                      <span className="text-emerald-600 dark:text-emerald-300 font-semibold">Đã thanh toán {fmtVND(v.totalAmount)}</span>
                    )}
                    {v.paymentStatus === 'DEBT' && (
                      <span className="text-amber-700 dark:text-amber-300 font-semibold">
                        Công nợ {fmtVND(v.debtRemaining)}
                        {v.debtSettlementStatus === 'SETTLED' ? ' (đã trả hết)' : v.debtSettlementStatus === 'PARTIAL' ? ' (đã trả 1 phần)' : ''}
                      </span>
                    )}
                  </div>
                  {(v.importReceiptInfo || v.serialImei) && (
                    <div className="flex flex-wrap gap-x-3 mt-0.5 text-[11px] text-muted">
                      {v.importReceiptInfo && <span>Phiếu nhập: <span className="text-ink">{v.importReceiptInfo}</span></span>}
                      {v.serialImei && <span>Serial/IMEI: <span className="text-ink">{v.serialImei}</span></span>}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Thời gian giao nếu đã đặt */}
          {req.estimatedDelivery && req.status !== 'NEW' && (
            <div className="mt-2 space-y-0.5">
              <p className="text-xs text-muted">
                🚚 Dự kiến giao: <span className="font-medium text-ink">{fmtDateTime(req.estimatedDelivery)}</span>
              </p>
              {req.deliveryExtendedTo && (
                <p className="text-xs text-amber-700 dark:text-amber-300">
                  📅 Gia hạn đến: <span className="font-semibold">{fmtDateTime(req.deliveryExtendedTo)}</span>
                  {req.deliveryExtendReason ? <span className="text-muted"> — {req.deliveryExtendReason}</span> : ''}
                </p>
              )}
            </div>
          )}

          {/* Actions */}
          {req.status === 'NEW' && (
            <div className="mt-4">
              <PrimaryButton className="w-full" onClick={() => onConfirmOrder(req)}>
                Xác nhận đặt hàng
              </PrimaryButton>
            </div>
          )}

          {req.status === 'ORDERED' && (
            <div className="mt-4 flex gap-2">
              <SecondaryButton className="flex-1 flex items-center justify-center gap-1.5" onClick={() => onExtendDelivery(req)}>
                <CalendarClock size={14} /> Gia hạn giao hàng
              </SecondaryButton>
            </div>
          )}

          {req.status === 'RECEIVED' && (
            <div className="mt-4">
              <p className="text-xs text-emerald-600 dark:text-emerald-300 mb-2">✓ Nhận hàng lúc {fmtDateTime(req.receivedAt)}</p>
              <PrimaryButton className="w-full" onClick={() => onComplete(req)}>
                <Check size={14} className="mr-2"/> Hoàn thành phiếu
              </PrimaryButton>
            </div>
          )}

          {req.status === 'COMPLETED' && req.completedAt && (
            <p className="mt-3 text-xs text-muted">
              ✓ Hoàn thành {fmtDateTime(req.completedAt)}
              {req.totalAmount != null && <> · Tổng tiền: <span className="font-semibold text-ink">{fmtVND(req.totalAmount)}</span></>}
            </p>
          )}
        </div>
      )}
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function SuperAccountantMaterialRequestPage() {
  const { t } = useLang();
  const { fmtCurrency, fmtDate, fmtDateTime } = useFmt();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useMinLoading();
  const [confirmTarget, setConfirmTarget] = useState(null);
  const [completeTarget, setCompleteTarget] = useState(null);
  const [extendTarget, setExtendTarget] = useState(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [dateRange, setDateRange] = useState({ from: null, to: null });
  const [page, setPage] = useState(0);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await accountantMaterialRequestApi.list({
        status: statusFilter || undefined,
        dateFrom: dateRange.from || undefined,
        dateTo: dateRange.to || undefined,
        search: search || undefined,
        page,
      });
      setData(res);
    } finally { setLoading(false); }
  }, [statusFilter, dateRange, search, page]);

  useEffect(() => { load(); }, [load]);

  const requests = data?.content || [];

  return (
    <div className="p-4 space-y-4 bg-surface-2 min-h-full">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-ink">{t('production','mr_title')}</h1>
      </div>

      <div className="bg-surface rounded-2xl border border-hairline shadow-sm p-4 space-y-3">
        <div className="relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted"/>
          <input
            className="w-full pl-9 pr-4 py-2 text-sm rounded-xl border border-line focus:outline-none focus:border-gold bg-canvas placeholder-muted"
            placeholder={t('production','mr_search_ph')}
            value={search}
            onChange={e => { setSearch(e.target.value); setPage(0); }}
          />
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {[
            { val: '', label: 'Tất cả' }, { val: 'NEW', label: 'Mới tạo' },
            { val: 'ORDERED', label: 'Đã đặt' }, { val: 'RECEIVED', label: 'Đã nhận' },
            { val: 'COMPLETED', label: 'Hoàn thành' },
          ].map(s => (
            <button key={s.val} onClick={() => { setStatusFilter(s.val); setPage(0); }}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${statusFilter === s.val ? 'bg-forest-deep text-white border-forest-deep' : 'bg-surface text-muted border-line hover:border-forest-deep'}`}>
              {s.label}
            </button>
          ))}
          <DateRangePicker from={dateRange.from} to={dateRange.to} onChange={r => { setDateRange(r); setPage(0); }} placeholder={t('production','mr_filter_date')}/>
        </div>
      </div>

      {loading
        ? <div className="space-y-3">{[1,2,3].map(i => <CardSkeleton key={i}/>)}</div>
        : requests.length === 0
          ? <div className="bg-surface rounded-2xl border border-hairline shadow-sm p-10 text-center">
              <Package size={32} className="mx-auto text-muted mb-2"/>
              <p className="text-muted text-sm">{t('production','mr_empty')}</p>
            </div>
          : <div className="space-y-3">
              {requests.map(req => (
                <RequestCard key={req.id} req={req} onConfirmOrder={setConfirmTarget} onComplete={setCompleteTarget} onExtendDelivery={setExtendTarget}/>
              ))}
            </div>
      }

      {data?.totalPages > 1 && (
        <div className="flex justify-center gap-2">
          <button disabled={page === 0} onClick={() => setPage(p => p - 1)}
            className="px-4 py-2 rounded-xl border border-line text-sm disabled:opacity-40 hover:bg-surface-2">{t('production','mr_prev')}</button>
          <span className="px-4 py-2 text-sm text-muted">{page + 1} / {data.totalPages}</span>
          <button disabled={page >= data.totalPages - 1} onClick={() => setPage(p => p + 1)}
            className="px-4 py-2 rounded-xl border border-line text-sm disabled:opacity-40 hover:bg-surface-2">{t('production','mr_next')}</button>
        </div>
      )}

      {confirmTarget && (
        <ConfirmOrderModal req={confirmTarget} onClose={() => setConfirmTarget(null)} onDone={() => { setConfirmTarget(null); load(); }}/>
      )}
      {completeTarget && (
        <CompleteModal req={completeTarget} onClose={() => setCompleteTarget(null)} onDone={() => { setCompleteTarget(null); load(); }}/>
      )}
      {extendTarget && (
        <ExtendDeliveryModal req={extendTarget} onClose={() => setExtendTarget(null)} onDone={() => { setExtendTarget(null); load(); }}/>
      )}
    </div>
  );
}