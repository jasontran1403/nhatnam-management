// src/context/AuthContext.jsx
import { createContext, useContext, useState, useCallback } from 'react';
import { authApi } from '../api/services';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem('user')); } catch { return null; }
  });
  const [token, setToken] = useState(() => localStorage.getItem('token'));

  const login = useCallback(async (username, password, selectedRole = null) => {
    const res = await authApi.login({ username, password, selectedRole });
    const { data } = res.data;

    if (data.requireRoleSelection) {
      // Check if there's a default role saved for this username
      const defaultRole = localStorage.getItem(`defaultRole:${username}`);
      if (defaultRole && data.availableRoles?.includes(defaultRole)) {
        // Auto-login with default role
        const res2 = await authApi.login({ username, password, selectedRole: defaultRole });
        const { data: data2 } = res2.data;
        localStorage.setItem('token', data2.accessToken);
        localStorage.setItem('user', JSON.stringify(data2));
        setToken(data2.accessToken);
        setUser(data2);
        return data2;
      }
      return data;
    }

    localStorage.setItem('token', data.accessToken);
    localStorage.setItem('user', JSON.stringify(data));
    setToken(data.accessToken);
    setUser(data);
    return data;
  }, []);

  /**
   * Switch role không cần re-enter password.
   * Gọi /api/auth/switch-role với token hiện tại.
   */
  const switchRole = useCallback(async (newRole) => {
    const res = await authApi.switchRole(newRole);
    const data = res.data?.data ?? res.data;
    localStorage.setItem('token', data.accessToken);
    localStorage.setItem('user', JSON.stringify(data));
    setToken(data.accessToken);
    setUser(data);
    return data;
  }, []);

  /**
   * Đặt role mặc định cho username hiện tại.
   * Khi đăng nhập lần sau sẽ tự vào role này.
   */
  const setDefaultRole = useCallback((username, role) => {
    if (role) {
      localStorage.setItem(`defaultRole:${username}`, role);
    } else {
      localStorage.removeItem(`defaultRole:${username}`);
    }
  }, []);

  const getDefaultRole = useCallback((username) => {
    return localStorage.getItem(`defaultRole:${username}`) || null;
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    localStorage.removeItem('app_lang');
    localStorage.removeItem('app-version-code');
    setToken(null);
    setUser(null);
  }, []);

  const updateUser = useCallback((newData) => {
    const updated = { ...user, ...newData };
    localStorage.setItem('user', JSON.stringify(updated));
    setUser(updated);
  }, [user]);

  const isAuthenticated = !!token && !!user;
  const role = user?.role || user?.roles?.[0] || '';

  return (
    <AuthContext.Provider value={{
      user, token, login, logout, switchRole,
      setDefaultRole, getDefaultRole,
      isAuthenticated, role, updateUser,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
