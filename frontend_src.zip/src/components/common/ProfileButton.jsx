// src/components/common/ProfileButton.jsx
import { useState } from 'react';
import { UserCircle, X, Eye, EyeOff, Loader2, Check, Mail, Phone, Lock, RefreshCw, Star, ChevronRight } from 'lucide-react';
import api from '../../api/axios';
import { useToast } from './Toast';
import { useAuth } from '../../context/AuthContext';
import { useLang } from '../../context/LangContext';
import { useNavigate } from 'react-router-dom';

function inputCls(hasErr) {
    return `w-full px-3 py-2.5 rounded-xl border text-sm focus:outline-none transition
    ${hasErr
            ? 'border-red-400 bg-red-50/40 focus:border-red-400'
            : 'border-black/10 focus:border-[#C9A84C] focus:ring-2 focus:ring-[#C9A84C]/20'}`;
}

const ROLE_LABELS = {
    ADMIN: 'Quản trị viên', OWNER: 'Giám đốc', SELLER: 'Kinh doanh',
    SUPER_SELLER: 'Trưởng KD', ACCOUNTANT: 'Kế toán', SUPER_ACCOUNTANT: 'Trưởng KT',
    WAREHOUSE: 'Kho hàng', SUPER_WAREHOUSE: 'Trưởng kho', HR: 'Nhân sự',
    SUPERADMIN: 'Super Admin',
};

const ROLE_COLORS = {
    ADMIN: 'bg-red-100 text-red-700', OWNER: 'bg-purple-100 text-purple-700',
    SELLER: 'bg-blue-100 text-blue-700', SUPER_SELLER: 'bg-blue-200 text-blue-800',
    ACCOUNTANT: 'bg-green-100 text-green-700', SUPER_ACCOUNTANT: 'bg-green-200 text-green-800',
    WAREHOUSE: 'bg-orange-100 text-orange-700', SUPER_WAREHOUSE: 'bg-orange-200 text-orange-800',
    HR: 'bg-pink-100 text-pink-700', SUPERADMIN: 'bg-gray-200 text-gray-800',
};

export default function ProfileButton({ compact = false }) {
    const navigate = useNavigate();
    const [redirecting, setRedirecting] = useState(false);
    const toast = useToast();
    const { user: authUser, logout, updateUser, switchRole, setDefaultRole, getDefaultRole } = useAuth();
    const { t } = useLang();
    const [open, setOpen] = useState(false);
    // 'menu' | 'profile' | 'switch-role'
    const [view, setView] = useState('menu');
    const [tab, setTab] = useState('info');

    const [profile, setProfile] = useState(null);
    const [loadingProfile, setLoadingProfile] = useState(false);
    const [infoForm, setInfoForm] = useState({ fullName: '', email: '', phoneNumber: '' });
    const [infoErr, setInfoErr] = useState({});
    const [savingInfo, setSavingInfo] = useState(false);

    const [pwdForm, setPwdForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
    const [pwdErr, setPwdErr] = useState({});
    const [savingPwd, setSavingPwd] = useState(false);
    const [showPwd, setShowPwd] = useState({ current: false, new: false, confirm: false });

    const [switchingRole, setSwitchingRole] = useState(null);

    const availableRoles = authUser?.availableRoles || [];
    const currentRole = authUser?.role || '';
    const defaultRole = getDefaultRole(authUser?.username || '');

    const loadProfile = async () => {
        setLoadingProfile(true);
        try {
            const res = await api.get('/api/profile');
            const data = res.data?.data;
            setProfile(data);
            setInfoForm({ fullName: data?.fullName || '', email: data?.email || '', phoneNumber: data?.phoneNumber || '' });
        } catch (e) { console.error(e); }
        finally { setLoadingProfile(false); }
    };

    const handleOpen = () => {
        setOpen(true);
        setView('menu');
        setPwdForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
        setPwdErr({}); setInfoErr({});
    };

    const handleOpenProfile = () => {
        setView('profile');
        setTab('info');
        loadProfile();
    };

    const handleSaveInfo = async () => {
        const errs = {};
        if (infoForm.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(infoForm.email))
            errs.email = t('misc', 'email_invalid');
        setInfoErr(errs);
        if (Object.keys(errs).length) return;
        setSavingInfo(true);
        try {
            const res = await api.put('/api/profile', {
                fullName: infoForm.fullName.trim() || null,
                email: infoForm.email.trim() || null,
                phoneNumber: infoForm.phoneNumber.trim() || null,
            });
            if (res.data?.success === false) { toast(res.data?.message || 'Lỗi', 'error'); return; }
            toast('Đã lưu thông tin', 'success');
            const updated = res.data?.data;
            setProfile(updated);
            updateUser({ fullName: updated?.fullName, email: updated?.email, phoneNumber: updated?.phoneNumber });
        } catch (e) { toast(e?.response?.data?.message || 'Lỗi', 'error'); }
        finally { setSavingInfo(false); }
    };

    const handleChangePassword = async () => {
        const errs = {};
        if (!pwdForm.currentPassword) errs.currentPassword = t('common', 'required');
        if (!pwdForm.newPassword || pwdForm.newPassword.length < 6) errs.newPassword = t('auth', 'password_min_length');
        if (pwdForm.newPassword !== pwdForm.confirmPassword) errs.confirmPassword = t('auth', 'password_mismatch');
        setPwdErr(errs);
        if (Object.keys(errs).length) return;
        setSavingPwd(true);
        try {
            const res = await api.put('/api/profile/password', {
                currentPassword: pwdForm.currentPassword, newPassword: pwdForm.newPassword,
            });
            if (res.data?.success === false) { toast(res.data?.message || 'Lỗi', 'error'); return; }
            toast(t('auth', 'change_password_success_relogin'), 'success');
            setRedirecting(true);
            setTimeout(() => { setOpen(false); logout(); navigate('/login'); }, 1500);
        } catch (e) { toast(e?.response?.data?.message || 'Lỗi', 'error'); }
        finally { setSavingPwd(false); }
    };

    const handleSwitchRole = async (role) => {
        if (role === currentRole) return;
        setSwitchingRole(role);
        try {
            await switchRole(role);
            toast(`Đã chuyển sang ${ROLE_LABELS[role] || role}`, 'success');
            setOpen(false);
            // Force reload to apply new role routing
            setTimeout(() => window.location.href = '/', 300);
        } catch (e) {
            toast(e?.response?.data?.message || 'Lỗi chuyển role', 'error');
        } finally { setSwitchingRole(null); }
    };

    const handleToggleDefault = (role) => {
        const username = authUser?.username || '';
        if (defaultRole === role) {
            setDefaultRole(username, null);
            toast('Đã bỏ role mặc định', 'info');
        } else {
            setDefaultRole(username, role);
            toast(`${ROLE_LABELS[role] || role} sẽ là role mặc định khi đăng nhập`, 'success');
        }
    };

    const displayRole = t('roles', currentRole.toLowerCase()) || ROLE_LABELS[currentRole] || currentRole;

    const tabs = [
        { key: 'info', label: t('profile', 'info_tab'), icon: UserCircle },
        { key: 'password', label: t('profile', 'password_tab'), icon: Lock },
    ];

    return (
        <>
            <button onClick={handleOpen}
                className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl hover:bg-[#FAF7F2] transition group"
                title={t('profile', 'my_profile')}>
                <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#C9A84C] to-[#A07830] flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                    {(authUser?.fullName || authUser?.username || '?')[0]?.toUpperCase()}
                </div>
                {!compact && (
                    <div className="hidden sm:block text-left">
                        <p className="text-xs font-semibold text-[#1C1C1E] leading-tight truncate max-w-[120px]">
                            {authUser?.fullName || authUser?.username}
                        </p>
                        <p className="text-[10px] text-[#8E8878] leading-tight">{displayRole}</p>
                    </div>
                )}
            </button>

            {open && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                    <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setOpen(false)} />
                    <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
                        {redirecting && (
                            <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-10 flex flex-col items-center justify-center gap-3 rounded-2xl">
                                <Loader2 size={28} className="animate-spin text-[#C9A84C]" />
                                <p className="text-sm font-semibold text-[#1C1C1E]">{t('common', 'loading')}</p>
                            </div>
                        )}

                        {/* Header */}
                        <div className="flex items-center justify-between px-5 py-4 border-b border-black/5">
                            <div className="flex items-center gap-3">
                                {view !== 'menu' && (
                                    <button onClick={() => setView('menu')}
                                        className="p-1 rounded-lg text-[#8E8878] hover:bg-[#FAF7F2] mr-1">
                                        <ChevronRight size={16} className="rotate-180" />
                                    </button>
                                )}
                                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#C9A84C] to-[#A07830] flex items-center justify-center text-white font-bold">
                                    {(authUser?.fullName || authUser?.username || '?')[0]?.toUpperCase()}
                                </div>
                                <div>
                                    <p className="font-bold text-[#1C1C1E]">{authUser?.fullName || authUser?.username}</p>
                                    <p className="text-xs text-[#8E8878]">@{authUser?.username} · {displayRole}</p>
                                </div>
                            </div>
                            <button onClick={() => setOpen(false)} className="p-1.5 rounded-lg text-[#8E8878] hover:bg-[#FAF7F2]">
                                <X size={18} />
                            </button>
                        </div>

                        {/* ── View: Menu ── */}
                        {view === 'menu' && (
                            <div className="p-4 space-y-2">
                                {/* Switch Role option — only if user has multiple roles */}
                                {availableRoles.length > 1 && (
                                    <button onClick={() => setView('switch-role')}
                                        className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-[#FAF7F2] border border-[#F0EBE3] transition text-left group">
                                        <div className="w-9 h-9 rounded-xl bg-[#C9A84C]/10 flex items-center justify-center flex-shrink-0">
                                            <RefreshCw size={16} className="text-[#C9A84C]" />
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <p className="text-sm font-semibold text-[#1C1C1E]">Chuyển đổi vai trò</p>
                                            <p className="text-xs text-[#8E8878]">Đang dùng: <span className={`px-1.5 py-0.5 rounded font-medium ${ROLE_COLORS[currentRole] || 'bg-gray-100 text-gray-700'}`}>{ROLE_LABELS[currentRole] || currentRole}</span></p>
                                        </div>
                                        <ChevronRight size={16} className="text-[#C4B9A8] group-hover:text-[#C9A84C] flex-shrink-0" />
                                    </button>
                                )}

                                {/* Update profile */}
                                <button onClick={handleOpenProfile}
                                    className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-[#FAF7F2] border border-[#F0EBE3] transition text-left group">
                                    <div className="w-9 h-9 rounded-xl bg-blue-50 flex items-center justify-center flex-shrink-0">
                                        <UserCircle size={16} className="text-blue-500" />
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <p className="text-sm font-semibold text-[#1C1C1E]">Thông tin tài khoản</p>
                                        <p className="text-xs text-[#8E8878]">Cập nhật tên, email, mật khẩu</p>
                                    </div>
                                    <ChevronRight size={16} className="text-[#C4B9A8] group-hover:text-[#C9A84C] flex-shrink-0" />
                                </button>
                            </div>
                        )}

                        {/* ── View: Switch Role ── */}
                        {view === 'switch-role' && (
                            <div className="p-4 space-y-2">
                                <p className="text-xs text-[#8E8878] px-1 mb-3">
                                    Chọn vai trò để chuyển đổi. Nhấn ⭐ để đặt làm mặc định khi đăng nhập.
                                </p>
                                {availableRoles.map(r => {
                                    const isActive = r === currentRole;
                                    const isDefault = r === defaultRole;
                                    const isSwitching = switchingRole === r;
                                    return (
                                        <div key={r}
                                            className={`flex items-center gap-3 px-4 py-3 rounded-xl border transition
                                            ${isActive
                                                ? 'border-[#C9A84C] bg-[#FDF8ED]'
                                                : 'border-[#F0EBE3] hover:border-[#C9A84C]/40 hover:bg-[#FAF7F2]'}`}>
                                            {/* Role info - clickable to switch */}
                                            <button
                                                onClick={() => handleSwitchRole(r)}
                                                disabled={isActive || !!switchingRole}
                                                className="flex items-center gap-3 flex-1 text-left disabled:cursor-default">
                                                {isSwitching
                                                    ? <Loader2 size={16} className="animate-spin text-[#C9A84C] flex-shrink-0" />
                                                    : isActive
                                                        ? <Check size={16} className="text-[#C9A84C] flex-shrink-0" />
                                                        : <div className="w-4 h-4 rounded-full border-2 border-[#E8DDD0] flex-shrink-0" />
                                                }
                                                <div>
                                                    <p className={`text-sm font-semibold ${isActive ? 'text-[#C9A84C]' : 'text-[#1C1C1E]'}`}>
                                                        {ROLE_LABELS[r] || r}
                                                    </p>
                                                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${ROLE_COLORS[r] || 'bg-gray-100 text-gray-600'}`}>
                                                        {r}
                                                    </span>
                                                </div>
                                            </button>
                                            {/* Star = set default */}
                                            <button
                                                onClick={() => handleToggleDefault(r)}
                                                title={isDefault ? 'Bỏ mặc định' : 'Đặt làm mặc định'}
                                                className={`p-1.5 rounded-lg transition flex-shrink-0
                                                ${isDefault ? 'text-yellow-500 hover:text-yellow-600' : 'text-[#C4B9A8] hover:text-yellow-500'}`}>
                                                <Star size={14} fill={isDefault ? 'currentColor' : 'none'} />
                                            </button>
                                        </div>
                                    );
                                })}
                            </div>
                        )}

                        {/* ── View: Profile ── */}
                        {view === 'profile' && (
                            <>
                                <div className="flex border-b border-black/5">
                                    {tabs.map(({ key, label, icon: Icon }) => (
                                        <button key={key} onClick={() => setTab(key)}
                                            className={`flex-1 flex items-center justify-center gap-2 py-3 text-sm font-medium transition border-b-2
                                            ${tab === key
                                                ? 'border-[#C9A84C] text-[#C9A84C]'
                                                : 'border-transparent text-[#8E8878] hover:text-[#1C1C1E] hover:bg-[#FAF7F2]'}`}>
                                            <Icon size={15} /> {label}
                                        </button>
                                    ))}
                                </div>

                                {tab === 'info' && (
                                    <div className="p-5 space-y-4">
                                        {loadingProfile ? (
                                            <div className="flex justify-center py-8">
                                                <Loader2 size={24} className="animate-spin text-[#C9A84C]" />
                                            </div>
                                        ) : (
                                            <>
                                                <div>
                                                    <label className="block text-sm font-semibold text-[#1C1C1E] mb-1.5 flex items-center gap-1.5">
                                                        <UserCircle size={13} className="text-[#C9A84C]" /> {t('profile', 'full_name')}
                                                    </label>
                                                    <input type="text" value={infoForm.fullName}
                                                        onChange={e => setInfoForm(p => ({ ...p, fullName: e.target.value }))}
                                                        placeholder={t('placeholder', 'name_example')}
                                                        className={inputCls(false)} />
                                                </div>
                                                <div>
                                                    <label className="block text-sm font-semibold text-[#1C1C1E] mb-1.5 flex items-center gap-1.5">
                                                        <Mail size={13} className="text-[#C9A84C]" /> Email
                                                    </label>
                                                    <input type="email" value={infoForm.email}
                                                        onChange={e => { setInfoForm(p => ({ ...p, email: e.target.value })); setInfoErr(p => ({ ...p, email: '' })); }}
                                                        placeholder="email@example.com" className={inputCls(!!infoErr.email)} />
                                                    {infoErr.email && <p className="text-xs text-red-500 mt-1">{infoErr.email}</p>}
                                                </div>
                                                <div>
                                                    <label className="block text-sm font-semibold text-[#1C1C1E] mb-1.5 flex items-center gap-1.5">
                                                        <Phone size={13} className="text-[#C9A84C]" /> {t('customer', 'phone')}
                                                    </label>
                                                    <input type="tel" value={infoForm.phoneNumber}
                                                        onChange={e => setInfoForm(p => ({ ...p, phoneNumber: e.target.value }))}
                                                        placeholder="0912 345 678" className={inputCls(false)} />
                                                </div>
                                                <button onClick={handleSaveInfo} disabled={savingInfo}
                                                    className="w-full py-2.5 rounded-xl bg-[#C9A84C] text-white font-semibold hover:bg-[#B8923E] transition disabled:opacity-50 flex items-center justify-center gap-2">
                                                    {savingInfo ? <><Loader2 size={16} className="animate-spin" /> {t('common', 'processing')}</> : <><Check size={16} /> {t('common', 'save_changes')}</>}
                                                </button>
                                            </>
                                        )}
                                    </div>
                                )}

                                {tab === 'password' && (
                                    <div className="p-5 space-y-4">
                                        {[
                                            { key: 'currentPassword', label: t('auth', 'current_password'), showKey: 'current' },
                                            { key: 'newPassword', label: t('auth', 'new_password'), showKey: 'new', hint: t('auth', 'password_min_length') },
                                            { key: 'confirmPassword', label: t('auth', 'confirm_password'), showKey: 'confirm' },
                                        ].map(({ key, label, showKey, hint }) => (
                                            <div key={key}>
                                                <label className="block text-sm font-semibold text-[#1C1C1E] mb-1.5">{label}</label>
                                                <div className="relative">
                                                    <input type={showPwd[showKey] ? 'text' : 'password'} value={pwdForm[key]}
                                                        onChange={e => { setPwdForm(p => ({ ...p, [key]: e.target.value })); setPwdErr(p => ({ ...p, [key]: '' })); }}
                                                        placeholder="••••••••" className={`${inputCls(!!pwdErr[key])} pr-10`} />
                                                    <button type="button"
                                                        onClick={() => setShowPwd(p => ({ ...p, [showKey]: !p[showKey] }))}
                                                        className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8E8878] hover:text-[#1C1C1E]">
                                                        {showPwd[showKey] ? <EyeOff size={15} /> : <Eye size={15} />}
                                                    </button>
                                                </div>
                                                {pwdErr[key] && <p className="text-xs text-red-500 mt-1">{pwdErr[key]}</p>}
                                                {hint && !pwdErr[key] && <p className="text-xs text-[#8E8878] mt-1">{hint}</p>}
                                            </div>
                                        ))}
                                        <button onClick={handleChangePassword} disabled={savingPwd}
                                            className="w-full py-2.5 rounded-xl bg-[#C9A84C] text-white font-semibold hover:bg-[#B8923E] transition disabled:opacity-50 flex items-center justify-center gap-2">
                                            {savingPwd ? <><Loader2 size={16} className="animate-spin" /> {t('common', 'processing')}</> : <><Lock size={16} /> {t('auth', 'change_password')}</>}
                                        </button>
                                        <p className="text-xs text-[#8E8878] text-center">{t('auth', 'change_password_success_relogin')}</p>
                                    </div>
                                )}
                            </>
                        )}
                    </div>
                </div>
            )}
        </>
    );
}
